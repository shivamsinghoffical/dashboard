import { useMemo, useState } from "react";
import { Input } from "@/components/ui/input";
import { nodeDefinitions, getNodesByCategory } from "@/lib/node-definitions";
import {
  Play,
  Webhook,
  Clock,
  Settings2,
  GitBranch,
  Timer,
  Braces,
  Globe,
  Mail,
  Table2,
  Folder,
  CalendarDays,
  FileText,
  MessageCircle,
  Sparkles,
  DollarSign,
  Search,
  X,
} from "lucide-react";
import { Button } from "@/components/ui/button";

const iconMap: Record<string, any> = {
  Play,
  Webhook,
  Clock,
  Settings2,
  GitBranch,
  Timer,
  Braces,
  Globe,
  Mail,
  Table2,
  Folder,
  CalendarDays,
  FileText,
  MessageCircle,
  Sparkles,
  DollarSign,
};

const categoryColors: Record<string, string> = {
  Triggers: "#22c55e",
  Core: "#3b82f6",
  Developer: "#f97316",
  Google: "#34a853",
  Communication: "#14b8a6",
  AI: "#a855f7",
  Finance: "#eab308",
};

const categoryOrder = [
  "Triggers",
  "Core",
  "Developer",
  "Google",
  "Communication",
  "AI",
  "Finance",
];

interface NodeLibraryProps {
  onAddNode: (type: string) => void;
  onClose: () => void;
}

export function NodeLibrary({ onAddNode, onClose }: NodeLibraryProps) {
  const [search, setSearch] = useState("");

  const categories = useMemo(() => getNodesByCategory(), []);
  const searchValue = search.trim().toLowerCase();

  const filteredCategories = useMemo(() => {
    const result: Record<string, typeof nodeDefinitions> = {};

    for (const category of categoryOrder) {
      const nodes = categories[category] || [];
      const filtered = nodes.filter((node) => {
        const haystack = [
          node.label,
          node.description,
          node.type,
          node.category,
        ]
          .join(" ")
          .toLowerCase();

        return haystack.includes(searchValue);
      });

      if (filtered.length > 0) {
        result[category] = filtered;
      }
    }

    for (const [category, nodes] of Object.entries(categories)) {
      if (result[category]) continue;

      const filtered = nodes.filter((node) => {
        const haystack = [
          node.label,
          node.description,
          node.type,
          node.category,
        ]
          .join(" ")
          .toLowerCase();

        return haystack.includes(searchValue);
      });

      if (filtered.length > 0) {
        result[category] = filtered;
      }
    }

    return result;
  }, [categories, searchValue]);

  const totalResults = Object.values(filteredCategories).reduce(
    (sum, nodes) => sum + nodes.length,
    0
  );

  return (
    <div
      className="h-full min-h-0 flex flex-col bg-background"
      data-testid="panel-node-library"
    >
      <div className="shrink-0 border-b border-border px-4 py-4">
        <div className="flex items-center justify-between gap-3">
          <div>
            <h3 className="text-lg font-semibold text-foreground">Add node</h3>
            <p className="mt-0.5 text-xs text-muted-foreground">
              Search and add workflow steps
            </p>
          </div>

          <Button
            size="icon"
            variant="ghost"
            onClick={onClose}
            className="h-8 w-8 rounded-md"
            data-testid="button-close-library"
          >
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="shrink-0 border-b border-border px-4 py-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search nodes, actions, apps..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="h-10 rounded-lg pl-10 pr-10 text-sm"
            data-testid="input-search-nodes"
          />
          {search && (
            <button
              type="button"
              onClick={() => setSearch("")}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="Clear search"
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>

        <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
          <span>{totalResults} nodes</span>
          {search && <span>Showing results for "{search}"</span>}
        </div>
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto">
        <div className="px-4 py-4 space-y-6">
          {totalResults > 0 ? (
            Object.entries(filteredCategories).map(([category, nodes]) => (
              <section key={category} className="space-y-3">
                <div className="flex items-center gap-2">
                  <div
                    className="h-2 w-2 rounded-full"
                    style={{
                      backgroundColor: categoryColors[category] || "#6b7280",
                    }}
                  />
                  <h4 className="text-[11px] font-semibold uppercase tracking-[0.16em] text-muted-foreground">
                    {category}
                  </h4>
                </div>

                <div className="space-y-2">
                  {nodes.map((node) => {
                    const Icon = iconMap[node.icon] || Settings2;
                    const nodeColor = node.color || "#6b7280";

                    return (
                      <button
                        key={node.type}
                        type="button"
                        onClick={() => onAddNode(node.type)}
                        className="group w-full rounded-xl border border-border/60 bg-card px-3 py-3 text-left transition-all hover:border-border hover:bg-accent/30 hover:shadow-sm"
                        data-testid={`button-add-node-${node.type}`}
                      >
                        <div className="flex items-start gap-3">
                          <div
                            className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border"
                            style={{
                              backgroundColor: `${nodeColor}14`,
                              color: nodeColor,
                              borderColor: `${nodeColor}2e`,
                            }}
                          >
                            <Icon className="h-4.5 w-4.5" />
                          </div>

                          <div className="min-w-0 flex-1">
                            <div className="flex items-center justify-between gap-3">
                              <p className="truncate text-sm font-semibold text-foreground">
                                {node.label}
                              </p>
                              <span className="shrink-0 rounded-md bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground opacity-0 transition-opacity group-hover:opacity-100">
                                Add
                              </span>
                            </div>

                            <p className="mt-1 line-clamp-2 text-xs leading-5 text-muted-foreground">
                              {node.description}
                            </p>
                          </div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </section>
            ))
          ) : (
            <div className="flex min-h-[260px] flex-col items-center justify-center text-center">
              <div className="rounded-full border border-border bg-muted/40 p-3">
                <Search className="h-5 w-5 text-muted-foreground" />
              </div>
              <p className="mt-4 text-sm font-medium text-foreground">
                No nodes found
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Try a different keyword or category.
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
