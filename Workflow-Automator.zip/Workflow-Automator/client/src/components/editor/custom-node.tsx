import { memo } from "react";
import { Handle, Position, type NodeProps } from "@xyflow/react";
import {
  Play,
  Webhook,
  Clock,
  Settings2,
  GitBranch,
  Timer,
  Braces,
  Globe,
  Mail,
  Table2,
  Folder,
  CalendarDays,
  FileText,
  MessageCircle,
  Sparkles,
  DollarSign,
  AlertCircle,
  CheckCircle2,
  PauseCircle,
} from "lucide-react";
import { getNodeDefinition } from "@/lib/node-definitions";

const iconMap: Record<string, any> = {
  Play,
  Webhook,
  Clock,
  Settings2,
  GitBranch,
  Timer,
  Braces,
  Globe,
  Mail,
  Table2,
  Folder,
  CalendarDays,
  FileText,
  MessageCircle,
  Sparkles,
  DollarSign,
};

function CustomNodeComponent({ data, selected }: NodeProps) {
  const def = getNodeDefinition(data.nodeType as string);
  const IconComponent = def ? iconMap[def.icon] : Settings2;
  const color = def?.color || "#6b7280";

  const outputs = def?.outputs || [];
  const hasMultipleOutputs = outputs.length > 1;

  const isTrigger = ["manualTrigger", "webhookTrigger", "scheduleTrigger"].includes(
    data.nodeType as string
  );

  const disabled = Boolean(data.disabled);
  const hasError = Boolean(data.hasError || data.error);
  const isSuccess = Boolean(data.lastRunStatus === "success");
  const isRunning = Boolean(data.lastRunStatus === "running");

  const subtitle =
    (data.description as string) || def?.description || (data.nodeType as string);

  const StatusIcon = hasError
    ? AlertCircle
    : isRunning
    ? PauseCircle
    : isSuccess
    ? CheckCircle2
    : null;

  return (
    <div
      className={[
        "group relative bg-card border shadow-sm transition-all duration-150",
        "rounded-xl",
        selected
          ? "border-primary ring-2 ring-primary/20 shadow-md"
          : "border-border hover:border-muted-foreground/30 hover:shadow-md",
        disabled ? "opacity-60" : "",
      ].join(" ")}
      style={{
        width: 220,
        minHeight: 78,
      }}
      data-testid={`node-${data.nodeType}`}
    >
      {!isTrigger && (
        <Handle
          type="target"
          position={Position.Left}
          className="!w-3 !h-3 !rounded-full !border-2 !shadow-none"
          style={{
            background: "hsl(var(--background))",
            borderColor: color,
            left: -6,
            top: "50%",
            transform: "translateY(-50%)",
          }}
        />
      )}

      <div
        className="absolute left-0 top-0 h-full w-1 rounded-l-xl"
        style={{ backgroundColor: color }}
      />

      <div className="flex items-center gap-3 px-3 py-3">
        <div
          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg border"
          style={{
            backgroundColor: `${color}14`,
            color,
            borderColor: `${color}30`,
          }}
        >
          {IconComponent ? <IconComponent className="h-5 w-5" /> : <Settings2 className="h-5 w-5" />}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-2">
            <p className="truncate text-sm font-semibold leading-5 text-foreground">
              {data.label as string}
            </p>

            {disabled && (
              <span className="shrink-0 rounded-md border border-border bg-muted px-1.5 py-0.5 text-[10px] font-medium text-muted-foreground">
                Off
              </span>
            )}
          </div>

          <p className="mt-0.5 line-clamp-1 text-xs leading-4 text-muted-foreground">
            {subtitle}
          </p>
        </div>

        <div className="flex shrink-0 items-center">
          {StatusIcon && (
            <StatusIcon
              className={[
                "h-4 w-4",
                hasError
                  ? "text-destructive"
                  : isRunning
                  ? "text-amber-500"
                  : "text-emerald-600",
              ].join(" ")}
            />
          )}
        </div>
      </div>

      {hasMultipleOutputs ? (
        <>
          <Handle
            type="source"
            position={Position.Right}
            id="true"
            className="!w-3 !h-3 !rounded-full !border-2 !shadow-none"
            style={{
              background: "hsl(var(--background))",
              borderColor: "#22c55e",
              right: -6,
              top: "34%",
            }}
          />
          <Handle
            type="source"
            position={Position.Right}
            id="false"
            className="!w-3 !h-3 !rounded-full !border-2 !shadow-none"
            style={{
              background: "hsl(var(--background))",
              borderColor: "#ef4444",
              right: -6,
              top: "68%",
            }}
          />

          <div
            className="pointer-events-none absolute -right-5 text-[10px] font-semibold"
            style={{ top: "27%", color: "#16a34a" }}
          >
            true
          </div>
          <div
            className="pointer-events-none absolute -right-5 text-[10px] font-semibold"
            style={{ top: "61%", color: "#dc2626" }}
          >
            false
          </div>
        </>
      ) : (
        <Handle
          type="source"
          position={Position.Right}
          className="!w-3 !h-3 !rounded-full !border-2 !shadow-none"
          style={{
            background: "hsl(var(--background))",
            borderColor: color,
            right: -6,
            top: "50%",
            transform: "translateY(-50%)",
          }}
        />
      )}
    </div>
  );
}

export const CustomNode = memo(CustomNodeComponent);
