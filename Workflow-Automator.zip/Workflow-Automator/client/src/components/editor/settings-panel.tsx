import { useState, useEffect, type ReactNode } from "react";
import { useQuery } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import {
  X,
  Copy,
  Trash2,
  Play,
  Loader2,
  ExternalLink,
  Pencil,
  Plus,
} from "lucide-react";
import { getNodeDefinition } from "@/lib/node-definitions";
import type { WorkflowNode, StepLog, CredentialMasked } from "@shared/schema";

interface SettingsPanelProps {
  node: WorkflowNode;
  onUpdate: (nodeId: string, data: Partial<WorkflowNode["data"]>) => void;
  onDelete: (nodeId: string) => void;
  onDuplicate: (nodeId: string) => void;
  onClose: () => void;
  onTestNode?: (nodeId: string) => void;
  isTestingNode?: boolean;
  nodeTestResult?: StepLog | null;
  lastRunSteps?: StepLog[];
}

type KeyValueRow = {
  id: string;
  name: string;
  value: string;
};

function makeRow(name = "", value = ""): KeyValueRow {
  return {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    name,
    value,
  };
}

function normalizeRows(value: any, uiValue?: any): KeyValueRow[] {
  if (Array.isArray(uiValue) && uiValue.length > 0) {
    return uiValue.map((item) => ({
      id: String(item?.id || makeRow().id),
      name: String(item?.name ?? ""),
      value: String(item?.value ?? ""),
    }));
  }

  if (Array.isArray(value) && value.length > 0) {
    return value.map((item) => ({
      id: String(item?.id || makeRow().id),
      name: String(item?.name ?? ""),
      value: String(item?.value ?? ""),
    }));
  }

  if (value && typeof value === "object" && Object.keys(value).length > 0) {
    return Object.entries(value).map(([k, v]) =>
      makeRow(String(k), v == null ? "" : String(v))
    );
  }

  return [makeRow()];
}

function rowsToObject(rows: KeyValueRow[]): Record<string, string> {
  const out: Record<string, string> = {};
  for (const row of rows) {
    const key = String(row.name || "").trim();
    if (!key) continue;
    out[key] = String(row.value ?? "");
  }
  return out;
}

function Section({
  title,
  description,
  children,
}: {
  title: string;
  description?: string;
  children: ReactNode;
}) {
  return (
    <div className="rounded-xl border border-border bg-card">
      <div className="border-b border-border px-4 py-3">
        <h3 className="text-sm font-semibold text-foreground">{title}</h3>
        {description ? (
          <p className="mt-1 text-xs text-muted-foreground">{description}</p>
        ) : null}
      </div>
      <div className="p-4 space-y-4">{children}</div>
    </div>
  );
}

export function SettingsPanel({
  node,
  onUpdate,
  onDelete,
  onDuplicate,
  onClose,
  onTestNode,
  isTestingNode,
  nodeTestResult,
  lastRunSteps,
}: SettingsPanelProps) {
  const def = getNodeDefinition(node.data.nodeType);
  const [config, setConfig] = useState<Record<string, any>>(node.data.config || {});
  const [label, setLabel] = useState(node.data.label);
  const [activeTab, setActiveTab] = useState("parameters");

  const [queryParamMode, setQueryParamMode] = useState<"fields" | "json">("fields");
  const [headerMode, setHeaderMode] = useState<"fields" | "json">("fields");
  const [formBodyMode, setFormBodyMode] = useState<"fields" | "json">("fields");

  const [queryRows, setQueryRows] = useState<KeyValueRow[]>([makeRow()]);
  const [headerRows, setHeaderRows] = useState<KeyValueRow[]>([makeRow()]);
  const [formRows, setFormRows] = useState<KeyValueRow[]>([makeRow()]);

  const { data: credentials } = useQuery<CredentialMasked[]>({
    queryKey: ["/api/credentials"],
  });

  useEffect(() => {
    const nextConfig = node.data.config || {};
    setConfig(nextConfig);
    setLabel(node.data.label);
    setActiveTab("parameters");

    setQueryRows(normalizeRows(nextConfig.queryParams, nextConfig.queryParamsUi));
    setHeaderRows(normalizeRows(nextConfig.headers, nextConfig.headersUi));
    setFormRows(normalizeRows(nextConfig.formBody, nextConfig.formBodyUi));

    setQueryParamMode(nextConfig.queryParamsMode || "fields");
    setHeaderMode(nextConfig.headersMode || "fields");
    setFormBodyMode(nextConfig.formBodyMode || "fields");
  }, [node.id, node.data.label, node.data.config]);

  const updateConfig = (patch: Record<string, any>) => {
    const updated = { ...config, ...patch };
    setConfig(updated);
    onUpdate(node.id, { config: updated });
  };

  const handleConfigChange = (key: string, value: any) => {
    updateConfig({ [key]: value });
  };

  const handleLabelChange = (newLabel: string) => {
    setLabel(newLabel);
    onUpdate(node.id, { label: newLabel });
  };

  const webhookUrl =
    node.data.nodeType === "webhookTrigger" && config.path
      ? `${window.location.origin}/api/webhook/${config.path}`
      : null;

  const supportedCredTypes = def?.supportedCredentials || [];
  const matchingCreds =
    credentials?.filter((c) => supportedCredTypes.includes(c.type)) || [];

  const nodeStep = lastRunSteps?.find((s) => s.nodeId === node.id);
  const displayResult = nodeTestResult || nodeStep;
  const isHttpRequest = node.data.nodeType === "httpRequest";

  const updateRows = (
    type: "query" | "header" | "form",
    nextRows: KeyValueRow[]
  ) => {
    const safeRows = nextRows.length > 0 ? nextRows : [makeRow()];

    if (type === "query") {
      setQueryRows(safeRows);
      updateConfig({
        queryParamsUi: safeRows,
        queryParams: rowsToObject(safeRows),
      });
      return;
    }

    if (type === "header") {
      setHeaderRows(safeRows);
      updateConfig({
        headersUi: safeRows,
        headers: rowsToObject(safeRows),
      });
      return;
    }

    setFormRows(safeRows);
    updateConfig({
      formBodyUi: safeRows,
      formBody: rowsToObject(safeRows),
    });
  };

  const addRow = (type: "query" | "header" | "form") => {
    if (type === "query") {
      updateRows("query", [...queryRows, makeRow()]);
      return;
    }
    if (type === "header") {
      updateRows("header", [...headerRows, makeRow()]);
      return;
    }
    updateRows("form", [...formRows, makeRow()]);
  };

  const updateRowField = (
    type: "query" | "header" | "form",
    rowId: string,
    key: "name" | "value",
    value: string
  ) => {
    const rows = type === "query" ? queryRows : type === "header" ? headerRows : formRows;
    const nextRows = rows.map((row) =>
      row.id === rowId ? { ...row, [key]: value } : row
    );
    updateRows(type, nextRows);
  };

  const removeRow = (type: "query" | "header" | "form", rowId: string) => {
    const rows = type === "query" ? queryRows : type === "header" ? headerRows : formRows;
    const nextRows = rows.filter((row) => row.id !== rowId);
    updateRows(type, nextRows);
  };

  const renderKeyValueEditor = (
    type: "query" | "header" | "form",
    title: string,
    rows: KeyValueRow[]
  ) => {
    return (
      <div className="space-y-3">
        <div className="rounded-xl border border-border">
          <div className="grid grid-cols-[1fr_1fr_48px] gap-3 border-b border-border px-3 py-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            <div>Name</div>
            <div>Value</div>
            <div></div>
          </div>

          <div className="divide-y divide-border">
            {rows.map((row) => (
              <div
                key={row.id}
                className="grid grid-cols-[1fr_1fr_48px] gap-3 px-3 py-3"
              >
                <Input
                  value={row.name}
                  onChange={(e) => updateRowField(type, row.id, "name", e.target.value)}
                  placeholder="name"
                  className="h-10 text-sm"
                />
                <Input
                  value={row.value}
                  onChange={(e) => updateRowField(type, row.id, "value", e.target.value)}
                  placeholder="value"
                  className="h-10 text-sm"
                />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="h-10 w-10 rounded-lg text-destructive"
                  onClick={() => removeRow(type, row.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </div>

        <Button
          type="button"
          variant="outline"
          className="h-10"
          onClick={() => addRow(type)}
        >
          <Plus className="w-4 h-4 mr-2" />
          Add {title}
        </Button>
      </div>
    );
  };

  const renderField = (field: any) => {
    if (field.type === "text") {
      return (
        <Input
          value={config[field.key] || field.defaultValue || ""}
          onChange={(e) => handleConfigChange(field.key, e.target.value)}
          placeholder={field.placeholder}
          className="h-10 text-sm"
          data-testid={`input-config-${field.key}`}
        />
      );
    }

    if (field.type === "number") {
      return (
        <Input
          type="number"
          value={config[field.key] ?? field.defaultValue ?? ""}
          onChange={(e) =>
            handleConfigChange(
              field.key,
              e.target.value === "" ? "" : Number(e.target.value)
            )
          }
          placeholder={field.placeholder}
          className="h-10 text-sm"
          data-testid={`input-config-${field.key}`}
        />
      );
    }

    if (field.type === "textarea") {
      return (
        <Textarea
          value={config[field.key] || field.defaultValue || ""}
          onChange={(e) => handleConfigChange(field.key, e.target.value)}
          placeholder={field.placeholder}
          className="min-h-[90px] resize-none text-sm"
          data-testid={`input-config-${field.key}`}
        />
      );
    }

    if (field.type === "code") {
      return (
        <Textarea
          value={config[field.key] || field.defaultValue || ""}
          onChange={(e) => handleConfigChange(field.key, e.target.value)}
          placeholder={field.placeholder}
          className="min-h-[180px] resize-y rounded-xl border-border bg-background font-mono text-sm text-foreground"
          spellCheck={false}
          data-testid={`input-config-${field.key}`}
        />
      );
    }

    if (field.type === "select" && field.options) {
      return (
        <Select
          value={config[field.key] || field.defaultValue || ""}
          onValueChange={(val) => handleConfigChange(field.key, val)}
        >
          <SelectTrigger
            className="h-10 text-sm"
            data-testid={`select-config-${field.key}`}
          >
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {field.options.map((opt: any) => (
              <SelectItem key={opt.value} value={opt.value} className="text-sm">
                {opt.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      );
    }

    if (field.type === "boolean") {
      return (
        <div className="flex items-center justify-between rounded-xl border border-border px-4 py-3">
          <span className="text-sm text-foreground">{field.label}</span>
          <Switch
            checked={config[field.key] ?? field.defaultValue ?? false}
            onCheckedChange={(val) => handleConfigChange(field.key, val)}
            data-testid={`switch-config-${field.key}`}
          />
        </div>
      );
    }

    if (field.type === "json") {
      return (
        <Textarea
          value={
            typeof config[field.key] === "object"
              ? JSON.stringify(config[field.key], null, 2)
              : config[field.key] || ""
          }
          onChange={(e) => {
            try {
              const parsed = JSON.parse(e.target.value);
              handleConfigChange(field.key, parsed);
            } catch {
              handleConfigChange(field.key, e.target.value);
            }
          }}
          placeholder={field.placeholder}
          className="min-h-[140px] resize-y rounded-xl border-border font-mono text-sm"
          data-testid={`input-config-${field.key}`}
        />
      );
    }

    return null;
  };

  const renderHttpRequestFields = () => {
    const methodField = def?.configFields.find((f) => f.key === "method");
    const urlField = def?.configFields.find((f) => f.key === "url");
    const authenticationField = def?.configFields.find((f) => f.key === "authentication");
    const queryParamsField = def?.configFields.find((f) => f.key === "queryParams");
    const headersField = def?.configFields.find((f) => f.key === "headers");
    const bodyContentTypeField = def?.configFields.find((f) => f.key === "bodyContentType");
    const jsonBodyField = def?.configFields.find((f) => f.key === "jsonBody");
    const rawBodyField = def?.configFields.find((f) => f.key === "rawBody");
    const formBodyField = def?.configFields.find((f) => f.key === "formBody");
    const timeoutField = def?.configFields.find((f) => f.key === "timeout");
    const responseFormatField = def?.configFields.find((f) => f.key === "responseFormat");
    const maxRetriesField = def?.configFields.find((f) => f.key === "maxRetries");
    const followRedirectsField = def?.configFields.find((f) => f.key === "followRedirects");

    const authValue = config.authentication || "none";
    const selectedCredentialId = node.data.credentialId || "_none";
    const selectedCredential =
      matchingCreds.find((cred) => cred.id === node.data.credentialId) || null;

    const sendQueryParams = !!config.sendQueryParams;
    const sendHeaders = !!config.sendHeaders;
    const sendBody = !!config.sendBody;
    const bodyContentType = config.bodyContentType || "json";
    const retryOnFail = !!config.retryOnFail;

    return (
      <div className="space-y-5">
        <Section title="Request" description="Configure request method and endpoint.">
          {methodField && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Method</Label>
              {renderField(methodField)}
            </div>
          )}

          {urlField && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">
                URL
                <span className="text-destructive ml-1">*</span>
              </Label>
              {renderField(urlField)}
            </div>
          )}
        </Section>

        <Section
          title="Authentication"
          description="Select how the request should be authenticated."
        >
          {authenticationField && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Authentication</Label>
              {renderField(authenticationField)}
            </div>
          )}

          {authValue === "credential" && (
            <div className="space-y-3">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Saved Credential</Label>
                <Select
                  value={selectedCredentialId}
                  onValueChange={(val) =>
                    onUpdate(node.id, {
                      credentialId: val === "_none" ? undefined : val,
                    })
                  }
                >
                  <SelectTrigger
                    className="h-10 text-sm"
                    data-testid="select-inline-credential"
                  >
                    <SelectValue placeholder="Select saved credential..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="_none" className="text-sm">
                      Select saved credential...
                    </SelectItem>
                    {matchingCreds.map((cred) => (
                      <SelectItem key={cred.id} value={cred.id} className="text-sm">
                        {cred.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {matchingCreds.length > 0 ? (
                <div className="rounded-xl border border-emerald-200 bg-emerald-50 px-4 py-3">
                  <p className="text-sm text-emerald-700">
                    {selectedCredential
                      ? `Saved credential selected: ${selectedCredential.name}`
                      : "Choose one of your saved credentials from the dropdown above."}
                  </p>
                </div>
              ) : (
                <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
                  <p className="text-sm text-amber-700">
                    No saved credentials found for this authentication type. Create one in the Credentials page.
                  </p>
                </div>
              )}
            </div>
          )}
        </Section>

        <Section
          title="Query Parameters"
          description="Attach query string parameters to the URL."
        >
          <div className="flex items-center justify-between rounded-xl border border-border px-4 py-3">
            <span className="text-sm text-foreground">Send Query Parameters</span>
            <Switch
              checked={sendQueryParams}
              onCheckedChange={(val) => handleConfigChange("sendQueryParams", val)}
            />
          </div>

          {sendQueryParams && (
            <>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Specify Query Parameters</Label>
                <Select
                  value={queryParamMode}
                  onValueChange={(val: "fields" | "json") => {
                    setQueryParamMode(val);
                    handleConfigChange("queryParamsMode", val);
                  }}
                >
                  <SelectTrigger className="h-10 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fields">Using Fields Below</SelectItem>
                    <SelectItem value="json">Using JSON</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {queryParamMode === "fields" ? (
                renderKeyValueEditor("query", "Parameter", queryRows)
              ) : queryParamsField ? (
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Query Parameters (JSON)</Label>
                  {renderField(queryParamsField)}
                </div>
              ) : null}
            </>
          )}
        </Section>

        <Section title="Headers" description="Add request headers.">
          <div className="flex items-center justify-between rounded-xl border border-border px-4 py-3">
            <span className="text-sm text-foreground">Send Headers</span>
            <Switch
              checked={sendHeaders}
              onCheckedChange={(val) => handleConfigChange("sendHeaders", val)}
            />
          </div>

          {sendHeaders && (
            <>
              <div className="space-y-2">
                <Label className="text-sm font-medium">Specify Headers</Label>
                <Select
                  value={headerMode}
                  onValueChange={(val: "fields" | "json") => {
                    setHeaderMode(val);
                    handleConfigChange("headersMode", val);
                  }}
                >
                  <SelectTrigger className="h-10 text-sm">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="fields">Using Fields Below</SelectItem>
                    <SelectItem value="json">Using JSON</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {headerMode === "fields" ? (
                renderKeyValueEditor("header", "Header", headerRows)
              ) : headersField ? (
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Headers (JSON)</Label>
                  {renderField(headersField)}
                </div>
              ) : null}
            </>
          )}
        </Section>

        <Section title="Body" description="Set request body and body type.">
          <div className="flex items-center justify-between rounded-xl border border-border px-4 py-3">
            <span className="text-sm text-foreground">Send Body</span>
            <Switch
              checked={sendBody}
              onCheckedChange={(val) => handleConfigChange("sendBody", val)}
            />
          </div>

          {sendBody && bodyContentTypeField && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Body Content Type</Label>
              {renderField(bodyContentTypeField)}
            </div>
          )}

          {sendBody && bodyContentType === "json" && jsonBodyField && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">JSON Body</Label>
              {renderField(jsonBodyField)}
            </div>
          )}

          {sendBody && bodyContentType === "raw" && rawBodyField && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Raw Body</Label>
              {renderField(rawBodyField)}
            </div>
          )}

          {sendBody &&
            (bodyContentType === "form-urlencoded" || bodyContentType === "form-data") && (
              <>
                <div className="space-y-2">
                  <Label className="text-sm font-medium">Specify Form Body</Label>
                  <Select
                    value={formBodyMode}
                    onValueChange={(val: "fields" | "json") => {
                      setFormBodyMode(val);
                      handleConfigChange("formBodyMode", val);
                    }}
                  >
                    <SelectTrigger className="h-10 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="fields">Using Fields Below</SelectItem>
                      <SelectItem value="json">Using JSON</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {formBodyMode === "fields" ? (
                  renderKeyValueEditor("form", "Field", formRows)
                ) : formBodyField ? (
                  <div className="space-y-2">
                    <Label className="text-sm font-medium">Form Body (JSON)</Label>
                    {renderField(formBodyField)}
                  </div>
                ) : null}
              </>
            )}
        </Section>

        <Section
          title="Options"
          description="Control timeout, retries and response handling."
        >
          <div className="grid grid-cols-2 gap-4">
            {timeoutField && (
              <div className="space-y-2">
                <Label className="text-sm font-medium">Timeout (ms)</Label>
                {renderField(timeoutField)}
              </div>
            )}

            {responseFormatField && (
              <div className="space-y-2">
                <Label className="text-sm font-medium">Response Format</Label>
                {renderField(responseFormatField)}
              </div>
            )}
          </div>

          <div className="flex items-center justify-between rounded-xl border border-border px-4 py-3">
            <span className="text-sm text-foreground">Retry On Fail</span>
            <Switch
              checked={retryOnFail}
              onCheckedChange={(val) => handleConfigChange("retryOnFail", val)}
            />
          </div>

          {retryOnFail && maxRetriesField && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Max Retries</Label>
              {renderField(maxRetriesField)}
            </div>
          )}

          {followRedirectsField && (
            <div className="space-y-2">
              <Label className="text-sm font-medium">Follow Redirects</Label>
              {renderField(followRedirectsField)}
            </div>
          )}
        </Section>
      </div>
    );
  };

  return (
    <Dialog open onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="max-w-[96vw] w-[96vw] h-[88vh] max-h-[88vh] p-0 overflow-hidden rounded-2xl border-border bg-background">
        <div className="h-full min-h-0 flex flex-col">
          <div className="h-14 shrink-0 border-b border-border px-4 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3 min-w-0">
              <div className="flex items-center gap-2 rounded-md border border-border px-3 py-1.5 bg-background">
                <span className="text-sm font-medium truncate">{label}</span>
              </div>
            </div>

            <div className="flex items-center gap-3 shrink-0">
              <Button variant="ghost" className="h-9 px-3 text-sm gap-2">
                <span>Docs</span>
                <ExternalLink className="w-4 h-4" />
              </Button>
              <Button
                size="icon"
                variant="ghost"
                className="h-9 w-9 rounded-md"
                onClick={onClose}
                data-testid="button-close-settings"
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>

          <div className="flex-1 min-h-0 h-0 grid grid-cols-[1fr_1.2fr_1fr]">
            <div className="border-r border-border flex flex-col min-h-0 h-full overflow-hidden">
              <div className="px-4 py-4 border-b border-border shrink-0">
                <h3 className="text-xs tracking-[0.18em] font-semibold text-muted-foreground uppercase">
                  Input
                </h3>
              </div>

              <div className="flex-1 min-h-0 overflow-y-auto">
                <div className="p-6">
                  {displayResult?.input ? (
                    <pre className="rounded-xl border border-border bg-accent/20 p-4 text-[11px] font-mono overflow-auto whitespace-pre-wrap break-words">
                      {JSON.stringify(displayResult.input, null, 2)}
                    </pre>
                  ) : (
                    <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-center px-6">
                      <div className="text-5xl text-muted-foreground/60">↦|</div>
                      <p className="mt-4 text-2xl font-semibold text-foreground">
                        No input data
                      </p>
                      <p className="mt-2 text-sm text-muted-foreground">
                        Execute previous nodes to view input data
                      </p>
                    </div>
                  )}
                </div>
              </div>
            </div>

            <Tabs
              value={activeTab}
              onValueChange={setActiveTab}
              className="flex flex-col min-h-0 h-full overflow-hidden"
            >
              <div className="border-b border-border px-4 pt-4 shrink-0">
                <div className="flex items-center justify-between gap-4">
                  <TabsList className="bg-muted">
                    <TabsTrigger value="parameters">Parameters</TabsTrigger>
                    <TabsTrigger value="settings">Settings</TabsTrigger>
                    {supportedCredTypes.length > 0 && (
                      <TabsTrigger value="credentials">Credentials</TabsTrigger>
                    )}
                  </TabsList>

                  {onTestNode && (
                    <Button
                      onClick={() => onTestNode(node.id)}
                      disabled={isTestingNode}
                      className="h-10 px-4 text-sm shrink-0"
                      data-testid="button-test-node"
                    >
                      {isTestingNode ? (
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      ) : (
                        <Play className="w-4 h-4 mr-2" />
                      )}
                      Execute step
                    </Button>
                  )}
                </div>
              </div>

              <TabsContent
                value="parameters"
                className="mt-0 flex-1 min-h-0 h-0 overflow-y-auto data-[state=inactive]:hidden"
              >
                <div className="p-6 space-y-5 pb-24">
                  {webhookUrl && (
                    <div className="rounded-xl border border-border bg-accent/30 p-3">
                      <Label className="text-xs text-muted-foreground">Webhook URL</Label>
                      <div className="mt-2 flex items-center gap-2">
                        <code className="flex-1 break-all rounded-md bg-background px-2 py-2 text-[11px] font-mono">
                          {webhookUrl}
                        </code>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-9 w-9 rounded-lg"
                          onClick={() => navigator.clipboard.writeText(webhookUrl)}
                          data-testid="button-copy-webhook"
                        >
                          <Copy className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  )}

                  {isHttpRequest ? (
                    renderHttpRequestFields()
                  ) : (
                    <>
                      {def?.configFields.map((field) => (
                        <div key={field.key} className="space-y-2">
                          <Label className="text-sm font-medium">
                            {field.label}
                            {field.required ? (
                              <span className="text-destructive ml-1">*</span>
                            ) : null}
                          </Label>
                          {renderField(field)}
                        </div>
                      ))}
                    </>
                  )}

                  <div className="flex gap-2 pt-4 border-t border-border">
                    <Button
                      variant="secondary"
                      size="sm"
                      onClick={() => onDuplicate(node.id)}
                      className="flex-1 h-10 text-sm"
                      data-testid="button-duplicate-node"
                    >
                      <Copy className="w-4 h-4 mr-2" />
                      Duplicate
                    </Button>

                    <Button
                      variant="destructive"
                      size="sm"
                      onClick={() => onDelete(node.id)}
                      className="flex-1 h-10 text-sm"
                      data-testid="button-delete-node"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete
                    </Button>
                  </div>
                </div>
              </TabsContent>

              <TabsContent
                value="settings"
                className="mt-0 flex-1 min-h-0 h-0 overflow-y-auto data-[state=inactive]:hidden"
              >
                <div className="p-6 space-y-5 pb-24">
                  <Section title="General" description="Configure node level settings.">
                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Node Name</Label>
                      <Input
                        value={label}
                        onChange={(e) => handleLabelChange(e.target.value)}
                        className="h-10 text-sm"
                        data-testid="input-node-name"
                      />
                    </div>

                    <div className="flex items-center justify-between rounded-xl border border-border px-4 py-3">
                      <Label className="text-sm font-medium">Disabled</Label>
                      <Switch
                        checked={node.data.disabled ?? false}
                        onCheckedChange={(val) => onUpdate(node.id, { disabled: val })}
                        data-testid="switch-disabled"
                      />
                    </div>

                    <div className="flex items-center justify-between rounded-xl border border-border px-4 py-3">
                      <Label className="text-sm font-medium">Continue on Fail</Label>
                      <Switch
                        checked={node.data.continueOnFail ?? false}
                        onCheckedChange={(val) =>
                          onUpdate(node.id, { continueOnFail: val })
                        }
                        data-testid="switch-continue-on-fail"
                      />
                    </div>

                    <div className="space-y-2">
                      <Label className="text-sm font-medium">Notes</Label>
                      <Textarea
                        value={node.data.notes || ""}
                        onChange={(e) => onUpdate(node.id, { notes: e.target.value })}
                        placeholder="Add notes about this node..."
                        className="min-h-[100px] resize-none text-sm"
                        data-testid="input-notes"
                      />
                    </div>

                    {def?.description ? (
                      <div className="rounded-xl border border-border bg-accent/20 p-3">
                        <p className="text-sm text-muted-foreground">{def.description}</p>
                      </div>
                    ) : null}
                  </Section>
                </div>
              </TabsContent>

              {supportedCredTypes.length > 0 && (
                <TabsContent
                  value="credentials"
                  className="mt-0 flex-1 min-h-0 h-0 overflow-y-auto data-[state=inactive]:hidden"
                >
                  <div className="p-6 space-y-5 pb-24">
                    <Section
                      title="Credentials"
                      description="Select a saved credential for this node."
                    >
                      <div className="space-y-2">
                        <Label className="text-sm font-medium">Credential</Label>
                        <Select
                          value={node.data.credentialId || "_none"}
                          onValueChange={(val) =>
                            onUpdate(node.id, {
                              credentialId: val === "_none" ? undefined : val,
                            })
                          }
                        >
                          <SelectTrigger
                            className="h-10 text-sm"
                            data-testid="select-credential"
                          >
                            <SelectValue placeholder="Select credential..." />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="_none" className="text-sm">
                              No credential
                            </SelectItem>
                            {matchingCreds.map((cred) => (
                              <SelectItem key={cred.id} value={cred.id} className="text-sm">
                                {cred.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>

                        <p className="text-xs text-muted-foreground">
                          Supported types:{" "}
                          {supportedCredTypes.map((t) => t.replace(/_/g, " ")).join(", ")}
                        </p>

                        {matchingCreds.length === 0 ? (
                          <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-3">
                            <p className="text-sm text-amber-700">
                              No matching credentials found. Create one in the Credentials page.
                            </p>
                          </div>
                        ) : null}
                      </div>
                    </Section>
                  </div>
                </TabsContent>
              )}
            </Tabs>

            <div className="border-l border-border flex flex-col min-h-0 h-full overflow-hidden">
              <div className="px-4 py-4 border-b border-border flex items-center justify-between shrink-0">
                <h3 className="text-xs tracking-[0.18em] font-semibold text-muted-foreground uppercase">
                  Output
                </h3>
                <Button size="icon" variant="outline" className="h-10 w-10 rounded-lg">
                  <Pencil className="w-4 h-4" />
                </Button>
              </div>

              <div className="flex-1 min-h-0 overflow-y-auto">
                <div className="p-6">
                  {displayResult?.output ? (
                    <pre
                      className="rounded-xl border border-border bg-accent/20 p-4 text-[11px] font-mono overflow-auto whitespace-pre-wrap break-words"
                      data-testid="text-node-output"
                    >
                      {JSON.stringify(displayResult.output, null, 2)}
                    </pre>
                  ) : (
                    <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-center px-6">
                      <div className="text-5xl text-muted-foreground/60">|↦</div>
                      <p className="mt-4 text-2xl font-semibold text-foreground">
                        No output data
                      </p>
                      <div className="mt-5 flex items-center gap-2">
                        {onTestNode ? (
                          <Button
                            onClick={() => onTestNode(node.id)}
                            disabled={isTestingNode}
                            variant="outline"
                            className="h-10 px-4"
                          >
                            {isTestingNode ? (
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                            ) : (
                              <Play className="w-4 h-4 mr-2" />
                            )}
                            Execute step
                          </Button>
                        ) : null}
                      </div>
                    </div>
                  )}

                  {displayResult?.error ? (
                    <div className="mt-4 rounded-xl border border-destructive/20 bg-destructive/10 p-3 text-[11px] font-mono text-destructive">
                      {displayResult.error}
                    </div>
                  ) : null}
                </div>
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}