import { ScrollArea } from "@/components/ui/scroll-area";
import { Badge } from "@/components/ui/badge";
import {
  CheckCircle2,
  XCircle,
  Clock,
  Loader2,
  ChevronDown,
  ChevronRight,
} from "lucide-react";
import { useMemo, useState } from "react";
import type { WorkflowRun, StepLog } from "@shared/schema";

interface ExecutionPanelProps {
  run: WorkflowRun | null;
  isRunning?: boolean;
}

function StepItem({ step }: { step: StepLog }) {
  const [expanded, setExpanded] = useState(false);

  const statusIcon = {
    success: <CheckCircle2 className="w-4 h-4 text-green-500" />,
    error: <XCircle className="w-4 h-4 text-red-500" />,
    running: <Loader2 className="w-4 h-4 text-blue-500 animate-spin" />,
    skipped: <Clock className="w-4 h-4 text-muted-foreground" />,
  };

  return (
    <div
      className="rounded-xl border border-border bg-background shadow-sm"
      data-testid={`step-log-${step.nodeId}`}
    >
      <button
        className="flex w-full items-center gap-3 px-4 py-3 text-left"
        onClick={() => setExpanded(!expanded)}
        data-testid={`button-expand-step-${step.nodeId}`}
      >
        {expanded ? (
          <ChevronDown className="w-4 h-4 text-muted-foreground shrink-0" />
        ) : (
          <ChevronRight className="w-4 h-4 text-muted-foreground shrink-0" />
        )}

        <div className="shrink-0">
          {statusIcon[step.status]}
        </div>

        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-medium text-foreground">
            {step.nodeLabel || "Unnamed step"}
          </p>
          <p className="mt-0.5 text-xs text-muted-foreground">
            {step.nodeType || "Unknown type"}
          </p>
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Badge
            variant={
              step.status === "success"
                ? "secondary"
                : step.status === "error"
                ? "destructive"
                : "secondary"
            }
            className="text-[10px]"
          >
            {step.status}
          </Badge>

          {step.branch && (
            <Badge variant="outline" className="text-[10px]">
              {step.branch}
            </Badge>
          )}
        </div>
      </button>

      {expanded && (
        <div className="border-t border-border px-4 py-4 space-y-4">
          {step.error && (
            <div className="rounded-xl border border-destructive/20 bg-destructive/10 p-3 text-[11px] font-mono text-destructive">
              {step.error}
            </div>
          )}

          <div className="grid grid-cols-1 gap-4 xl:grid-cols-2">
            <div>
              <p className="mb-1.5 text-xs font-semibold uppercase text-muted-foreground">
                Input
              </p>
              <pre className="max-h-40 overflow-auto rounded-xl border border-border bg-accent/20 p-3 text-[11px] font-mono">
                {JSON.stringify(step.input ?? null, null, 2)}
              </pre>
            </div>

            <div>
              <p className="mb-1.5 text-xs font-semibold uppercase text-muted-foreground">
                Output
              </p>
              <pre className="max-h-40 overflow-auto rounded-xl border border-border bg-accent/20 p-3 text-[11px] font-mono">
                {JSON.stringify(step.output ?? null, null, 2)}
              </pre>
            </div>
          </div>

          <div className="flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
            <span>Type: {step.nodeType || "Unknown"}</span>
            {step.startedAt && (
              <span>Start: {new Date(step.startedAt).toLocaleTimeString()}</span>
            )}
            {step.finishedAt && (
              <span>End: {new Date(step.finishedAt).toLocaleTimeString()}</span>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

export function ExecutionPanel({ run, isRunning }: ExecutionPanelProps) {
  const steps = useMemo<StepLog[]>(() => {
    if (!run) return [];
    if (Array.isArray(run.steps)) return run.steps;
    return [];
  }, [run]);

  if (!run && !isRunning) {
    return (
      <div
        className="h-full flex flex-col bg-background"
        data-testid="panel-execution"
      >
        <div className="flex items-center justify-between px-4 py-3 border-b border-border">
          <h3 className="text-sm font-semibold text-foreground">
            Execution
          </h3>
        </div>

        <div className="flex-1 flex items-center justify-center px-6">
          <p className="text-sm text-muted-foreground text-center">
            No execution yet. Run the workflow to see results.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="h-full flex flex-col bg-background"
      data-testid="panel-execution"
    >
      <div className="flex items-center justify-between gap-3 px-4 py-3 border-b border-border">
        <h3 className="text-sm font-semibold text-foreground">
          Execution
        </h3>

        {run && (
          <div className="flex items-center gap-2">
            <Badge
              variant={
                run.status === "success"
                  ? "secondary"
                  : run.status === "error"
                  ? "destructive"
                  : "secondary"
              }
              className="text-[10px]"
            >
              {isRunning ? "Running..." : run.status}
            </Badge>

            <span className="text-xs text-muted-foreground">
              {run.triggerType || "manual"}
            </span>
          </div>
        )}
      </div>

      <ScrollArea className="flex-1">
        <div className="p-4 space-y-3">
          {isRunning && steps.length === 0 && (
            <div className="flex items-center gap-3 rounded-xl border border-border bg-background p-4">
              <Loader2 className="w-4 h-4 animate-spin text-primary" />
              <span className="text-sm text-muted-foreground">
                Executing workflow...
              </span>
            </div>
          )}

          {steps.map((step, i) => (
            <StepItem key={`${step.nodeId || "step"}-${i}`} step={step} />
          ))}

          {run?.error && (
            <div className="rounded-xl border border-destructive/20 bg-destructive/10 p-3 text-sm font-mono text-destructive">
              {run.error}
            </div>
          )}

          {!isRunning && run && steps.length === 0 && !run.error && (
            <div className="rounded-xl border border-border bg-background p-4 text-sm text-muted-foreground">
              No step logs available for this run.
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  );
}