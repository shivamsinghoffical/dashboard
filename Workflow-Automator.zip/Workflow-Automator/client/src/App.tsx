import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Workflows from "@/pages/workflows";
import Builder from "@/pages/builder";
import RunHistory from "@/pages/run-history";
import Templates from "@/pages/templates";
import Credentials from "@/pages/credentials";
import { useEffect } from "react";

function ThemeToggle() {
  useEffect(() => {
    document.documentElement.classList.remove("dark");
    document.body.classList.remove("dark");
  }, []);

  return null;
}

function AppLayout({ children }: { children: React.ReactNode }) {
  const style = {
    "--sidebar-width": "13rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <SidebarProvider style={style as React.CSSProperties}>
      <div className="flex h-screen w-full bg-background text-foreground">
        <AppSidebar />
        <div className="flex flex-col flex-1 overflow-hidden">
          <div className="flex items-center gap-2 p-2 border-b border-border bg-card/30">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
          </div>
          <main className="flex-1 overflow-auto">
            {children}
          </main>
        </div>
      </div>
    </SidebarProvider>
  );
}

function BuilderLayout() {
  return (
    <div className="h-screen w-full overflow-hidden bg-background text-foreground">
      <Builder />
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/">
        <AppLayout><Dashboard /></AppLayout>
      </Route>
      <Route path="/workflows">
        <AppLayout><Workflows /></AppLayout>
      </Route>
      <Route path="/builder/:id">
        <BuilderLayout />
      </Route>
      <Route path="/runs">
        <AppLayout><RunHistory /></AppLayout>
      </Route>
      <Route path="/credentials">
        <AppLayout><Credentials /></AppLayout>
      </Route>
      <Route path="/templates">
        <AppLayout><Templates /></AppLayout>
      </Route>
      <Route>
        <AppLayout><NotFound /></AppLayout>
      </Route>
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <ThemeToggle />
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;