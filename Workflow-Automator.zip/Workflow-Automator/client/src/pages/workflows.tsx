import { useMemo, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Plus,
  MoreVertical,
  GitBranch,
  Trash2,
  Copy,
  Pencil,
  Sparkles,
  Search,
  ChevronDown,
  Filter,
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { Workflow } from "@shared/schema";

type StatusFilter = "all" | "active" | "draft";
type SortMode = "updatedDesc" | "updatedAsc" | "nameAsc";

function formatDateTime(value?: string) {
  if (!value) return "Unknown";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Unknown";
  return date.toLocaleString([], {
    month: "short",
    day: "numeric",
    year: "numeric",
  });
}

function getStatusPillClass(status: Workflow["status"]) {
  return status === "active"
    ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-700"
    : "border-amber-300/70 bg-amber-500/10 text-amber-700";
}

export default function Workflows() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<StatusFilter>("all");
  const [sortMode, setSortMode] = useState<SortMode>("updatedDesc");

  const { data: workflows = [], isLoading } = useQuery<Workflow[]>({
    queryKey: ["/api/workflows"],
  });

  const createMutation = useMutation({
    mutationFn: () => apiRequest("POST", "/api/workflows", { name: "Untitled Workflow" }),
    onSuccess: async (res) => {
      const workflow = await res.json();
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      navigate(`/builder/${workflow.id}`);
    },
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/workflows/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Workflow deleted" });
    },
  });

  const duplicateMutation = useMutation({
    mutationFn: (id: string) => apiRequest("POST", `/api/workflows/${id}/duplicate`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Workflow duplicated" });
    },
  });

  const activeCount = workflows.filter((workflow) => workflow.status === "active").length;
  const draftCount = workflows.length - activeCount;

  const visibleWorkflows = useMemo(() => {
    const searchValue = search.trim().toLowerCase();

    let result = workflows.filter((workflow) => {
      const matchesSearch = !searchValue
        ? true
        : (workflow.name || "").toLowerCase().includes(searchValue);
      const matchesStatus =
        statusFilter === "all" ? true : workflow.status === statusFilter;
      return matchesSearch && matchesStatus;
    });

    result = [...result].sort((a, b) => {
      if (sortMode === "nameAsc") {
        return (a.name || "").localeCompare(b.name || "");
      }

      const aTime = new Date(a.updatedAt).getTime() || 0;
      const bTime = new Date(b.updatedAt).getTime() || 0;
      return sortMode === "updatedAsc" ? aTime - bTime : bTime - aTime;
    });

    return result;
  }, [workflows, search, statusFilter, sortMode]);

  if (isLoading) {
    return (
      <div className="min-h-full bg-background px-6 py-5" data-testid="page-workflows-loading">
        <div className="mx-auto max-w-[1320px] space-y-5">
          <Skeleton className="h-44 w-full rounded-3xl" />
          <Skeleton className="h-14 w-full rounded-2xl" />
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="rounded-2xl">
                <CardContent className="p-5">
                  <Skeleton className="h-24 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-full bg-[radial-gradient(1100px_420px_at_8%_-8%,rgba(56,189,248,0.15),transparent_58%),radial-gradient(1200px_420px_at_94%_6%,rgba(16,185,129,0.10),transparent_54%),hsl(var(--background))] px-6 py-5"
      data-testid="page-workflows"
    >
      <div className="mx-auto max-w-[1320px] space-y-5">
        <section className="relative overflow-hidden rounded-3xl border border-border/70 bg-card/90 p-6 shadow-sm">
          <div className="pointer-events-none absolute -top-20 -left-14 h-52 w-52 rounded-full bg-cyan-400/15 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-20 -right-8 h-52 w-52 rounded-full bg-emerald-400/15 blur-3xl" />

          <div className="relative flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-background/70 px-3 py-1 text-xs font-semibold tracking-[0.12em] uppercase text-muted-foreground">
                <Sparkles className="h-3.5 w-3.5 text-cyan-600" />
                Workflow Studio
              </div>
              <h1 className="mt-3 text-3xl font-semibold tracking-tight text-foreground">
                Manage automation workflows
              </h1>
              <p className="mt-1.5 text-sm text-muted-foreground">
                {workflows.length} total, {activeCount} active, {draftCount} draft
              </p>
            </div>

            <Button
              onClick={() => createMutation.mutate()}
              disabled={createMutation.isPending}
              className="h-10 rounded-xl bg-gradient-to-r from-cyan-600 to-emerald-600 px-4 text-white hover:from-cyan-700 hover:to-emerald-700"
              data-testid="button-create-workflow"
            >
              <Plus className="mr-2 h-4 w-4" />
              Create Workflow
            </Button>
          </div>
        </section>

        <Card className="rounded-2xl border border-border/70 bg-card/85 shadow-sm">
          <CardContent className="p-3">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div className="relative min-w-[260px]">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search workflows..."
                  className="h-10 rounded-xl pl-10"
                  data-testid="input-search-workflows"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant={statusFilter === "all" ? "default" : "outline"}
                  className="h-9 rounded-xl"
                  onClick={() => setStatusFilter("all")}
                  data-testid="button-filter-all"
                >
                  All
                </Button>
                <Button
                  variant={statusFilter === "active" ? "default" : "outline"}
                  className="h-9 rounded-xl"
                  onClick={() => setStatusFilter("active")}
                  data-testid="button-filter-active"
                >
                  Active
                </Button>
                <Button
                  variant={statusFilter === "draft" ? "default" : "outline"}
                  className="h-9 rounded-xl"
                  onClick={() => setStatusFilter("draft")}
                  data-testid="button-filter-draft"
                >
                  Draft
                </Button>
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="outline"
                    className="h-10 min-w-[210px] justify-between rounded-xl px-4 text-sm font-normal"
                    data-testid="button-sort-workflows"
                  >
                    {sortMode === "updatedDesc"
                      ? "Sort: Last updated"
                      : sortMode === "updatedAsc"
                        ? "Sort: Oldest updated"
                        : "Sort: Name A-Z"}
                    <ChevronDown className="ml-3 h-4 w-4 text-muted-foreground" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuItem onClick={() => setSortMode("updatedDesc")}>
                    <Filter className="mr-2 h-4 w-4" />
                    Last updated
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortMode("updatedAsc")}>
                    <Filter className="mr-2 h-4 w-4" />
                    Oldest updated
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => setSortMode("nameAsc")}>
                    <Filter className="mr-2 h-4 w-4" />
                    Name A-Z
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </CardContent>
        </Card>

        {visibleWorkflows.length === 0 ? (
          <Card className="rounded-2xl border border-dashed border-border/80 bg-card/60">
            <CardContent className="flex flex-col items-center justify-center py-16 text-center">
              <GitBranch className="mb-4 h-11 w-11 text-muted-foreground" />
              <h3 className="text-lg font-semibold text-foreground">
                {workflows.length === 0 ? "No workflows yet" : "No matching workflows"}
              </h3>
              <p className="mt-1.5 text-sm text-muted-foreground">
                {workflows.length === 0
                  ? "Create your first workflow to get started."
                  : "Try changing search or filters."}
              </p>
              <Button
                onClick={() => createMutation.mutate()}
                className="mt-5 h-10 rounded-xl px-4"
                data-testid="button-create-first"
              >
                <Plus className="mr-2 h-4 w-4" />
                Create Workflow
              </Button>
            </CardContent>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-3">
            {visibleWorkflows.map((workflow) => (
              <Card
                key={workflow.id}
                className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card/90 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
              >
                <div className="pointer-events-none absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-cyan-500 to-emerald-500" />
                <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-cyan-500/[0.05] to-emerald-500/[0.02] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

                <CardContent className="relative p-4 pl-5">
                  <div className="flex items-start justify-between gap-2">
                    <Link href={`/builder/${workflow.id}`} className="flex-1 min-w-0">
                      <div className="cursor-pointer" data-testid={`link-workflow-${workflow.id}`}>
                        <div className="mb-2 flex items-center gap-2">
                          <div className="flex h-7 w-7 items-center justify-center rounded-md border border-border/70 bg-background/80">
                            <GitBranch className="h-4 w-4 text-muted-foreground" />
                          </div>
                          <h3 className="truncate text-base font-semibold text-foreground">
                            {workflow.name || "Untitled Workflow"}
                          </h3>
                        </div>
                        <div className="mt-2 flex flex-wrap items-center gap-1.5">
                          <Badge
                            variant="outline"
                            className={`rounded-full px-2.5 py-1 text-[10px] ${getStatusPillClass(
                              workflow.status,
                            )}`}
                          >
                            {workflow.status}
                          </Badge>
                          <Badge variant="outline" className="rounded-full px-2.5 py-1 text-[10px]">
                            {workflow.nodes.length} nodes
                          </Badge>
                          <Badge variant="outline" className="rounded-full px-2.5 py-1 text-[10px]">
                            Updated {formatDateTime(workflow.updatedAt)}
                          </Badge>
                        </div>
                      </div>
                    </Link>

                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button
                          size="icon"
                          variant="ghost"
                          className="h-8 w-8 rounded-md"
                          data-testid={`button-menu-${workflow.id}`}
                        >
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem onClick={() => navigate(`/builder/${workflow.id}`)}>
                          <Pencil className="mr-2 h-3.5 w-3.5" />
                          Edit
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => duplicateMutation.mutate(workflow.id)}>
                          <Copy className="mr-2 h-3.5 w-3.5" />
                          Duplicate
                        </DropdownMenuItem>
                        <DropdownMenuItem
                          onClick={() => {
                            const ok = window.confirm(
                              `Delete workflow "${workflow.name || "Untitled Workflow"}"?`,
                            );
                            if (ok) {
                              deleteMutation.mutate(workflow.id);
                            }
                          }}
                          className="text-destructive"
                        >
                          <Trash2 className="mr-2 h-3.5 w-3.5" />
                          Delete
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
