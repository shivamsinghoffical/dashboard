import { useMemo, useState, type CSSProperties } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link, useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  GitBranch,
  Play,
  CheckCircle2,
  XCircle,
  Plus,
  Search,
  ChevronDown,
  Filter,
  MoreVertical,
  User,
  Pencil,
  Copy,
  Trash2,
  Sparkles,
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { DashboardStats } from "@shared/schema";

function formatDateTime(value?: string) {
  if (!value) return "Unknown time";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Unknown time";
  return date.toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function getRunStatusStyles(status?: string) {
  if (status === "success") {
    return "border-emerald-300/60 bg-emerald-500/10 text-emerald-700";
  }
  if (status === "error") {
    return "border-rose-300/60 bg-rose-500/10 text-rose-700";
  }
  if (status === "running") {
    return "border-amber-300/60 bg-amber-500/10 text-amber-700";
  }
  return "border-border bg-muted/30 text-muted-foreground";
}

function getWorkflowStatusStyles(status?: string) {
  return status === "active"
    ? "border-emerald-300/60 bg-emerald-500/10 text-emerald-700"
    : "border-amber-300/60 bg-amber-500/10 text-amber-700";
}

export default function Dashboard() {
  const { data: stats, isLoading } = useQuery<DashboardStats>({
    queryKey: ["/api/dashboard"],
  });

  const [search, setSearch] = useState("");
  const [location, setLocation] = useLocation();
  const { toast } = useToast();

  const workflows = stats?.recentWorkflows || [];
  const runs = stats?.recentRuns || [];

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/workflows/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      toast({ title: "Workflow deleted" });
    },
    onError: (error: any) => {
      toast({
        title: "Delete failed",
        description: error?.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const duplicateMutation = useMutation({
    mutationFn: (id: string) => apiRequest("POST", `/api/workflows/${id}/duplicate`),
    onSuccess: async (res) => {
      const workflow = await res.json();
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      toast({ title: "Workflow duplicated" });
      setLocation(`/builder/${workflow.id}`);
    },
    onError: (error: any) => {
      toast({
        title: "Duplicate failed",
        description: error?.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const filteredWorkflows = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return workflows;
    return workflows.filter((w) => (w.name || "").toLowerCase().includes(q));
  }, [workflows, search]);

  const latestRunByWorkflow = useMemo(() => {
    const byWorkflow = new Map<string, (typeof runs)[number]>();
    for (const run of runs) {
      if (!run?.workflowId || byWorkflow.has(run.workflowId)) continue;
      byWorkflow.set(run.workflowId, run);
    }
    return byWorkflow;
  }, [runs]);

  const totalRuns = stats?.totalRuns || 0;
  const successRuns = stats?.successfulRuns || 0;
  const failedRuns = stats?.failedRuns || 0;
  const totalWorkflows = stats?.totalWorkflows || 0;
  const activeWorkflows = workflows.filter((w) => w.status === "active").length;
  const successRate = totalRuns > 0 ? Math.round((successRuns / totalRuns) * 100) : 0;
  const activeRate = totalWorkflows > 0 ? Math.round((activeWorkflows / totalWorkflows) * 100) : 0;
  const maturityScore = Math.min(99, Math.round(successRate * 0.68 + activeRate * 0.32));
  const healthyRuns = Math.max(0, totalRuns - failedRuns);
  const avgRunsPerWorkflow =
    totalWorkflows > 0 ? (totalRuns / totalWorkflows).toFixed(1) : "0.0";

  const pageTheme = {
    "--dash-cyan": "14 165 233",
    "--dash-green": "16 185 129",
    "--dash-amber": "245 158 11",
    "--dash-ink": "15 23 42",
    fontFamily: "\"Plus Jakarta Sans\", \"DM Sans\", sans-serif",
    backgroundImage:
      "radial-gradient(1300px 550px at 8% -10%, rgb(var(--dash-cyan) / 0.18), transparent 55%), radial-gradient(1300px 550px at 92% 8%, rgb(var(--dash-green) / 0.14), transparent 52%), linear-gradient(hsl(var(--background)), hsl(var(--background)))",
  } as CSSProperties;

  const opsStrip = [
    {
      label: "Healthy Runs",
      value: healthyRuns,
      hint: `${successRuns} success / ${failedRuns} failed`,
      tone: "from-emerald-500/20 to-teal-500/10",
    },
    {
      label: "Avg Runs / Workflow",
      value: avgRunsPerWorkflow,
      hint: `${totalWorkflows} workflows in portfolio`,
      tone: "from-cyan-500/20 to-indigo-500/10",
    },
    {
      label: "Automation Maturity",
      value: `${maturityScore}%`,
      hint: "Blended score from quality + adoption",
      tone: "from-amber-500/20 to-orange-500/10",
    },
  ];

  if (isLoading) {
    return (
      <div className="min-h-full px-6 py-5" style={pageTheme} data-testid="page-dashboard-loading">
        <div className="mx-auto max-w-[1360px] space-y-6">
          <Skeleton className="h-56 w-full rounded-3xl" />
          <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="rounded-2xl">
                <CardContent className="p-5">
                  <Skeleton className="h-24 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
          <Skeleton className="h-16 w-full rounded-2xl" />
          <div className="grid gap-4 xl:grid-cols-[minmax(0,1fr)_360px]">
            <Skeleton className="h-[430px] w-full rounded-2xl" />
            <Skeleton className="h-[430px] w-full rounded-2xl" />
          </div>
        </div>
      </div>
    );
  }

  const statCards = [
    {
      label: "Total Workflows",
      value: totalWorkflows,
      icon: GitBranch,
      accent: "from-sky-500/20 to-cyan-500/10",
      iconClass: "text-sky-700",
      hint: `${activeWorkflows} currently active`,
    },
    {
      label: "Total Runs",
      value: totalRuns,
      icon: Play,
      accent: "from-indigo-500/20 to-violet-500/10",
      iconClass: "text-indigo-700",
      hint: "Total executions logged",
    },
    {
      label: "Successful",
      value: successRuns,
      icon: CheckCircle2,
      accent: "from-emerald-500/20 to-teal-500/10",
      iconClass: "text-emerald-700",
      hint: `${successRate}% success performance`,
    },
    {
      label: "Failed",
      value: failedRuns,
      icon: XCircle,
      accent: "from-rose-500/20 to-red-500/10",
      iconClass: "text-rose-700",
      hint: `${Math.max(0, 100 - successRate)}% failure band`,
    },
  ];

  const isWorkflowsTab = location === "/" || location === "/workflows";
  const isCredentialsTab = location === "/credentials";
  const isRunsTab = location === "/runs";

  return (
    <div className="min-h-full px-6 py-5" style={pageTheme} data-testid="page-dashboard">
      <div className="mx-auto max-w-[1360px] space-y-6">
        <section className="relative overflow-hidden rounded-[30px] border border-border/70 bg-card/90 p-6 shadow-[0_20px_60px_rgba(2,8,23,0.08)] backdrop-blur-xl md:p-7">
          <div className="pointer-events-none absolute -top-20 -left-16 h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-24 -right-10 h-56 w-56 rounded-full bg-emerald-400/20 blur-3xl" />

          <div className="relative">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-background/70 px-3 py-1 text-xs font-semibold tracking-[0.12em] text-muted-foreground uppercase">
                <Sparkles className="h-3.5 w-3.5 text-cyan-600" />
                Premium Automation Command Center
              </div>

              <h1 className="mt-4 text-3xl font-semibold tracking-tight text-foreground md:text-5xl">
                Run your automation business like a control tower
              </h1>

              <p className="mt-2 max-w-3xl text-sm text-muted-foreground md:text-base">
                Design workflows faster, monitor execution quality in real time, and keep every
                integration stable from one premium operations dashboard.
              </p>

              <div className="mt-5">
                <Link href="/builder/new">
                  <Button
                    className="h-10 rounded-xl bg-gradient-to-r from-cyan-600 to-emerald-600 px-4 text-white shadow-sm hover:from-cyan-700 hover:to-emerald-700"
                    data-testid="button-create-workflow"
                  >
                    <Plus className="mr-2 h-4 w-4" />
                    Create Workflow
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        <div className="grid grid-cols-1 gap-4 md:grid-cols-2 xl:grid-cols-4">
          {statCards.map((stat) => (
            <Card
              key={stat.label}
              className="overflow-hidden rounded-2xl border border-border/70 bg-card/85 shadow-sm"
            >
              <CardContent className="relative p-5">
                <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${stat.accent}`} />
                <div className="relative flex items-start justify-between gap-3">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">{stat.label}</p>
                    <p
                      className="mt-2 text-4xl font-semibold tracking-tight text-foreground"
                      data-testid={`stat-${stat.label.toLowerCase().replace(/\s/g, "-")}`}
                    >
                      {stat.value}
                    </p>
                    <p className="mt-2 text-xs text-muted-foreground">{stat.hint}</p>
                  </div>

                  <div className="flex h-11 w-11 items-center justify-center rounded-xl border border-border/60 bg-background/80 shadow-sm">
                    <stat.icon className={`h-5 w-5 ${stat.iconClass}`} />
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          {opsStrip.map((item) => (
            <Card
              key={item.label}
              className="overflow-hidden rounded-2xl border border-border/70 bg-card/90 shadow-sm"
            >
              <CardContent className="relative p-4">
                <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${item.tone}`} />
                <div className="relative">
                  <p className="text-xs font-semibold uppercase tracking-[0.14em] text-muted-foreground">
                    {item.label}
                  </p>
                  <p className="mt-1 text-2xl font-semibold text-foreground">{item.value}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{item.hint}</p>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="rounded-2xl border border-border/70 bg-card/75 p-3 shadow-sm">
          <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
            <div className="flex flex-wrap items-center gap-2">
              <Link href="/workflows">
                <button
                  className={`rounded-xl px-3 py-2 text-sm font-medium transition ${
                    isWorkflowsTab
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                  data-testid="tab-workflows"
                >
                  Workflows
                </button>
              </Link>

              <Link href="/credentials">
                <button
                  className={`rounded-xl px-3 py-2 text-sm font-medium transition ${
                    isCredentialsTab
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                  data-testid="tab-credentials"
                >
                  Credentials
                </button>
              </Link>

              <Link href="/runs">
                <button
                  className={`rounded-xl px-3 py-2 text-sm font-medium transition ${
                    isRunsTab
                      ? "bg-primary text-primary-foreground shadow-sm"
                      : "text-muted-foreground hover:bg-muted hover:text-foreground"
                  }`}
                  data-testid="tab-executions"
                >
                  Run History
                </button>
              </Link>
            </div>

            <div className="flex flex-col gap-2.5 sm:flex-row sm:items-center">
              <div className="relative min-w-[240px]">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search workflows..."
                  className="h-10 rounded-xl border-border/70 bg-background/80 pl-10 text-sm"
                  data-testid="input-search-workflows"
                />
              </div>

              <Button
                variant="outline"
                className="h-10 min-w-[200px] justify-between rounded-xl border-border/70 px-4 text-sm font-normal"
                data-testid="button-sort-workflows"
              >
                Sort by last updated
                <ChevronDown className="ml-3 h-4 w-4 text-muted-foreground" />
              </Button>

              <Button
                variant="outline"
                size="icon"
                className="h-10 w-10 rounded-xl border-border/70"
                data-testid="button-filter-workflows"
              >
                <Filter className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {filteredWorkflows.length > 0 ? (
            filteredWorkflows.map((w) => {
              const latestRun = latestRunByWorkflow.get(w.id);

              return (
                <Link key={w.id} href={`/builder/${w.id}`}>
                  <Card
                    className="group relative cursor-pointer overflow-hidden rounded-2xl border border-border/70 bg-card/90 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
                    data-testid={`workflow-row-${w.id}`}
                  >
                    <div className="pointer-events-none absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-cyan-500 to-emerald-500" />
                    <div className="pointer-events-none absolute inset-0 bg-gradient-to-r from-cyan-500/[0.06] to-emerald-500/[0.03] opacity-0 transition-opacity duration-300 group-hover:opacity-100" />

                    <CardContent className="flex items-start justify-between gap-4 p-4 pl-5">
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2.5">
                          <div className="flex h-8 w-8 items-center justify-center rounded-lg border border-border/70 bg-background/80">
                            <GitBranch className="h-4 w-4 text-muted-foreground" />
                          </div>

                          <h3 className="truncate text-xl font-semibold text-foreground">
                            {w.name || "Untitled Workflow"}
                          </h3>
                        </div>

                        <div className="mt-3 flex flex-wrap items-center gap-2 pl-10">
                          <Badge
                            className={`rounded-full px-2.5 py-1 text-[11px] ${getWorkflowStatusStyles(
                              w.status,
                            )}`}
                          >
                            {w.status === "active" ? "Active" : "Draft"}
                          </Badge>

                          <Badge variant="outline" className="rounded-full px-2.5 py-1 text-[11px]">
                            {w.nodes?.length || 0} nodes
                          </Badge>

                          <Badge variant="outline" className="rounded-full px-2.5 py-1 text-[11px]">
                            Updated {formatDateTime(w.updatedAt)}
                          </Badge>

                          {latestRun ? (
                            <Badge
                              variant="outline"
                              className={`rounded-full px-2.5 py-1 text-[11px] ${getRunStatusStyles(
                                latestRun.status,
                              )}`}
                            >
                              Last run: {latestRun.status}
                            </Badge>
                          ) : (
                            <Badge variant="outline" className="rounded-full px-2.5 py-1 text-[11px]">
                              No runs yet
                            </Badge>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center gap-2">
                        <Badge
                          variant="outline"
                          className="hidden items-center gap-1.5 rounded-full px-2.5 py-1.5 text-xs md:flex"
                        >
                          <User className="h-3.5 w-3.5" />
                          Personal
                        </Badge>

                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 rounded-md"
                              data-testid={`button-workflow-menu-${w.id}`}
                              onClick={(e) => e.preventDefault()}
                            >
                              <MoreVertical className="h-4 w-4" />
                            </Button>
                          </DropdownMenuTrigger>

                          <DropdownMenuContent align="end" className="w-44">
                            <DropdownMenuItem
                              onClick={(e) => {
                                e.preventDefault();
                                setLocation(`/builder/${w.id}`);
                              }}
                              className="cursor-pointer"
                            >
                              <Pencil className="mr-2 h-4 w-4" />
                              Edit
                            </DropdownMenuItem>

                            <DropdownMenuItem
                              onClick={(e) => {
                                e.preventDefault();
                                duplicateMutation.mutate(w.id);
                              }}
                              className="cursor-pointer"
                              disabled={duplicateMutation.isPending}
                            >
                              <Copy className="mr-2 h-4 w-4" />
                              Duplicate
                            </DropdownMenuItem>

                            <DropdownMenuItem
                              onClick={(e) => {
                                e.preventDefault();
                                const ok = window.confirm(
                                  `Delete workflow "${w.name || "Untitled Workflow"}"?`,
                                );
                                if (ok) {
                                  deleteMutation.mutate(w.id);
                                }
                              }}
                              className="cursor-pointer text-red-500 focus:text-red-500"
                              disabled={deleteMutation.isPending}
                            >
                              <Trash2 className="mr-2 h-4 w-4 text-red-500" />
                              Delete
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              );
            })
          ) : (
            <Card className="rounded-2xl border border-dashed border-border/80 bg-card/60">
              <CardContent className="flex flex-col items-center justify-center py-14 text-center">
                <GitBranch className="h-10 w-10 text-muted-foreground" />
                <h3 className="mt-4 text-xl font-semibold text-foreground">No workflows found</h3>
                <p className="mt-2 text-sm text-muted-foreground">
                  {search
                    ? "Try a different keyword."
                    : "Create your first workflow to get started."}
                </p>
                {!search && (
                  <Link href="/builder/new">
                    <Button className="mt-5 h-10 rounded-xl px-4">
                      <Plus className="mr-2 h-4 w-4" />
                      Create workflow
                    </Button>
                  </Link>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}
