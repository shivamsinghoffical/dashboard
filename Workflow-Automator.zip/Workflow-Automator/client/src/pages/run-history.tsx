import { useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Activity,
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronRight,
  Clock3,
  History,
  PlayCircle,
  Search,
  Timer,
  XCircle,
} from "lucide-react";
import type { WorkflowRun, StepLog } from "@shared/schema";

type RunStatusFilter = "all" | "success" | "error" | "running";

function formatDateTime(value?: string) {
  if (!value) return "Unknown";
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return "Unknown";
  return date.toLocaleString([], {
    month: "short",
    day: "numeric",
    hour: "numeric",
    minute: "2-digit",
  });
}

function getDurationMs(startedAt?: string, finishedAt?: string) {
  if (!startedAt || !finishedAt) return null;
  const start = new Date(startedAt).getTime();
  const end = new Date(finishedAt).getTime();
  if (Number.isNaN(start) || Number.isNaN(end) || end < start) return null;
  return end - start;
}

function formatDuration(ms?: number | null) {
  if (!ms || ms <= 0) return "0s";
  const seconds = Math.round(ms / 1000);
  if (seconds < 60) return `${seconds}s`;
  const mins = Math.floor(seconds / 60);
  const rem = seconds % 60;
  return rem > 0 ? `${mins}m ${rem}s` : `${mins}m`;
}

function stringifyJson(value: unknown) {
  try {
    return JSON.stringify(value ?? null, null, 2);
  } catch {
    return String(value);
  }
}

function getRunStatusPill(status: WorkflowRun["status"]) {
  if (status === "success") {
    return "border-emerald-300/70 bg-emerald-500/10 text-emerald-700";
  }
  if (status === "error") {
    return "border-rose-300/70 bg-rose-500/10 text-rose-700";
  }
  return "border-amber-300/70 bg-amber-500/10 text-amber-700";
}

function getStepStatusPill(status: StepLog["status"]) {
  if (status === "success") {
    return "border-emerald-300/70 bg-emerald-500/10 text-emerald-700";
  }
  if (status === "error") {
    return "border-rose-300/70 bg-rose-500/10 text-rose-700";
  }
  if (status === "running") {
    return "border-amber-300/70 bg-amber-500/10 text-amber-700";
  }
  return "border-slate-300/70 bg-slate-500/10 text-slate-700";
}

function RunDetail({ run }: { run: WorkflowRun }) {
  const [expanded, setExpanded] = useState(false);
  const runDuration = formatDuration(getDurationMs(run.startedAt, run.finishedAt));
  const runStatusClass = getRunStatusPill(run.status);

  const steps: StepLog[] = Array.isArray(run.steps) ? run.steps : [];
  const triggerPayload =
    run.triggerPayload && typeof run.triggerPayload === "object" ? run.triggerPayload : null;

  return (
    <Card
      className="group relative overflow-hidden rounded-2xl border border-border/70 bg-card/90 shadow-sm transition-all duration-300 hover:-translate-y-0.5 hover:shadow-lg"
      data-testid={`run-detail-${run.id}`}
    >
      <div className="pointer-events-none absolute inset-y-0 left-0 w-1 bg-gradient-to-b from-cyan-500 to-emerald-500" />
      <CardContent className="p-0">
        <button
          type="button"
          className="flex w-full cursor-pointer items-center gap-3 p-4 text-left"
          onClick={() => setExpanded(!expanded)}
          data-testid={`button-expand-run-${run.id}`}
        >
          {expanded ? (
            <ChevronDown className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
          ) : (
            <ChevronRight className="h-4 w-4 flex-shrink-0 text-muted-foreground" />
          )}

          {run.status === "success" ? (
            <CheckCircle2 className="h-4 w-4 flex-shrink-0 text-emerald-600" />
          ) : run.status === "running" ? (
            <Clock3 className="h-4 w-4 flex-shrink-0 text-amber-600" />
          ) : (
            <XCircle className="h-4 w-4 flex-shrink-0 text-rose-600" />
          )}

          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <p className="truncate text-sm font-semibold text-foreground">
                {run.workflowName || "Unnamed Workflow"}
              </p>

              <Badge variant="outline" className={`rounded-full text-[10px] ${runStatusClass}`}>
                {run.status}
              </Badge>

              <Badge variant="outline" className="rounded-full text-[10px]">
                {run.triggerType || "unknown"}
              </Badge>

              <Badge variant="outline" className="rounded-full text-[10px]">
                {steps.length} steps
              </Badge>
            </div>

            <div className="mt-1 flex flex-wrap items-center gap-3 text-[11px] text-muted-foreground">
              <span>ID {run.id?.slice?.(0, 8) || "Unknown"}</span>
              <span>Started {formatDateTime(run.startedAt)}</span>
              <span>Finished {formatDateTime(run.finishedAt)}</span>
              <span>Duration {runDuration}</span>
            </div>
          </div>
        </button>

        {expanded && (
          <div className="space-y-3 border-t border-border/70 px-4 pb-4">
            {triggerPayload && Object.keys(triggerPayload).length > 0 && (
              <div className="mt-3 rounded-xl border border-border/70 bg-muted/20 p-3">
                <p className="mb-1 text-[10px] font-semibold uppercase text-muted-foreground">
                  Trigger Payload
                </p>
                <ScrollArea className="max-h-36">
                  <pre className="rounded-md bg-background/70 p-2 text-[10px] font-mono">
                    {stringifyJson(triggerPayload)}
                  </pre>
                </ScrollArea>
              </div>
            )}

            {run.error && (
              <div className="rounded-lg border border-rose-300/70 bg-rose-500/10 p-2 text-xs font-mono text-rose-700">
                {run.error}
              </div>
            )}

            <div className="mt-3 space-y-2">
              <p className="text-[10px] font-semibold uppercase text-muted-foreground">
                Step Logs
              </p>

              {steps.length > 0 ? (
                steps.map((step: StepLog, i: number) => (
                  <StepDetail key={`${step.nodeId || "step"}-${i}`} step={step} />
                ))
              ) : (
                <div className="rounded-lg border border-border/60 bg-muted/20 p-3 text-xs text-muted-foreground">
                  No step logs available for this run.
                </div>
              )}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function StepDetail({ step }: { step: StepLog }) {
  const [showDetails, setShowDetails] = useState(false);
  const stepStatusClass = getStepStatusPill(step.status);
  const stepDuration = formatDuration(getDurationMs(step.startedAt, step.finishedAt));

  return (
    <div className="rounded-xl border border-border/60 bg-background/60">
      <button
        type="button"
        className="flex w-full cursor-pointer items-center gap-2 p-2.5 text-left"
        onClick={() => setShowDetails(!showDetails)}
      >
        {step.status === "success" ? (
          <CheckCircle2 className="h-3.5 w-3.5 flex-shrink-0 text-emerald-600" />
        ) : step.status === "error" ? (
          <XCircle className="h-3.5 w-3.5 flex-shrink-0 text-rose-600" />
        ) : (
          <Clock3 className="h-3.5 w-3.5 flex-shrink-0 text-amber-600" />
        )}

        <span className="flex-1 truncate text-xs font-medium text-foreground">
          {step.nodeLabel || "Unnamed Step"}
        </span>

        <span className="text-[10px] text-muted-foreground">{step.nodeType || "unknown"}</span>

        <Badge variant="outline" className={`rounded-full text-[10px] ${stepStatusClass}`}>
          {step.status}
        </Badge>

        <span className="text-[10px] text-muted-foreground">{stepDuration}</span>

        {step.branch && (
          <Badge variant="outline" className="h-5 rounded-full text-[9px]">
            {step.branch}
          </Badge>
        )}
      </button>

      {showDetails && (
        <div className="space-y-2 border-t border-border/60 px-2.5 pb-2.5">
          {step.error && (
            <div className="mt-2 rounded bg-rose-500/10 p-2 text-[10px] font-mono text-rose-700">
              {step.error}
            </div>
          )}

          <div className="mt-2 grid gap-2 md:grid-cols-2">
            <div className="min-w-0">
              <p className="mb-1 text-[9px] font-semibold uppercase text-muted-foreground">
                Input
              </p>
              <ScrollArea className="max-h-32 rounded-md border border-border/60 bg-muted/20">
                <pre className="p-1.5 text-[10px] font-mono">{stringifyJson(step.input)}</pre>
              </ScrollArea>
            </div>

            <div className="min-w-0">
              <p className="mb-1 text-[9px] font-semibold uppercase text-muted-foreground">
                Output
              </p>
              <ScrollArea className="max-h-32 rounded-md border border-border/60 bg-muted/20">
                <pre className="p-1.5 text-[10px] font-mono">{stringifyJson(step.output)}</pre>
              </ScrollArea>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default function RunHistory() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<RunStatusFilter>("all");

  const { data: runs = [], isLoading } = useQuery<WorkflowRun[]>({
    queryKey: ["/api/runs"],
  });

  const safeRuns = Array.isArray(runs) ? runs : [];

  const totalRuns = safeRuns.length;
  const successRuns = safeRuns.filter((run) => run.status === "success").length;
  const failedRuns = safeRuns.filter((run) => run.status === "error").length;
  const runningRuns = safeRuns.filter((run) => run.status === "running").length;
  const successRate = totalRuns > 0 ? Math.round((successRuns / totalRuns) * 100) : 0;

  const avgDuration = useMemo(() => {
    const durations = safeRuns
      .map((run) => getDurationMs(run.startedAt, run.finishedAt))
      .filter((duration): duration is number => typeof duration === "number");

    if (durations.length === 0) return "0s";

    const totalDuration = durations.reduce((acc, value) => acc + value, 0);
    return formatDuration(Math.round(totalDuration / durations.length));
  }, [safeRuns]);

  const visibleRuns = useMemo(() => {
    const q = search.trim().toLowerCase();

    return safeRuns.filter((run) => {
      const workflowName = run.workflowName || "";
      const triggerType = run.triggerType || "";
      const runId = run.id || "";

      const matchesSearch = !q
        ? true
        : `${workflowName} ${triggerType} ${runId}`.toLowerCase().includes(q);

      const matchesStatus = statusFilter === "all" ? true : run.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [safeRuns, search, statusFilter]);

  if (isLoading) {
    return (
      <div
        className="min-h-full bg-[radial-gradient(1100px_420px_at_8%_-8%,rgba(56,189,248,0.15),transparent_58%),radial-gradient(1200px_420px_at_94%_6%,rgba(16,185,129,0.10),transparent_54%),hsl(var(--background))] px-6 py-5"
        data-testid="page-run-history-loading"
      >
        <div className="mx-auto max-w-[1360px] space-y-5">
          <Skeleton className="h-48 w-full rounded-3xl" />
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="rounded-2xl">
                <CardContent className="p-5">
                  <Skeleton className="h-24 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
          <Skeleton className="h-14 w-full rounded-2xl" />
          <div className="space-y-3">
            {[...Array(4)].map((_, i) => (
              <Card key={i} className="rounded-2xl">
                <CardContent className="p-4">
                  <Skeleton className="h-20 w-full" />
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className="min-h-full bg-[radial-gradient(1100px_420px_at_8%_-8%,rgba(56,189,248,0.15),transparent_58%),radial-gradient(1200px_420px_at_94%_6%,rgba(16,185,129,0.10),transparent_54%),hsl(var(--background))] px-6 py-5"
      data-testid="page-run-history"
    >
      <div className="mx-auto max-w-[1360px] space-y-5">
        <section className="relative overflow-hidden rounded-3xl border border-border/70 bg-card/90 p-6 shadow-sm">
          <div className="pointer-events-none absolute -top-20 -left-14 h-52 w-52 rounded-full bg-cyan-400/15 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-20 -right-8 h-52 w-52 rounded-full bg-emerald-400/12 blur-3xl" />

          <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-background/70 px-3 py-1 text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                <Activity className="h-3.5 w-3.5 text-cyan-600" />
                Execution Ledger
              </div>
              <h1 className="mt-3 text-3xl font-semibold tracking-tight text-foreground">
                Monitor every workflow run in one view
              </h1>
              <p className="mt-1.5 max-w-3xl text-sm text-muted-foreground">
                Trace execution quality, inspect step-by-step payloads, and debug failures faster
                with a premium run-history console.
              </p>
            </div>

            <Card className="w-full max-w-[320px] rounded-2xl border border-border/70 bg-background/70 shadow-none">
              <CardContent className="p-4">
                <p className="text-xs font-semibold uppercase tracking-[0.12em] text-muted-foreground">
                  Reliability Score
                </p>
                <p className="mt-1 text-3xl font-semibold text-foreground">{successRate}%</p>
                <div className="mt-3 space-y-1.5 text-xs text-muted-foreground">
                  <div className="flex items-center justify-between">
                    <span>Average duration</span>
                    <span className="font-medium text-foreground">{avgDuration}</span>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Runs in progress</span>
                    <span className="font-medium text-foreground">{runningRuns}</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </section>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 xl:grid-cols-4">
          <Card className="rounded-2xl border border-border/70 bg-card/90 shadow-sm">
            <CardContent className="p-5">
              <p className="text-sm text-muted-foreground">Total Runs</p>
              <p className="mt-1 text-3xl font-semibold text-foreground">{totalRuns}</p>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border border-border/70 bg-card/90 shadow-sm">
            <CardContent className="p-5">
              <p className="text-sm text-muted-foreground">Successful</p>
              <p className="mt-1 text-3xl font-semibold text-emerald-700">{successRuns}</p>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border border-border/70 bg-card/90 shadow-sm">
            <CardContent className="p-5">
              <p className="text-sm text-muted-foreground">Failed</p>
              <p className="mt-1 text-3xl font-semibold text-rose-700">{failedRuns}</p>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border border-border/70 bg-card/90 shadow-sm">
            <CardContent className="p-5">
              <p className="text-sm text-muted-foreground">Average Duration</p>
              <p className="mt-1 text-3xl font-semibold text-foreground">{avgDuration}</p>
            </CardContent>
          </Card>
        </div>

        <Card className="rounded-2xl border border-border/70 bg-card/85 shadow-sm">
          <CardContent className="p-3">
            <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
              <div className="relative min-w-[260px]">
                <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search by workflow, trigger, or run ID..."
                  className="h-10 rounded-xl bg-background/80 pl-9"
                  data-testid="input-search-runs"
                />
              </div>

              <div className="flex flex-wrap items-center gap-2">
                <Button
                  variant={statusFilter === "all" ? "default" : "outline"}
                  className="h-9 rounded-xl"
                  onClick={() => setStatusFilter("all")}
                  data-testid="button-filter-all-runs"
                >
                  All
                </Button>

                <Button
                  variant={statusFilter === "success" ? "default" : "outline"}
                  className="h-9 rounded-xl"
                  onClick={() => setStatusFilter("success")}
                  data-testid="button-filter-success-runs"
                >
                  <CheckCircle2 className="mr-1.5 h-3.5 w-3.5" />
                  Success
                </Button>

                <Button
                  variant={statusFilter === "running" ? "default" : "outline"}
                  className="h-9 rounded-xl"
                  onClick={() => setStatusFilter("running")}
                  data-testid="button-filter-running-runs"
                >
                  <PlayCircle className="mr-1.5 h-3.5 w-3.5" />
                  Running
                </Button>

                <Button
                  variant={statusFilter === "error" ? "default" : "outline"}
                  className="h-9 rounded-xl"
                  onClick={() => setStatusFilter("error")}
                  data-testid="button-filter-error-runs"
                >
                  <AlertTriangle className="mr-1.5 h-3.5 w-3.5" />
                  Failed
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        {visibleRuns.length === 0 ? (
          <Card className="rounded-2xl border border-dashed border-border/80 bg-card/60">
            <CardContent className="flex flex-col items-center justify-center py-16 text-center">
              <History className="mb-4 h-11 w-11 text-muted-foreground" />
              <h3 className="text-lg font-semibold text-foreground">
                {safeRuns.length === 0 ? "No executions yet" : "No matching runs"}
              </h3>
              <p className="mt-1.5 text-sm text-muted-foreground">
                {safeRuns.length === 0
                  ? "Run a workflow to populate execution history."
                  : "Try changing your search or run status filters."}
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {visibleRuns.map((run) => (
              <RunDetail key={run.id} run={run} />
            ))}
          </div>
        )}

        <Card className="rounded-2xl border border-border/70 bg-card/85 shadow-sm">
          <CardContent className="flex flex-wrap items-center gap-2 p-4 text-xs text-muted-foreground">
            <Timer className="h-4 w-4" />
            Live run logs are derived from stored run snapshots and displayed with masked payloads.
          </CardContent>
        </Card>
      </div>
    </div>
  );
}