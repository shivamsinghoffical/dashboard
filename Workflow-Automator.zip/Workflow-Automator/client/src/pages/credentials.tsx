import { useMemo, useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import {
  Plus,
  Search,
  Pencil,
  Trash2,
  ShieldCheck,
  KeyRound,
  Copy,
  ExternalLink,
  Loader2,
  ChevronRight,
  Link2,
  Sparkles,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";

import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardContent,
} from "@/components/ui/card";
import {
  Dialog,
  DialogHeader,
  DialogTitle,
  DialogFooter,
  DialogContent,
  DialogDescription,
} from "@/components/ui/dialog";

import type { CredentialMasked, CredentialType } from "@shared/schema";
import { credentialTypeDefs } from "@shared/schema";

const SECRET_KEYS = [
  "apiKey",
  "token",
  "password",
  "clientSecret",
  "headerValue",
  "accessToken",
  "refreshToken",
];

function getDefaultRedirectPath(path: string) {
  if (typeof window === "undefined") return path;
  return `${window.location.origin}${path}`;
}

const DEFAULT_QBO_REDIRECT = getDefaultRedirectPath("/rest/oauth2-credential/callback");
const DEFAULT_GOOGLE_REDIRECT = getDefaultRedirectPath("/api/oauth/google/callback");

function getDefaultFormData(type: CredentialType): Record<string, string> {
  switch (type) {
    case "openai_api":
      return { apiKey: "" };
    case "http_bearer":
      return { token: "" };
    case "http_basic":
      return { username: "", password: "" };
    case "http_header":
      return { headerName: "", headerValue: "" };
    case "quickbooks_oauth2":
      return {
        redirectUrl: DEFAULT_QBO_REDIRECT,
        clientId: "",
        clientSecret: "",
        environment: "production",
        allowedDomains: "quickbooks.api.intuit.com",
        scope: "com.intuit.quickbooks.accounting",
        accessToken: "",
        refreshToken: "",
        realmId: "",
        tokenExpiresAt: "",
      };
    case "google_oauth2":
      return {
        redirectUrl: DEFAULT_GOOGLE_REDIRECT,
        clientId: "",
        clientSecret: "",
        scope: [
          "https://www.googleapis.com/auth/gmail.send",
          "https://www.googleapis.com/auth/gmail.readonly",
          "https://www.googleapis.com/auth/spreadsheets",
          "https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/calendar",
          "https://www.googleapis.com/auth/documents",
        ].join(" "),
        accessToken: "",
        refreshToken: "",
        tokenExpiresAt: "",
      };
    default:
      return {};
  }
}

function maskDisplayValue(value?: string) {
  if (!value) return "";
  if (value === "********") return value;
  if (value.length <= 6) return "******";
  return `${value.slice(0, 3)}****${value.slice(-3)}`;
}

function isOAuthType(type: CredentialType) {
  return type === "quickbooks_oauth2" || type === "google_oauth2";
}

function isCredentialConnected(credential?: CredentialMasked | null) {
  if (!credential) return false;
  if (credential.type === "quickbooks_oauth2") {
    return !!credential.data?.realmId || !!credential.data?.tokenExpiresAt;
  }
  if (credential.type === "google_oauth2") {
    return !!credential.data?.accessToken || !!credential.data?.tokenExpiresAt;
  }
  return true;
}

function getOAuthLabel(type?: CredentialType) {
  return type === "quickbooks_oauth2" ? "QuickBooks" : "Google";
}

export default function CredentialsPage() {
  const { toast } = useToast();

  const [search, setSearch] = useState("");
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const [showCreate, setShowCreate] = useState(false);
  const [editingCredential, setEditingCredential] = useState<CredentialMasked | null>(null);
  const [deletingCredential, setDeletingCredential] = useState<CredentialMasked | null>(null);

  const [formName, setFormName] = useState("");
  const [formType, setFormType] = useState<CredentialType>("openai_api");
  const [formData, setFormData] = useState<Record<string, string>>(getDefaultFormData("openai_api"));

  const { data: credentials = [], isLoading } = useQuery<CredentialMasked[]>({
    queryKey: ["/api/credentials"],
  });

  const filteredCredentials = useMemo(() => {
    const q = search.trim().toLowerCase();
    if (!q) return credentials;
    return credentials.filter((cred) => `${cred.name} ${cred.type}`.toLowerCase().includes(q));
  }, [credentials, search]);

  const selectedCredential = useMemo(() => {
    if (!selectedId) return filteredCredentials[0] || null;
    return credentials.find((x) => x.id === selectedId) || filteredCredentials[0] || null;
  }, [credentials, filteredCredentials, selectedId]);

  const selectedTypeDef = credentialTypeDefs.find((x) => x.type === formType);

  const resetForm = () => {
    setFormName("");
    setFormType("openai_api");
    setFormData(getDefaultFormData("openai_api"));
  };

  const openCreateDialog = () => {
    setEditingCredential(null);
    setFormName("");
    setFormType("openai_api");
    setFormData(getDefaultFormData("openai_api"));
    setShowCreate(true);
  };

  const openEditDialog = (cred: CredentialMasked) => {
    setShowCreate(true);
    setEditingCredential(cred);
    setFormName(cred.name);
    setFormType(cred.type);

    const nextData = { ...getDefaultFormData(cred.type), ...(cred.data || {}) };
    if (cred.type === "quickbooks_oauth2") nextData.redirectUrl = DEFAULT_QBO_REDIRECT;
    if (cred.type === "google_oauth2") nextData.redirectUrl = DEFAULT_GOOGLE_REDIRECT;

    for (const field of credentialTypeDefs.find((t) => t.type === cred.type)?.fields || []) {
      const isSecret = field.type === "password" || SECRET_KEYS.includes(field.key);
      if (isSecret) nextData[field.key] = "";
    }

    setFormData(nextData);
  };

  const closeFormDialog = () => {
    setShowCreate(false);
    setEditingCredential(null);
    resetForm();
  };

  const createMutation = useMutation({
    mutationFn: async () =>
      apiRequest("POST", "/api/credentials", {
        name: formName.trim(),
        type: formType,
        data: formData,
      }),
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/credentials"] });
      closeFormDialog();
      toast({ title: "Credential created" });
    },
    onError: (err: any) => {
      toast({
        title: "Failed to create credential",
        description: err?.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const updateMutation = useMutation({
    mutationFn: async () => {
      if (!editingCredential) throw new Error("No credential selected");
      return apiRequest("PATCH", `/api/credentials/${editingCredential.id}`, {
        name: formName.trim(),
        data: formData,
      });
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/credentials"] });
      closeFormDialog();
      toast({ title: "Credential updated" });
    },
    onError: (err: any) => {
      toast({
        title: "Failed to update credential",
        description: err?.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const deleteMutation = useMutation({
    mutationFn: async () => {
      if (!deletingCredential) throw new Error("No credential selected");
      return apiRequest("DELETE", `/api/credentials/${deletingCredential.id}`);
    },
    onSuccess: async () => {
      await queryClient.invalidateQueries({ queryKey: ["/api/credentials"] });
      if (selectedId === deletingCredential?.id) setSelectedId(null);
      setDeletingCredential(null);
      toast({ title: "Credential deleted" });
    },
    onError: (err: any) => {
      toast({
        title: "Failed to delete credential",
        description: err?.message || "Something went wrong",
        variant: "destructive",
      });
    },
  });

  const connectOAuthCredential = async (credential: CredentialMasked) => {
    const isQuickBooks = credential.type === "quickbooks_oauth2";
    const provider = isQuickBooks ? "quickbooks" : "google";
    const endpoint = `/api/credentials/${credential.id}/${provider}/connect`;
    const connectedEvent = isQuickBooks ? "quickbooks_connected" : "google_connected";
    const providerLabel = isQuickBooks ? "QuickBooks" : "Google";

    try {
      const res = await fetch(endpoint, { credentials: "include" });
      if (!res.ok) {
        const text = await res.text();
        throw new Error(text || `Failed to generate ${providerLabel} connect URL`);
      }

      const data = await res.json();
      if (!data.url) throw new Error("Authorize URL missing");

      const popup = window.open(
        data.url,
        `${provider}-oauth`,
        "width=700,height=750,scrollbars=yes,resizable=yes",
      );

      if (!popup) {
        window.location.href = data.url;
        return;
      }

      const onMessage = (event: MessageEvent) => {
        if (event.data?.type === connectedEvent) {
          window.removeEventListener("message", onMessage);
          popup.close();
          window.location.reload();
        }
      };
      window.addEventListener("message", onMessage);
    } catch (error: any) {
      toast({
        title: `${providerLabel} connect failed`,
        description: error?.message || "Something went wrong",
        variant: "destructive",
      });
    }
  };

  const handleCopy = async (text: string, label: string) => {
    try {
      await navigator.clipboard.writeText(text);
      toast({ title: `${label} copied` });
    } catch {
      toast({
        title: "Copy failed",
        description: "Could not copy to clipboard",
        variant: "destructive",
      });
    }
  };

  const validateForm = () => {
    if (!formName.trim() || !selectedTypeDef) return false;

    for (const field of selectedTypeDef.fields) {
      if (
        field.required &&
        !["accessToken", "refreshToken", "realmId", "tokenExpiresAt"].includes(field.key) &&
        !String(formData[field.key] || "").trim()
      ) {
        return false;
      }
    }
    return true;
  };

  const getTypeLabel = (type: CredentialType) =>
    credentialTypeDefs.find((x) => x.type === type)?.label || type;

  const getTypeDescription = (type: CredentialType) =>
    credentialTypeDefs.find((x) => x.type === type)?.description || "";

  const isSubmitting = createMutation.isPending || updateMutation.isPending;
  const detailTypeDef = selectedCredential
    ? credentialTypeDefs.find((x) => x.type === selectedCredential.type)
    : null;

  const selectedIsOAuth = selectedCredential ? isOAuthType(selectedCredential.type) : false;
  const selectedIsConnected = isCredentialConnected(selectedCredential);

  const totalCredentials = credentials.length;
  const oauthCredentials = credentials.filter((c) => isOAuthType(c.type)).length;
  const connectedCredentials = credentials.filter((c) => isCredentialConnected(c)).length;

  return (
    <div
      className="min-h-full bg-[radial-gradient(1100px_420px_at_8%_-10%,rgba(56,189,248,0.14),transparent_58%),radial-gradient(1200px_420px_at_94%_8%,rgba(16,185,129,0.10),transparent_54%),hsl(var(--background))] px-6 py-5"
      data-testid="page-credentials"
    >
      <div className="mx-auto max-w-[1360px] space-y-5">
        <section className="relative overflow-hidden rounded-3xl border border-border/70 bg-card/90 p-6 shadow-sm">
          <div className="pointer-events-none absolute -top-20 -left-14 h-52 w-52 rounded-full bg-cyan-400/15 blur-3xl" />
          <div className="pointer-events-none absolute -bottom-20 -right-8 h-52 w-52 rounded-full bg-emerald-400/12 blur-3xl" />

          <div className="relative flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
            <div>
              <div className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-background/70 px-3 py-1 text-xs font-semibold tracking-[0.12em] uppercase text-muted-foreground">
                <Sparkles className="h-3.5 w-3.5 text-cyan-600" />
                Security Vault
              </div>
              <h1 className="mt-3 text-3xl font-semibold tracking-tight text-foreground">
                Manage credentials securely
              </h1>
              <p className="mt-1.5 text-sm text-muted-foreground">
                Store API keys, OAuth tokens, and attach credentials to workflow nodes.
              </p>
            </div>

            <Button onClick={openCreateDialog} className="h-10 rounded-xl gap-2">
              <Plus className="h-4 w-4" />
              Add credential
            </Button>
          </div>

          <div className="relative mt-4 grid grid-cols-1 gap-3 sm:grid-cols-3">
            <Card className="rounded-2xl border border-border/70 bg-background/75 shadow-none">
              <CardContent className="p-4">
                <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground">Total</p>
                <p className="mt-1 text-2xl font-semibold text-foreground">{totalCredentials}</p>
              </CardContent>
            </Card>
            <Card className="rounded-2xl border border-border/70 bg-background/75 shadow-none">
              <CardContent className="p-4">
                <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground">OAuth</p>
                <p className="mt-1 text-2xl font-semibold text-foreground">{oauthCredentials}</p>
              </CardContent>
            </Card>
            <Card className="rounded-2xl border border-border/70 bg-background/75 shadow-none">
              <CardContent className="p-4">
                <p className="text-xs uppercase tracking-[0.12em] text-muted-foreground">Connected</p>
                <p className="mt-1 text-2xl font-semibold text-foreground">{connectedCredentials}</p>
              </CardContent>
            </Card>
          </div>
        </section>

        <div className="grid gap-4 xl:grid-cols-[340px_minmax(0,1fr)]">
          <Card className="rounded-2xl border border-border/70 bg-card/90 shadow-sm">
            <CardContent className="p-0">
              <div className="border-b border-border/70 p-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search credentials..."
                    className="h-10 rounded-xl bg-background/80 pl-9"
                  />
                </div>
              </div>

              <ScrollArea className="h-[calc(100vh-360px)] min-h-[360px]">
                <div className="p-3 space-y-2">
                  {isLoading ? (
                    <div className="flex items-center gap-2 text-sm text-muted-foreground p-4">
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Loading credentials...
                    </div>
                  ) : filteredCredentials.length === 0 ? (
                    <div className="rounded-2xl border border-dashed bg-background p-6 text-center text-sm text-muted-foreground">
                      No credentials found.
                    </div>
                  ) : (
                    filteredCredentials.map((cred) => {
                      const active = selectedCredential?.id === cred.id;
                      const oauth = isOAuthType(cred.type);
                      const connected = isCredentialConnected(cred);

                      return (
                        <button
                          key={cred.id}
                          type="button"
                          onClick={() => setSelectedId(cred.id)}
                          className={`w-full rounded-2xl border px-4 py-3 text-left transition-all ${
                            active
                              ? "border-primary bg-primary/5 shadow-sm"
                              : "border-transparent hover:border-border hover:bg-background"
                          }`}
                        >
                          <div className="flex items-start justify-between gap-3">
                            <div className="min-w-0">
                              <div className="font-medium truncate text-foreground">{cred.name}</div>
                              <div className="text-xs text-muted-foreground mt-1 truncate">
                                {getTypeLabel(cred.type)}
                              </div>
                              <div className="mt-2">
                                <Badge
                                  variant="outline"
                                  className={`rounded-full text-[10px] ${
                                    oauth
                                      ? connected
                                        ? "border-emerald-300/70 bg-emerald-500/10 text-emerald-700"
                                        : "border-amber-300/70 bg-amber-500/10 text-amber-700"
                                      : "border-cyan-300/70 bg-cyan-500/10 text-cyan-700"
                                  }`}
                                >
                                  {oauth ? (connected ? "Connected" : "Not connected") : "Ready"}
                                </Badge>
                              </div>
                            </div>

                            <ChevronRight className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" />
                          </div>
                        </button>
                      );
                    })
                  )}
                </div>
              </ScrollArea>
            </CardContent>
          </Card>

          <Card className="rounded-2xl border border-border/70 bg-card/90 shadow-sm">
            <CardContent className="p-6">
              {!selectedCredential ? (
                <div className="rounded-3xl border border-dashed p-16 text-center bg-muted/10">
                  <KeyRound className="h-10 w-10 mx-auto text-muted-foreground mb-4" />
                  <h3 className="text-lg font-semibold">No credential selected</h3>
                  <p className="text-sm text-muted-foreground mt-2">
                    Select a credential from the left panel or create a new one.
                  </p>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="flex items-start justify-between gap-4 flex-wrap">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h2 className="text-2xl font-semibold">{selectedCredential.name}</h2>
                        <Badge variant="outline" className="rounded-full">
                          {getTypeLabel(selectedCredential.type)}
                        </Badge>
                        <Badge
                          className={`rounded-full ${
                            selectedIsOAuth
                              ? selectedIsConnected
                                ? "bg-emerald-600 text-white"
                                : "bg-amber-500 text-white"
                              : "bg-cyan-600 text-white"
                          }`}
                        >
                          {selectedIsOAuth
                            ? selectedIsConnected
                              ? "Connected"
                              : "Not connected"
                            : "Ready"}
                        </Badge>
                      </div>

                      <p className="text-sm text-muted-foreground mt-2 max-w-2xl">
                        {getTypeDescription(selectedCredential.type)}
                      </p>
                    </div>

                    <div className="flex items-center gap-2 flex-wrap">
                      {selectedIsOAuth && (
                        <Button
                          className="rounded-xl gap-2"
                          onClick={() => connectOAuthCredential(selectedCredential)}
                        >
                          <Link2 className="h-4 w-4" />
                          {selectedIsConnected
                            ? `Reconnect ${getOAuthLabel(selectedCredential.type)}`
                            : `Connect ${getOAuthLabel(selectedCredential.type)}`}
                        </Button>
                      )}

                      <Button
                        variant="outline"
                        className="rounded-xl gap-2"
                        onClick={() => openEditDialog(selectedCredential)}
                      >
                        <Pencil className="h-4 w-4" />
                        Edit
                      </Button>

                      <Button
                        variant="destructive"
                        className="rounded-xl gap-2"
                        onClick={() => setDeletingCredential(selectedCredential)}
                      >
                        <Trash2 className="h-4 w-4" />
                        Delete
                      </Button>
                    </div>
                  </div>

                  <div className="grid gap-4 md:grid-cols-3">
                    <Card className="rounded-2xl border border-border/70 shadow-none">
                      <CardHeader className="pb-2">
                        <CardDescription>Credential type</CardDescription>
                        <CardTitle className="text-base">
                          {getTypeLabel(selectedCredential.type)}
                        </CardTitle>
                      </CardHeader>
                    </Card>
                    <Card className="rounded-2xl border border-border/70 shadow-none">
                      <CardHeader className="pb-2">
                        <CardDescription>Created</CardDescription>
                        <CardTitle className="text-base">
                          {new Date(selectedCredential.createdAt).toLocaleString()}
                        </CardTitle>
                      </CardHeader>
                    </Card>
                    <Card className="rounded-2xl border border-border/70 shadow-none">
                      <CardHeader className="pb-2">
                        <CardDescription>Last updated</CardDescription>
                        <CardTitle className="text-base">
                          {new Date(selectedCredential.updatedAt).toLocaleString()}
                        </CardTitle>
                      </CardHeader>
                    </Card>
                  </div>

                  <Card className="rounded-2xl border border-border/70 shadow-none">
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <ShieldCheck className="h-5 w-5" />
                        Credential details
                      </CardTitle>
                      <CardDescription>
                        Sensitive values are masked and protected.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-5">
                      {detailTypeDef?.fields.map((field) => {
                        const redirectValue =
                          selectedCredential.type === "quickbooks_oauth2"
                            ? DEFAULT_QBO_REDIRECT
                            : selectedCredential.type === "google_oauth2"
                              ? DEFAULT_GOOGLE_REDIRECT
                              : "";
                        const value =
                          field.key === "redirectUrl"
                            ? redirectValue
                            : selectedCredential.data?.[field.key] || "";
                        const masked = field.type === "password" || SECRET_KEYS.includes(field.key);
                        const displayValue = masked ? maskDisplayValue(value) : value;

                        return (
                          <div key={field.key} className="grid gap-2">
                            <Label>{field.label}</Label>
                            <div className="flex items-center gap-2">
                              <Input value={displayValue} readOnly className="rounded-xl bg-muted/40" />
                              {!!value && (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="icon"
                                  className="rounded-xl"
                                  onClick={() => handleCopy(value, field.label)}
                                >
                                  <Copy className="h-4 w-4" />
                                </Button>
                              )}
                              {field.key === "redirectUrl" && value && (
                                <Button
                                  type="button"
                                  variant="outline"
                                  size="icon"
                                  className="rounded-xl"
                                  onClick={() => window.open(value, "_blank")}
                                >
                                  <ExternalLink className="h-4 w-4" />
                                </Button>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </CardContent>
                  </Card>

                  {selectedIsOAuth && (
                    <Card className="rounded-2xl border border-border/70 shadow-none">
                      <CardContent className="p-4">
                        <div className="flex items-start gap-2">
                          {selectedIsConnected ? (
                            <CheckCircle2 className="h-4 w-4 mt-0.5 text-emerald-600" />
                          ) : (
                            <AlertCircle className="h-4 w-4 mt-0.5 text-amber-600" />
                          )}
                          <p className="text-sm text-muted-foreground">
                            {selectedIsConnected
                              ? `${getOAuthLabel(selectedCredential.type)} is connected and ready for workflow execution.`
                              : `${getOAuthLabel(selectedCredential.type)} is not connected. Use Connect to authorize.`}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      <Dialog open={showCreate} onOpenChange={(open) => (!open ? closeFormDialog() : setShowCreate(true))}>
        <DialogContent className="sm:max-w-2xl rounded-3xl border border-border/70 p-0 overflow-hidden">
          <div className="border-b px-6 py-5">
            <DialogHeader>
              <DialogTitle className="text-xl">
                {editingCredential ? "Edit credential" : "Create credential"}
              </DialogTitle>
              <DialogDescription>
                Store credentials securely and attach them to workflow nodes.
              </DialogDescription>
            </DialogHeader>
          </div>

          <ScrollArea className="max-h-[75vh]">
            <div className="px-6 py-5 space-y-5">
              <div className="grid gap-2">
                <Label htmlFor="cred-name">Credential name</Label>
                <Input
                  id="cred-name"
                  value={formName}
                  onChange={(e) => setFormName(e.target.value)}
                  placeholder="e.g. QuickBooks Production"
                  className="rounded-xl"
                />
              </div>

              {!editingCredential && (
                <div className="grid gap-3">
                  <Label>Credential type</Label>
                  <div className="grid gap-3 sm:grid-cols-2">
                    {credentialTypeDefs.map((def) => {
                      const active = def.type === formType;
                      return (
                        <button
                          key={def.type}
                          type="button"
                          onClick={() => {
                            setFormType(def.type);
                            setFormData(getDefaultFormData(def.type));
                          }}
                          className={`rounded-2xl border p-4 text-left transition ${
                            active
                              ? "border-primary bg-primary/5"
                              : "border-border hover:bg-muted/40"
                          }`}
                        >
                          <div className="font-medium">{def.label}</div>
                          <div className="text-xs text-muted-foreground mt-1">
                            {def.description}
                          </div>
                        </button>
                      );
                    })}
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {selectedTypeDef?.fields.map((field) => (
                  <div key={field.key} className="grid gap-2">
                    <Label htmlFor={field.key}>
                      {field.label}
                      {field.required ? " *" : ""}
                    </Label>
                    <Input
                      id={field.key}
                      type={field.type === "password" ? "password" : "text"}
                      value={formData[field.key] || ""}
                      onChange={(e) =>
                        setFormData((prev) => ({
                          ...prev,
                          [field.key]: e.target.value,
                        }))
                      }
                      placeholder={field.placeholder}
                      readOnly={field.readOnly}
                      className="rounded-xl"
                    />
                    {field.key === "redirectUrl" && (
                      <p className="text-xs text-muted-foreground">
                        Add this exact redirect URL in your OAuth app configuration.
                      </p>
                    )}
                    {editingCredential &&
                      (field.type === "password" || SECRET_KEYS.includes(field.key)) && (
                        <p className="text-xs text-muted-foreground">
                          Leave blank to keep the existing secret value unchanged.
                        </p>
                      )}
                  </div>
                ))}
              </div>
            </div>
          </ScrollArea>

          <DialogFooter className="border-t px-6 py-4">
            <Button variant="outline" className="rounded-xl" onClick={closeFormDialog}>
              Cancel
            </Button>
            <Button
              className="rounded-xl"
              disabled={!validateForm() || isSubmitting}
              onClick={() => (editingCredential ? updateMutation.mutate() : createMutation.mutate())}
            >
              {isSubmitting ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              {editingCredential ? "Save changes" : "Create credential"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog
        open={!!deletingCredential}
        onOpenChange={(open) => (!open ? setDeletingCredential(null) : null)}
      >
        <DialogContent className="sm:max-w-md rounded-3xl border border-border/70">
          <DialogHeader>
            <DialogTitle>Delete credential</DialogTitle>
            <DialogDescription>
              This will remove the credential. Any linked workflow nodes will also lose the connection.
            </DialogDescription>
          </DialogHeader>

          <div className="rounded-2xl border bg-muted/30 p-4 text-sm">
            <div className="font-medium">{deletingCredential?.name}</div>
            <div className="text-muted-foreground mt-1">
              {deletingCredential ? getTypeLabel(deletingCredential.type) : ""}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" className="rounded-xl" onClick={() => setDeletingCredential(null)}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              className="rounded-xl"
              onClick={() => deleteMutation.mutate()}
              disabled={deleteMutation.isPending}
            >
              {deleteMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : null}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
