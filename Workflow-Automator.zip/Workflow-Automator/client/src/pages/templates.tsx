import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { BookTemplate, Plus, GitBranch, ArrowRight } from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import type { WorkflowTemplate } from "@shared/schema";

export default function Templates() {
  const [, navigate] = useLocation();
  const { toast } = useToast();

  const { data: templates, isLoading } = useQuery<WorkflowTemplate[]>({
    queryKey: ["/api/templates"],
  });

  const createFromTemplate = useMutation({
    mutationFn: (id: string) => apiRequest("POST", `/api/templates/${id}/create`),
    onSuccess: async (res) => {
      const workflow = await res.json();
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });
      toast({ title: "Workflow created from template" });
      navigate(`/builder/${workflow.id}`);
    },
  });

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <Skeleton className="h-8 w-48" />
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(3)].map((_, i) => (
            <Card key={i}><CardContent className="p-5"><Skeleton className="h-32" /></CardContent></Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="p-6 space-y-6 max-w-7xl" data-testid="page-templates">
      <div>
        <h1 className="text-xl font-semibold">Templates</h1>
        <p className="text-sm text-muted-foreground mt-0.5">
          Start with a pre-built workflow template
        </p>
      </div>

      {templates?.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-16">
            <BookTemplate className="w-12 h-12 text-muted-foreground mb-4" />
            <h3 className="text-sm font-medium mb-1">No templates available</h3>
            <p className="text-xs text-muted-foreground">Templates will appear here</p>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {templates?.map((template) => (
            <Card key={template.id}>
              <CardContent className="p-5 space-y-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <GitBranch className="w-4 h-4 text-primary flex-shrink-0" />
                    <h3 className="text-sm font-semibold">{template.name}</h3>
                  </div>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {template.description}
                  </p>
                </div>

                <div className="flex items-center gap-2 flex-wrap">
                  <Badge variant="secondary" className="text-[9px]">{template.category}</Badge>
                  <span className="text-[10px] text-muted-foreground">
                    {template.nodes.length} nodes
                  </span>
                </div>

                <div className="flex items-center gap-1 flex-wrap">
                  {template.nodes.map((node, i) => (
                    <span key={i}>
                      <Badge variant="secondary" className="text-[8px] h-4 no-default-active-elevate">
                        {node.data.label}
                      </Badge>
                      {i < template.nodes.length - 1 && (
                        <ArrowRight className="w-2.5 h-2.5 text-muted-foreground inline mx-0.5" />
                      )}
                    </span>
                  ))}
                </div>

                <Button
                  variant="secondary"
                  size="sm"
                  className="w-full text-xs"
                  onClick={() => createFromTemplate.mutate(template.id)}
                  disabled={createFromTemplate.isPending}
                  data-testid={`button-use-template-${template.id}`}
                >
                  <Plus className="w-3 h-3 mr-1.5" />
                  Use Template
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
