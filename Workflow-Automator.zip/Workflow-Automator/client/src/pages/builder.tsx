import { useState, useCallback, useEffect, useRef } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useRoute, useLocation } from "wouter";
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  addEdge,
  useNodesState,
  useEdgesState,
  type Connection,
  type Edge,
  type Node,
  BackgroundVariant,
} from "@xyflow/react";
import "@xyflow/react/dist/style.css";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import {
  Save,
  Play,
  PanelLeftClose,
  PanelLeftOpen,
  Loader2,
  ChevronUp,
  ChevronDown,
} from "lucide-react";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { CustomNode } from "@/components/editor/custom-node";
import { NodeLibrary } from "@/components/editor/node-library";
import { SettingsPanel } from "@/components/editor/settings-panel";
import { ExecutionPanel } from "@/components/editor/execution-panel";
import { getNodeDefinition } from "@/lib/node-definitions";
import type { Workflow, WorkflowRun, WorkflowNode, StepLog } from "@shared/schema";

const nodeTypes = { customNode: CustomNode };

async function parseJsonResponse<T>(res: Response, context: string): Promise<T> {
  const raw = await res.text();
  try {
    return JSON.parse(raw) as T;
  } catch {
    const snippet = raw.replace(/\s+/g, " ").trim().slice(0, 160);
    throw new Error(
      `${context} returned non-JSON response${snippet ? `: ${snippet}` : ""}`,
    );
  }
}

export default function Builder() {
  const [, params] = useRoute("/builder/:id");
  const [, navigate] = useLocation();
  const { toast } = useToast();
  const workflowId = params?.id;
  const isNew = workflowId === "new";

  const [nodes, setNodes, onNodesChange] = useNodesState([]);
  const [edges, setEdges, onEdgesChange] = useEdgesState([]);
  const [workflowName, setWorkflowName] = useState("Untitled Workflow");
  const [workflowStatus, setWorkflowStatus] = useState<"draft" | "active">("draft");
  const [selectedNodeId, setSelectedNodeId] = useState<string | null>(null);
  const [showLibrary, setShowLibrary] = useState(true);
  const [showExecution, setShowExecution] = useState(false);
  const [hasUnsavedChanges, setHasUnsavedChanges] = useState(false);
  const [lastRun, setLastRun] = useState<WorkflowRun | null>(null);
  const [isExecuting, setIsExecuting] = useState(false);
  const [currentWorkflowId, setCurrentWorkflowId] = useState<string | null>(null);
  const [isTestingNode, setIsTestingNode] = useState(false);
  const [nodeTestResult, setNodeTestResult] = useState<StepLog | null>(null);
  const [testedNodeId, setTestedNodeId] = useState<string | null>(null);
  const nodeCountRef = useRef(0);

  const { data: workflow, isLoading } = useQuery<Workflow>({
    queryKey: ["/api/workflows", workflowId],
    enabled: !isNew && !!workflowId,
  });

  useEffect(() => {
    if (workflow) {
      setNodes(workflow.nodes as Node[]);
      setEdges(workflow.edges as Edge[]);
      setWorkflowName(workflow.name);
      setWorkflowStatus(workflow.status);
      setCurrentWorkflowId(workflow.id);
      setHasUnsavedChanges(false);
    }
  }, [workflow, setNodes, setEdges]);

  useEffect(() => {
    if (isNew) {
      setNodes([]);
      setEdges([]);
      setWorkflowName("Untitled Workflow");
      setWorkflowStatus("draft");
      setHasUnsavedChanges(false);
      setCurrentWorkflowId(null);
    }
  }, [isNew, setNodes, setEdges]);

  const markUnsaved = useCallback(() => setHasUnsavedChanges(true), []);

  const onConnect = useCallback(
    (connection: Connection) => {
      setEdges((eds) => addEdge({ ...connection, id: `e-${Date.now()}` }, eds));
      markUnsaved();
    },
    [setEdges, markUnsaved]
  );

  const onNodeClick = useCallback((_: any, node: Node) => {
    setSelectedNodeId(node.id);
    setNodeTestResult(null);
    setTestedNodeId(null);
  }, []);

  const onPaneClick = useCallback(() => {
    setSelectedNodeId(null);
  }, []);

  const handleAddNode = useCallback(
    (nodeType: string) => {
      const def = getNodeDefinition(nodeType);
      if (!def) return;

      nodeCountRef.current += 1;

      const newNode: Node = {
        id: `node-${Date.now()}-${nodeCountRef.current}`,
        type: "customNode",
        position: {
          x: 180 + Math.random() * 260,
          y: 120 + Math.random() * 220,
        },
        data: {
          label: def.label,
          nodeType: def.type,
          description: def.description,
          config: def.configFields.reduce((acc, f) => {
            if (f.defaultValue !== undefined) acc[f.key] = f.defaultValue;
            return acc;
          }, {} as Record<string, any>),
        },
      };

      setNodes((nds) => [...nds, newNode]);
      markUnsaved();
    },
    [setNodes, markUnsaved]
  );

  const handleUpdateNode = useCallback(
    (nodeId: string, data: Partial<WorkflowNode["data"]>) => {
      setNodes((nds) =>
        nds.map((n) =>
          n.id === nodeId ? { ...n, data: { ...n.data, ...data } } : n
        )
      );
      markUnsaved();
    },
    [setNodes, markUnsaved]
  );

  const handleDeleteNode = useCallback(
    (nodeId: string) => {
      setNodes((nds) => nds.filter((n) => n.id !== nodeId));
      setEdges((eds) => eds.filter((e) => e.source !== nodeId && e.target !== nodeId));
      setSelectedNodeId(null);
      markUnsaved();
    },
    [setNodes, setEdges, markUnsaved]
  );

  const handleDuplicateNode = useCallback(
    (nodeId: string) => {
      const node = nodes.find((n) => n.id === nodeId);
      if (!node) return;

      nodeCountRef.current += 1;

      const newNode: Node = {
        ...node,
        id: `node-${Date.now()}-${nodeCountRef.current}`,
        position: {
          x: node.position.x + 50,
          y: node.position.y + 50,
        },
      };

      setNodes((nds) => [...nds, newNode]);
      markUnsaved();
    },
    [nodes, setNodes, markUnsaved]
  );

  const handleTestNode = useCallback(
    async (nodeId: string) => {
      if (!currentWorkflowId) {
        toast({
          title: "Save workflow first",
          description: "Save the workflow before testing individual nodes.",
          variant: "destructive",
        });
        return;
      }

      setIsTestingNode(true);
      setTestedNodeId(nodeId);
      setNodeTestResult(null);

      try {
        await apiRequest("PATCH", `/api/workflows/${currentWorkflowId}`, {
          name: workflowName,
          status: workflowStatus,
          nodes: nodes.map((n) => ({
            id: n.id,
            type: n.type,
            position: n.position,
            data: n.data,
          })),
          edges: edges.map((e) => ({
            id: e.id,
            source: e.source,
            target: e.target,
            sourceHandle: e.sourceHandle,
            targetHandle: e.targetHandle,
          })),
        });

        setHasUnsavedChanges(false);

        const res = await apiRequest(
          "POST",
          `/api/workflows/${currentWorkflowId}/execute-node`,
          {
            nodeId,
            sampleInput: { test: true, timestamp: new Date().toISOString() },
          }
        );

        const result = await parseJsonResponse<StepLog>(res, "Node test API");
        setNodeTestResult(result);

        toast({
          title: result.status === "success" ? "Node test successful" : "Node test failed",
          variant: result.status === "success" ? "default" : "destructive",
        });
      } catch (err: any) {
        toast({
          title: "Test failed",
          description: err.message,
          variant: "destructive",
        });
      } finally {
        setIsTestingNode(false);
      }
    },
    [currentWorkflowId, nodes, edges, workflowName, workflowStatus, toast]
  );

  const saveMutation = useMutation({
    mutationFn: async () => {
      const payload = {
        name: workflowName,
        status: workflowStatus,
        nodes: nodes.map((n) => ({
          id: n.id,
          type: n.type,
          position: n.position,
          data: n.data,
        })),
        edges: edges.map((e) => ({
          id: e.id,
          source: e.source,
          target: e.target,
          sourceHandle: e.sourceHandle,
          targetHandle: e.targetHandle,
        })),
      };

      if (currentWorkflowId) {
        return apiRequest("PATCH", `/api/workflows/${currentWorkflowId}`, payload);
      }

      return apiRequest("POST", "/api/workflows", payload);
    },
    onSuccess: async (res) => {
      const wf = await parseJsonResponse<Workflow>(res, "Save workflow API");
      setHasUnsavedChanges(false);
      queryClient.invalidateQueries({ queryKey: ["/api/workflows"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });

      if (!currentWorkflowId) {
        setCurrentWorkflowId(wf.id);
        navigate(`/builder/${wf.id}`, { replace: true });
      }

      toast({ title: "Workflow saved" });
    },
    onError: (err: any) => {
      toast({
        title: "Failed to save",
        description: err.message,
        variant: "destructive",
      });
    },
  });

  const executeMutation = useMutation({
    mutationFn: async () => {
      if (!currentWorkflowId) {
        const saveRes = await apiRequest("POST", "/api/workflows", {
          name: workflowName,
          status: workflowStatus,
          nodes: nodes.map((n) => ({
            id: n.id,
            type: n.type,
            position: n.position,
            data: n.data,
          })),
          edges: edges.map((e) => ({
            id: e.id,
            source: e.source,
            target: e.target,
            sourceHandle: e.sourceHandle,
            targetHandle: e.targetHandle,
          })),
        });

        const wf = await parseJsonResponse<Workflow>(saveRes, "Create workflow API");
        setCurrentWorkflowId(wf.id);
        navigate(`/builder/${wf.id}`, { replace: true });

        return apiRequest("POST", `/api/workflows/${wf.id}/execute`, {
          triggerType: "manual",
        });
      }

      await apiRequest("PATCH", `/api/workflows/${currentWorkflowId}`, {
        name: workflowName,
        status: workflowStatus,
        nodes: nodes.map((n) => ({
          id: n.id,
          type: n.type,
          position: n.position,
          data: n.data,
        })),
        edges: edges.map((e) => ({
          id: e.id,
          source: e.source,
          target: e.target,
          sourceHandle: e.sourceHandle,
          targetHandle: e.targetHandle,
        })),
      });

      setHasUnsavedChanges(false);

      return apiRequest("POST", `/api/workflows/${currentWorkflowId}/execute`, {
        triggerType: "manual",
      });
    },
    onMutate: () => {
      setIsExecuting(true);
      setShowExecution(true);
      setLastRun(null);
    },
    onSuccess: async (res) => {
      const run = await parseJsonResponse<WorkflowRun>(res, "Execute workflow API");
      setLastRun(run);
      setIsExecuting(false);
      queryClient.invalidateQueries({ queryKey: ["/api/runs"] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard"] });

      toast({
        title: run.status === "success" ? "Execution successful" : "Execution failed",
        variant: run.status === "success" ? "default" : "destructive",
      });
    },
    onError: (err: any) => {
      setIsExecuting(false);
      toast({
        title: "Execution failed",
        description: err.message,
        variant: "destructive",
      });
    },
  });

  const selectedNode = selectedNodeId
    ? nodes.find((n) => n.id === selectedNodeId)
    : null;

  const selectedNodeData = selectedNode
    ? {
        id: selectedNode.id,
        type: selectedNode.type || "customNode",
        position: selectedNode.position,
        data: selectedNode.data as WorkflowNode["data"],
      }
    : null;

  if (isLoading && !isNew) {
    return (
      <div className="h-full flex items-center justify-center bg-background">
        <Loader2 className="w-6 h-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="h-screen w-full bg-background text-foreground flex flex-col" data-testid="page-builder">
      <div className="h-14 border-b border-border bg-background px-4 flex items-center justify-between gap-4">
        <div className="flex items-center gap-3 min-w-0">
          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 rounded-md"
            onClick={() => setShowLibrary(!showLibrary)}
            data-testid="button-toggle-library"
          >
            {showLibrary ? (
              <PanelLeftClose className="w-4 h-4" />
            ) : (
              <PanelLeftOpen className="w-4 h-4" />
            )}
          </Button>

          <Input
            value={workflowName}
            onChange={(e) => {
              setWorkflowName(e.target.value);
              markUnsaved();
            }}
            className="h-10 w-[260px] rounded-lg border-border bg-background px-3 text-sm font-medium shadow-none"
            data-testid="input-workflow-name"
          />

          <div className="flex items-center gap-2 shrink-0">
            <span className="text-sm text-muted-foreground">
              {workflowStatus === "active" ? "Active" : "Draft"}
            </span>
            <Switch
              checked={workflowStatus === "active"}
              onCheckedChange={(checked) => {
                setWorkflowStatus(checked ? "active" : "draft");
                markUnsaved();
              }}
              data-testid="switch-workflow-status"
            />
          </div>

          {hasUnsavedChanges && (
            <Badge variant="secondary" className="h-6 rounded-md px-2 text-[10px]">
              Unsaved
            </Badge>
          )}
        </div>

        <div className="flex items-center gap-2 shrink-0">
          <Button
            variant="outline"
            className="h-10 rounded-lg px-4 text-sm"
            onClick={() => saveMutation.mutate()}
            disabled={saveMutation.isPending}
            data-testid="button-save-workflow"
          >
            {saveMutation.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Save className="w-4 h-4 mr-2" />
            )}
            Save
          </Button>

          <Button
            className="h-10 rounded-lg px-4 text-sm"
            onClick={() => executeMutation.mutate()}
            disabled={executeMutation.isPending || nodes.length === 0}
            data-testid="button-execute-workflow"
          >
            {executeMutation.isPending ? (
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
            ) : (
              <Play className="w-4 h-4 mr-2" />
            )}
            Execute
          </Button>

          <Button
            size="icon"
            variant="ghost"
            className="h-8 w-8 rounded-md"
            onClick={() => setShowExecution(!showExecution)}
            data-testid="button-toggle-execution"
          >
            {showExecution ? (
              <ChevronDown className="w-4 h-4" />
            ) : (
              <ChevronUp className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>

      <div className="flex flex-1 overflow-hidden">
        {showLibrary && (
          <div className="w-[320px] shrink-0 border-r border-border bg-card">
            <NodeLibrary onAddNode={handleAddNode} onClose={() => setShowLibrary(false)} />
          </div>
        )}

        <div className="flex-1 relative bg-background">
          <ReactFlow
            nodes={nodes}
            edges={edges}
            onNodesChange={(changes) => {
              onNodesChange(changes);
              markUnsaved();
            }}
            onEdgesChange={(changes) => {
              onEdgesChange(changes);
              markUnsaved();
            }}
            onConnect={onConnect}
            onNodeClick={onNodeClick}
            onPaneClick={onPaneClick}
            nodeTypes={nodeTypes}
            fitView
            deleteKeyCode={["Backspace", "Delete"]}
            className="bg-background"
            defaultEdgeOptions={{
              type: "smoothstep",
              style: {
                strokeWidth: 2,
                stroke: "hsl(var(--border))",
              },
              animated: false,
            }}
          >
            <Background
              variant={BackgroundVariant.Dots}
              gap={22}
              size={1.2}
              color="hsl(var(--border))"
            />
            <Controls className="!shadow-sm !border !border-border !bg-background !rounded-xl" />
            <MiniMap
              nodeColor={() => "hsl(var(--primary))"}
              maskColor="rgba(255,255,255,0.75)"
              className="!shadow-sm !border !border-border !bg-background !rounded-xl"
            />
          </ReactFlow>
        </div>
      </div>

      {showExecution && (
        <div className="h-[220px] shrink-0 border-t border-border bg-card">
          <ExecutionPanel run={lastRun} isRunning={isExecuting} />
        </div>
      )}

      {selectedNodeData && (
        <SettingsPanel
          node={selectedNodeData}
          onUpdate={handleUpdateNode}
          onDelete={handleDeleteNode}
          onDuplicate={handleDuplicateNode}
          onClose={() => setSelectedNodeId(null)}
          onTestNode={handleTestNode}
          isTestingNode={isTestingNode}
          nodeTestResult={testedNodeId === selectedNodeId ? nodeTestResult : null}
          lastRunSteps={lastRun?.steps}
        />
      )}
    </div>
  );
}
