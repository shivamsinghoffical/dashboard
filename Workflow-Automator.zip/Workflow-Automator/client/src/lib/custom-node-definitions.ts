import type { NodeDefinition } from "@shared/schema";

export const customNodeDefinitions: NodeDefinition[] = [];
