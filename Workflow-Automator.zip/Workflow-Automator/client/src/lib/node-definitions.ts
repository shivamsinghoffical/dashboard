import type { NodeDefinition } from "@shared/schema";
import { customNodeDefinitions } from "./custom-node-definitions";

const builtInNodeDefinitions: NodeDefinition[] = [
  {
    type: "manualTrigger",
    label: "Manual Trigger",
    description: "Starts the workflow when you execute it manually.",
    category: "Triggers",
    icon: "Play",
    color: "#22c55e",
    outputs: ["main"],
    configFields: [
      {
        key: "samplePayload",
        label: "Sample Payload",
        type: "json",
        placeholder: '{"key":"value"}',
        defaultValue: {},
      },
    ],
  },
  {
    type: "webhookTrigger",
    label: "Webhook",
    description: "Starts the workflow when an HTTP request hits the webhook URL.",
    category: "Triggers",
    icon: "Webhook",
    color: "#8b5cf6",
    outputs: ["main"],
    configFields: [
      {
        key: "path",
        label: "Path",
        type: "text",
        placeholder: "my-webhook",
        required: true,
      },
      {
        key: "method",
        label: "HTTP Method",
        type: "select",
        defaultValue: "POST",
        options: [
          { label: "GET", value: "GET" },
          { label: "POST", value: "POST" },
          { label: "PUT", value: "PUT" },
          { label: "PATCH", value: "PATCH" },
          { label: "DELETE", value: "DELETE" },
        ],
      },
      {
        key: "authentication",
        label: "Authentication",
        type: "select",
        defaultValue: "none",
        options: [
          { label: "None", value: "none" },
          { label: "Header Secret", value: "headerSecret" },
        ],
      },
      {
        key: "secretHeaderName",
        label: "Secret Header Name",
        type: "text",
        placeholder: "x-api-key",
      },
      {
        key: "secretValue",
        label: "Secret Value",
        type: "text",
        placeholder: "your-secret",
      },
      {
        key: "responseMode",
        label: "Response Mode",
        type: "select",
        defaultValue: "onReceived",
        options: [
          { label: "On Received", value: "onReceived" },
          { label: "After Workflow", value: "lastNode" },
        ],
      },
      {
        key: "samplePayload",
        label: "Sample Payload",
        type: "json",
        placeholder: '{"key":"value"}',
        defaultValue: {},
      },
    ],
  },
  {
    type: "scheduleTrigger",
    label: "Schedule Trigger",
    description: "Starts the workflow on a schedule using a cron expression.",
    category: "Triggers",
    icon: "Clock",
    color: "#f59e0b",
    outputs: ["main"],
    configFields: [
      {
        key: "schedule",
        label: "Cron Expression",
        type: "text",
        placeholder: "0 9 * * *",
        required: true,
      },
    ],
  },
  {
    type: "set",
    label: "Set",
    description: "Creates, updates, or merges values into the current item.",
    category: "Core",
    icon: "Settings2",
    color: "#3b82f6",
    outputs: ["main"],
    configFields: [
      {
        key: "keepOnlySet",
        label: "Keep Only Set",
        type: "boolean",
        defaultValue: false,
      },
      {
        key: "values",
        label: "Values (JSON)",
        type: "json",
        placeholder: '{"key":"value"}',
        defaultValue: {},
      },
    ],
  },
  {
    type: "if",
    label: "If",
    description: "Branches the workflow depending on whether a condition matches.",
    category: "Core",
    icon: "GitBranch",
    color: "#f97316",
    outputs: ["true", "false"],
    configFields: [
      {
        key: "field",
        label: "Field",
        type: "text",
        placeholder: "fieldName",
        required: true,
      },
      {
        key: "operator",
        label: "Operator",
        type: "select",
        defaultValue: "equals",
        options: [
          { label: "Equals", value: "equals" },
          { label: "Not Equals", value: "notEquals" },
          { label: "Greater Than", value: "greaterThan" },
          { label: "Less Than", value: "lessThan" },
          { label: "Contains", value: "contains" },
          { label: "Exists", value: "exists" },
          { label: "Starts With", value: "startsWith" },
          { label: "Ends With", value: "endsWith" },
        ],
      },
      {
        key: "value",
        label: "Value",
        type: "text",
        placeholder: "comparison value",
      },
    ],
  },
  {
    type: "code",
    label: "Code",
    description: "Runs custom JavaScript against the current input items.",
    category: "Core",
    icon: "Braces",
    color: "#10b981",
    outputs: ["main"],
    configFields: [
      {
        key: "mode",
        label: "Mode",
        type: "select",
        defaultValue: "runOnceForAllItems",
        options: [
          { label: "Run Once for All Items", value: "runOnceForAllItems" },
          { label: "Run Once for Each Item", value: "runOnceForEachItem" },
        ],
      },
      {
        key: "code",
        label: "JavaScript Code",
        type: "code",
        placeholder:
          '// Access input via $input or $json\n// Set result = {...} or return a value\n\nresult = { processed: true, data: $json };',
        defaultValue:
          '// Access input via $input or $json\n// Set result = {...} or return a value\n\nresult = { processed: true, data: $json };',
      },
    ],
  },
  {
    type: "delay",
    label: "Delay",
    description: "Pauses the workflow for a specified duration.",
    category: "Core",
    icon: "Timer",
    color: "#6b7280",
    outputs: ["main"],
    configFields: [
      {
        key: "ms",
        label: "Delay (ms)",
        type: "number",
        placeholder: "1000",
        defaultValue: 1000,
      },
    ],
  },
  {
    type: "jsonTransform",
    label: "JSON Transform",
    description: "Transforms data using field mapping rules.",
    category: "Core",
    icon: "Braces",
    color: "#06b6d4",
    outputs: ["main"],
    configFields: [
      {
        key: "mapping",
        label: "Mapping (JSON)",
        type: "json",
        placeholder: '{"newField":"{{$json.oldField}}"}',
        defaultValue: {},
      },
    ],
  },
  {
    type: "httpRequest",
    label: "HTTP Request",
    description: "Makes an HTTP request to an external API or endpoint.",
    category: "Developer",
    icon: "Globe",
    color: "#4f46e5",
    outputs: ["main"],
    supportedCredentials: [
      "http_bearer",
      "http_basic",
      "http_header",
      "quickbooks_oauth2",
      "google_oauth2",
      "generic_oauth2",
    ],
    configFields: [
      {
        key: "method",
        label: "Method",
        type: "select",
        defaultValue: "GET",
        options: [
          { label: "GET", value: "GET" },
          { label: "POST", value: "POST" },
          { label: "PUT", value: "PUT" },
          { label: "PATCH", value: "PATCH" },
          { label: "DELETE", value: "DELETE" },
        ],
      },
      {
        key: "url",
        label: "URL",
        type: "text",
        placeholder: "https://api.example.com/data",
        required: true,
      },
      {
        key: "authentication",
        label: "Authentication",
        type: "select",
        defaultValue: "none",
        options: [
          { label: "None", value: "none" },
          { label: "Predefined Credential Type", value: "credential" },
          { label: "Bearer Token", value: "bearer" },
          { label: "Basic Auth", value: "basic" },
          { label: "Header Auth", value: "header" },
        ],
      },
      {
        key: "sendQueryParams",
        label: "Send Query Parameters",
        type: "boolean",
        defaultValue: false,
      },
      {
        key: "queryParams",
        label: "Query Parameters (JSON)",
        type: "json",
        placeholder: '{"page":"1","limit":"100"}',
        defaultValue: {},
      },
      {
        key: "sendHeaders",
        label: "Send Headers",
        type: "boolean",
        defaultValue: false,
      },
      {
        key: "headers",
        label: "Headers (JSON)",
        type: "json",
        placeholder: '{"Content-Type":"application/json"}',
        defaultValue: {},
      },
      {
        key: "sendBody",
        label: "Send Body",
        type: "boolean",
        defaultValue: false,
      },
      {
        key: "bodyContentType",
        label: "Body Content Type",
        type: "select",
        defaultValue: "json",
        options: [
          { label: "JSON", value: "json" },
          { label: "Raw", value: "raw" },
          { label: "Form URL Encoded", value: "form-urlencoded" },
          { label: "Multipart Form Data", value: "form-data" },
        ],
      },
      {
        key: "jsonBody",
        label: "Body (JSON)",
        type: "json",
        placeholder: '{"key":"value"}',
        defaultValue: {},
      },
      {
        key: "rawBody",
        label: "Raw Body",
        type: "textarea",
        placeholder: "Raw request body",
        defaultValue: "",
      },
      {
        key: "formBody",
        label: "Form Body (JSON)",
        type: "json",
        placeholder: '{"field1":"value1","field2":"value2"}',
        defaultValue: {},
      },
      {
        key: "timeout",
        label: "Timeout (ms)",
        type: "number",
        placeholder: "30000",
        defaultValue: 30000,
      },
      {
        key: "responseFormat",
        label: "Response Format",
        type: "select",
        defaultValue: "json",
        options: [
          { label: "JSON", value: "json" },
          { label: "Text", value: "text" },
          { label: "Full Response", value: "full" },
        ],
      },
      {
        key: "retryOnFail",
        label: "Retry On Fail",
        type: "boolean",
        defaultValue: false,
      },
      {
        key: "maxRetries",
        label: "Max Retries",
        type: "number",
        placeholder: "3",
        defaultValue: 3,
      },
      {
        key: "followRedirects",
        label: "Follow Redirects",
        type: "boolean",
        defaultValue: true,
      },
    ],
  },
  {
    type: "gmail",
    label: "Gmail",
    description: "Send or read Gmail messages using Google OAuth2.",
    category: "Google",
    icon: "Mail",
    color: "#ea4335",
    outputs: ["main"],
    supportedCredentials: ["google_oauth2"],
    configFields: [
      {
        key: "operation",
        label: "Operation",
        type: "select",
        defaultValue: "send",
        options: [
          { label: "Send Email", value: "send" },
          { label: "List Messages", value: "list" },
          { label: "Get Message", value: "get" },
        ],
      },
      {
        key: "userId",
        label: "User ID",
        type: "text",
        placeholder: "me",
        defaultValue: "me",
      },
      {
        key: "to",
        label: "To",
        type: "text",
        placeholder: "recipient@example.com",
      },
      {
        key: "subject",
        label: "Subject",
        type: "text",
        placeholder: "Email subject",
      },
      {
        key: "body",
        label: "Body",
        type: "textarea",
        placeholder: "Message body text",
      },
      {
        key: "threadId",
        label: "Thread ID",
        type: "text",
        placeholder: "Optional thread ID for replies",
      },
      {
        key: "query",
        label: "Search Query",
        type: "text",
        placeholder: "from:example@domain.com",
      },
      {
        key: "maxResults",
        label: "Max Results",
        type: "number",
        defaultValue: 10,
      },
      {
        key: "messageId",
        label: "Message ID",
        type: "text",
        placeholder: "Gmail message ID",
      },
    ],
  },
  {
    type: "googleSheets",
    label: "Google Sheets",
    description: "Read and write spreadsheet ranges with Google Sheets API.",
    category: "Google",
    icon: "Table2",
    color: "#34a853",
    outputs: ["main"],
    supportedCredentials: ["google_oauth2"],
    configFields: [
      {
        key: "operation",
        label: "Operation",
        type: "select",
        defaultValue: "readRange",
        options: [
          { label: "Read Range", value: "readRange" },
          { label: "Append Values", value: "appendValues" },
          { label: "Update Values", value: "updateValues" },
          { label: "Clear Range", value: "clearRange" },
        ],
      },
      {
        key: "spreadsheetId",
        label: "Spreadsheet ID",
        type: "text",
        placeholder: "1AbC...",
        required: true,
      },
      {
        key: "range",
        label: "Range",
        type: "text",
        placeholder: "Sheet1!A1:D20",
        required: true,
      },
      {
        key: "valueInputOption",
        label: "Value Input Option",
        type: "select",
        defaultValue: "USER_ENTERED",
        options: [
          { label: "User Entered", value: "USER_ENTERED" },
          { label: "Raw", value: "RAW" },
        ],
      },
      {
        key: "majorDimension",
        label: "Major Dimension",
        type: "select",
        defaultValue: "ROWS",
        options: [
          { label: "Rows", value: "ROWS" },
          { label: "Columns", value: "COLUMNS" },
        ],
      },
      {
        key: "values",
        label: "Values (JSON Array)",
        type: "json",
        placeholder: '[["Name","Amount"],["Acme",1200]]',
        defaultValue: [],
      },
    ],
  },
  {
    type: "googleDrive",
    label: "Google Drive",
    description: "List files, create folders, and manage files in Google Drive.",
    category: "Google",
    icon: "Folder",
    color: "#4285f4",
    outputs: ["main"],
    supportedCredentials: ["google_oauth2"],
    configFields: [
      {
        key: "operation",
        label: "Operation",
        type: "select",
        defaultValue: "listFiles",
        options: [
          { label: "List Files", value: "listFiles" },
          { label: "Create Folder", value: "createFolder" },
          { label: "Delete File", value: "deleteFile" },
          { label: "Get File", value: "getFile" },
        ],
      },
      {
        key: "query",
        label: "Search Query",
        type: "text",
        placeholder: "name contains 'invoice'",
      },
      {
        key: "pageSize",
        label: "Page Size",
        type: "number",
        defaultValue: 20,
      },
      {
        key: "folderName",
        label: "Folder Name",
        type: "text",
        placeholder: "New Folder",
      },
      {
        key: "fileId",
        label: "File ID",
        type: "text",
        placeholder: "Drive file ID",
      },
    ],
  },
  {
    type: "googleCalendar",
    label: "Google Calendar",
    description: "Create and fetch calendar events using Google Calendar API.",
    category: "Google",
    icon: "CalendarDays",
    color: "#4285f4",
    outputs: ["main"],
    supportedCredentials: ["google_oauth2"],
    configFields: [
      {
        key: "operation",
        label: "Operation",
        type: "select",
        defaultValue: "listEvents",
        options: [
          { label: "List Events", value: "listEvents" },
          { label: "Create Event", value: "createEvent" },
          { label: "Delete Event", value: "deleteEvent" },
        ],
      },
      {
        key: "calendarId",
        label: "Calendar ID",
        type: "text",
        placeholder: "primary",
        defaultValue: "primary",
      },
      {
        key: "timeMin",
        label: "Time Min (ISO)",
        type: "text",
        placeholder: "2026-03-11T00:00:00Z",
      },
      {
        key: "timeMax",
        label: "Time Max (ISO)",
        type: "text",
        placeholder: "2026-03-31T23:59:59Z",
      },
      {
        key: "maxResults",
        label: "Max Results",
        type: "number",
        defaultValue: 10,
      },
      {
        key: "summary",
        label: "Summary",
        type: "text",
        placeholder: "Meeting with client",
      },
      {
        key: "description",
        label: "Description",
        type: "textarea",
        placeholder: "Event notes",
      },
      {
        key: "location",
        label: "Location",
        type: "text",
        placeholder: "Online",
      },
      {
        key: "startDateTime",
        label: "Start (ISO)",
        type: "text",
        placeholder: "2026-03-20T10:00:00Z",
      },
      {
        key: "endDateTime",
        label: "End (ISO)",
        type: "text",
        placeholder: "2026-03-20T11:00:00Z",
      },
      {
        key: "eventId",
        label: "Event ID",
        type: "text",
        placeholder: "Google event ID",
      },
    ],
  },
  {
    type: "googleDocs",
    label: "Google Docs",
    description: "Create documents, fetch docs, and append text content.",
    category: "Google",
    icon: "FileText",
    color: "#1a73e8",
    outputs: ["main"],
    supportedCredentials: ["google_oauth2"],
    configFields: [
      {
        key: "operation",
        label: "Operation",
        type: "select",
        defaultValue: "createDocument",
        options: [
          { label: "Create Document", value: "createDocument" },
          { label: "Get Document", value: "getDocument" },
          { label: "Append Text", value: "appendText" },
        ],
      },
      {
        key: "title",
        label: "Title",
        type: "text",
        placeholder: "Document title",
      },
      {
        key: "documentId",
        label: "Document ID",
        type: "text",
        placeholder: "Google document ID",
      },
      {
        key: "text",
        label: "Text",
        type: "textarea",
        placeholder: "Text to append",
      },
      {
        key: "index",
        label: "Insert Index",
        type: "number",
        defaultValue: 1,
      },
    ],
  },
  {
    type: "googleApiRequest",
    label: "Google API Request",
    description: "Call any Google REST endpoint with your Google OAuth2 credential.",
    category: "Google",
    icon: "Globe",
    color: "#1a73e8",
    outputs: ["main"],
    supportedCredentials: ["google_oauth2"],
    configFields: [
      {
        key: "method",
        label: "Method",
        type: "select",
        defaultValue: "GET",
        options: [
          { label: "GET", value: "GET" },
          { label: "POST", value: "POST" },
          { label: "PUT", value: "PUT" },
          { label: "PATCH", value: "PATCH" },
          { label: "DELETE", value: "DELETE" },
        ],
      },
      {
        key: "url",
        label: "URL",
        type: "text",
        placeholder: "https://www.googleapis.com/...",
        required: true,
      },
      {
        key: "queryParams",
        label: "Query Params (JSON)",
        type: "json",
        placeholder: '{"pageSize":"10"}',
        defaultValue: {},
      },
      {
        key: "headers",
        label: "Headers (JSON)",
        type: "json",
        placeholder: '{"X-Custom":"value"}',
        defaultValue: {},
      },
      {
        key: "body",
        label: "Body (JSON)",
        type: "json",
        placeholder: '{"name":"value"}',
        defaultValue: {},
      },
      {
        key: "timeout",
        label: "Timeout (ms)",
        type: "number",
        defaultValue: 30000,
      },
      {
        key: "responseFormat",
        label: "Response Format",
        type: "select",
        defaultValue: "json",
        options: [
          { label: "JSON", value: "json" },
          { label: "Text", value: "text" },
          { label: "Full Response", value: "full" },
        ],
      },
    ],
  },
  {
    type: "sendEmail",
    label: "Send Email",
    description: "Sends an email message using the selected provider.",
    category: "Communication",
    icon: "Mail",
    color: "#14b8a6",
    outputs: ["main"],
    configFields: [
      {
        key: "provider",
        label: "Provider",
        type: "select",
        defaultValue: "smtp",
        options: [
          { label: "SMTP", value: "smtp" },
          { label: "SendGrid", value: "sendgrid" },
          { label: "Mailgun", value: "mailgun" },
        ],
      },
      {
        key: "to",
        label: "To",
        type: "text",
        placeholder: "recipient@example.com",
        required: true,
      },
      {
        key: "subject",
        label: "Subject",
        type: "text",
        placeholder: "Email subject",
        required: true,
      },
      {
        key: "body",
        label: "Body",
        type: "textarea",
        placeholder: "Email body content",
      },
    ],
  },
  {
    type: "whatsappSend",
    label: "WhatsApp Send",
    description: "Sends a WhatsApp message using the configured provider.",
    category: "Communication",
    icon: "MessageCircle",
    color: "#22c55e",
    outputs: ["main"],
    configFields: [
      {
        key: "provider",
        label: "Provider",
        type: "select",
        defaultValue: "twilio",
        options: [
          { label: "Twilio", value: "twilio" },
          { label: "Meta", value: "meta" },
        ],
      },
      {
        key: "to",
        label: "To (Phone)",
        type: "text",
        placeholder: "+1234567890",
        required: true,
      },
      {
        key: "message",
        label: "Message",
        type: "textarea",
        placeholder: "Hello from automation!",
      },
    ],
  },
  {
    type: "openaiChat",
    label: "OpenAI Chat",
    description: "Generates text or responses using an OpenAI model.",
    category: "AI",
    icon: "Sparkles",
    color: "#a855f7",
    outputs: ["main"],
    supportedCredentials: ["openai_api"],
    configFields: [
      {
        key: "model",
        label: "Model",
        type: "select",
        defaultValue: "gpt-4o-mini",
        options: [
          { label: "GPT-4o mini", value: "gpt-4o-mini" },
          { label: "GPT-4o", value: "gpt-4o" },
          { label: "GPT-4.1", value: "gpt-4.1" },
        ],
      },
      {
        key: "systemMessage",
        label: "System Message",
        type: "textarea",
        placeholder: "You are a helpful assistant...",
      },
      {
        key: "prompt",
        label: "Prompt",
        type: "textarea",
        placeholder: "Enter your prompt. Use {{$json.field}} for expressions.",
        required: true,
      },
      {
        key: "temperature",
        label: "Temperature",
        type: "number",
        placeholder: "0.7",
        defaultValue: 0.7,
      },
    ],
  },
  {
    type: "arReminder",
    label: "AR Reminder",
    description: "Prepares or sends an accounts receivable reminder.",
    category: "Finance",
    icon: "DollarSign",
    color: "#eab308",
    outputs: ["main"],
    configFields: [
      {
        key: "customer",
        label: "Customer",
        type: "text",
        placeholder: "Acme Corp",
        required: true,
      },
      {
        key: "amount",
        label: "Amount",
        type: "number",
        placeholder: "5000",
        required: true,
      },
      {
        key: "email",
        label: "Email",
        type: "text",
        placeholder: "billing@acme.com",
        required: true,
      },
      {
        key: "daysOverdue",
        label: "Days Overdue",
        type: "number",
        placeholder: "30",
        defaultValue: 30,
      },
      {
        key: "tone",
        label: "Reminder Tone",
        type: "select",
        defaultValue: "professional",
        options: [
          { label: "Professional", value: "professional" },
          { label: "Friendly", value: "friendly" },
          { label: "Firm", value: "firm" },
        ],
      },
    ],
  },
];

function mergeNodeDefinitions(...groups: NodeDefinition[][]): NodeDefinition[] {
  const byType = new Map<string, NodeDefinition>();

  for (const group of groups) {
    for (const node of group) {
      byType.set(node.type, node);
    }
  }

  return Array.from(byType.values());
}

export const nodeDefinitions: NodeDefinition[] = mergeNodeDefinitions(
  builtInNodeDefinitions,
  customNodeDefinitions,
);

export const NODE_CATEGORY_ORDER = [
  "Triggers",
  "Core",
  "Developer",
  "Google",
  "Communication",
  "AI",
  "Finance",
] as const;

export function getNodeDefinition(type: string): NodeDefinition | undefined {
  return nodeDefinitions.find((node) => node.type === type);
}

export function getNodesByCategory(): Record<string, NodeDefinition[]> {
  const grouped: Record<string, NodeDefinition[]> = {};

  for (const category of NODE_CATEGORY_ORDER) {
    grouped[category] = [];
  }

  for (const node of nodeDefinitions) {
    if (!grouped[node.category]) {
      grouped[node.category] = [];
    }
    grouped[node.category].push(node);
  }

  return grouped;
}

export function isTriggerNode(type: string): boolean {
  return ["manualTrigger", "webhookTrigger", "scheduleTrigger"].includes(type);
}

export function getNodeColor(type: string): string {
  return getNodeDefinition(type)?.color || "#6b7280";
}

export function getNodeOutputs(type: string): string[] {
  return getNodeDefinition(type)?.outputs || ["main"];
}
