import { z } from "zod";

export interface WorkflowNode {
  id: string;
  type: string;
  position: { x: number; y: number };
  data: {
    label: string;
    nodeType: string;
    description?: string;
    config: Record<string, any>;
    credentialId?: string;
    disabled?: boolean;
    continueOnFail?: boolean;
    notes?: string;
  };
}

export interface WorkflowEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string | null;
  targetHandle?: string | null;
}

export interface Workflow {
  id: string;
  name: string;
  status: "draft" | "active";
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
  createdAt: string;
  updatedAt: string;
}

export interface StepLog {
  nodeId: string;
  nodeLabel: string;
  nodeType: string;
  status: "running" | "success" | "error" | "skipped";
  startedAt: string;
  finishedAt?: string;
  input: any;
  output: any;
  error?: string;
  branch?: string;
}

export interface WorkflowRun {
  id: string;
  workflowId: string;
  workflowName: string;
  triggerType: string;
  status: "running" | "success" | "error";
  startedAt: string;
  finishedAt?: string;
  triggerPayload?: any;
  error?: string;
  steps: StepLog[];
}

export interface NodeOption {
  label: string;
  value: string;
}

export type NodeFieldType =
  | "text"
  | "number"
  | "boolean"
  | "json"
  | "textarea"
  | "code"
  | "select";

export interface NodeConfigField {
  key: string;
  label: string;
  type: NodeFieldType;
  placeholder?: string;
  required?: boolean;
  defaultValue?: any;
  options?: NodeOption[];
}

export interface NodeDefinition {
  type: string;
  label: string;
  description: string;
  category: string;
  icon: string;
  color: string;
  outputs: string[];
  supportedCredentials?: string[];
  configFields: NodeConfigField[];
}

export interface WorkflowTemplate {
  id: string;
  name: string;
  description: string;
  category: string;
  nodes: WorkflowNode[];
  edges: WorkflowEdge[];
}

export interface DashboardStats {
  totalWorkflows: number;
  totalRuns: number;
  successfulRuns: number;
  failedRuns: number;
  recentWorkflows: Workflow[];
  recentRuns: WorkflowRun[];
}

export type CredentialType =
  | "openai_api"
  | "http_bearer"
  | "http_basic"
  | "http_header"
  | "quickbooks_oauth2"
  | "google_oauth2";

export interface Credential {
  id: string;
  name: string;
  type: CredentialType;
  data: Record<string, string>;
  createdAt: string;
  updatedAt: string;
}

export interface CredentialMasked {
  id: string;
  name: string;
  type: CredentialType;
  data: Record<string, string>;
  createdAt: string;
  updatedAt: string;
}

export interface CredentialFieldDef {
  key: string;
  label: string;
  type: "text" | "password";
  placeholder?: string;
  required?: boolean;
  readOnly?: boolean;
}

export interface CredentialTypeDef {
  type: CredentialType;
  label: string;
  description: string;
  fields: CredentialFieldDef[];
}

export const credentialTypeDefs: CredentialTypeDef[] = [
  {
    type: "openai_api",
    label: "OpenAI API Key",
    description: "API key for OpenAI services",
    fields: [
      {
        key: "apiKey",
        label: "API Key",
        type: "password",
        placeholder: "sk-...",
        required: true,
      },
    ],
  },
  {
    type: "http_bearer",
    label: "HTTP Bearer Token",
    description: "Bearer token for HTTP authentication",
    fields: [
      {
        key: "token",
        label: "Bearer Token",
        type: "password",
        placeholder: "your-token",
        required: true,
      },
    ],
  },
  {
    type: "http_basic",
    label: "HTTP Basic Auth",
    description: "Username and password for HTTP Basic authentication",
    fields: [
      {
        key: "username",
        label: "Username",
        type: "text",
        placeholder: "username",
        required: true,
      },
      {
        key: "password",
        label: "Password",
        type: "password",
        placeholder: "password",
        required: true,
      },
    ],
  },
  {
    type: "http_header",
    label: "HTTP Header Auth",
    description: "Custom header name and value",
    fields: [
      {
        key: "headerName",
        label: "Header Name",
        type: "text",
        placeholder: "X-API-Key",
        required: true,
      },
      {
        key: "headerValue",
        label: "Header Value",
        type: "password",
        placeholder: "your-api-key",
        required: true,
      },
    ],
  },
  {
    type: "quickbooks_oauth2",
    label: "QuickBooks Online OAuth2 API",
    description: "Connect QuickBooks Online using OAuth2 credentials",
    fields: [
      {
        key: "redirectUrl",
        label: "OAuth Redirect URL",
        type: "text",
        placeholder:
          "https://585d4429-e9ee-4189-a057-3c5612e070d2-00-cdim0dkt3io9.janeway.replit.dev/rest/oauth2-credential/callback",
        readOnly: true,
      },
      {
        key: "clientId",
        label: "Client ID",
        type: "text",
        placeholder: "Enter QuickBooks client ID",
        required: true,
      },
      {
        key: "clientSecret",
        label: "Client Secret",
        type: "password",
        placeholder: "Enter QuickBooks client secret",
        required: true,
      },
      {
        key: "environment",
        label: "Environment",
        type: "text",
        placeholder: "production or sandbox",
        required: true,
      },
      {
        key: "allowedDomains",
        label: "Allowed HTTP Request Domains",
        type: "text",
        placeholder: "quickbooks.api.intuit.com",
      },
      {
        key: "scope",
        label: "Scope",
        type: "text",
        placeholder: "com.intuit.quickbooks.accounting",
      },
      {
        key: "accessToken",
        label: "Access Token",
        type: "password",
      },
      {
        key: "refreshToken",
        label: "Refresh Token",
        type: "password",
      },
      {
        key: "realmId",
        label: "Realm ID",
        type: "text",
      },
      {
        key: "tokenExpiresAt",
        label: "Token Expires At",
        type: "text",
      },
    ],
  },
  {
    type: "google_oauth2",
    label: "Google OAuth2 API",
    description: "Connect Google APIs (Gmail, Sheets, Drive, Calendar, Docs) using OAuth2",
    fields: [
      {
        key: "redirectUrl",
        label: "OAuth Redirect URL",
        type: "text",
        placeholder: "https://your-app.com/api/oauth/google/callback",
        readOnly: true,
      },
      {
        key: "clientId",
        label: "Client ID",
        type: "text",
        placeholder: "Enter Google OAuth client ID",
        required: true,
      },
      {
        key: "clientSecret",
        label: "Client Secret",
        type: "password",
        placeholder: "Enter Google OAuth client secret",
        required: true,
      },
      {
        key: "scope",
        label: "Scope",
        type: "text",
        placeholder:
          "https://www.googleapis.com/auth/gmail.send https://www.googleapis.com/auth/spreadsheets",
      },
      {
        key: "accessToken",
        label: "Access Token",
        type: "password",
      },
      {
        key: "refreshToken",
        label: "Refresh Token",
        type: "password",
      },
      {
        key: "tokenExpiresAt",
        label: "Token Expires At",
        type: "text",
      },
    ],
  },
];

export const createWorkflowSchema = z.object({
  name: z.string().min(1),
  status: z.enum(["draft", "active"]).default("draft"),
  nodes: z.array(z.any()).default([]),
  edges: z.array(z.any()).default([]),
});

export const updateWorkflowSchema = z.object({
  name: z.string().min(1).optional(),
  status: z.enum(["draft", "active"]).optional(),
  nodes: z.array(z.any()).optional(),
  edges: z.array(z.any()).optional(),
});

export const createCredentialSchema = z.object({
  name: z.string().min(1),
  type: z.enum([
    "openai_api",
    "http_bearer",
    "http_basic",
    "http_header",
    "quickbooks_oauth2",
    "google_oauth2",
  ]),
  data: z.record(z.string()),
});

export const updateCredentialSchema = z.object({
  name: z.string().min(1).optional(),
  data: z.record(z.string()).optional(),
});

export type CreateWorkflow = z.infer<typeof createWorkflowSchema>;
export type UpdateWorkflow = z.infer<typeof updateWorkflowSchema>;
export type CreateCredential = z.infer<typeof createCredentialSchema>;
export type UpdateCredential = z.infer<typeof updateCredentialSchema>;
