# FlowCraft - Workflow Automation Platform

## Overview
A workflow automation platform similar to n8n, built with Express + Vite + React + TypeScript. Users can visually create workflows, drag and connect nodes on a canvas, configure each node, trigger workflows manually or by webhook, and inspect execution logs. Includes credentials management, expression engine, Code node, single-node testing, and a tabbed settings panel.

## Tech Stack
- **Backend**: Express.js with TypeScript
- **Frontend**: React 18 with TypeScript, Vite
- **UI**: Tailwind CSS, shadcn/ui components
- **Canvas**: @xyflow/react (React Flow)
- **Routing**: wouter
- **State**: @tanstack/react-query
- **Storage**: JSON file-based persistence (data/ directory)

## Architecture
```
client/src/
  App.tsx              - Main app with routing
  components/
    app-sidebar.tsx    - Navigation sidebar
    editor/
      custom-node.tsx  - React Flow custom node component
      node-library.tsx - Searchable node library panel
      settings-panel.tsx - Tabbed node config panel (Parameters, Credentials, Settings, I/O, Logs)
      execution-panel.tsx - Execution results panel
  pages/
    dashboard.tsx      - Dashboard with stats
    workflows.tsx      - Workflows list CRUD
    builder.tsx        - Main workflow editor with React Flow canvas
    run-history.tsx    - Execution history
    templates.tsx      - Pre-built workflow templates
    credentials.tsx    - Credentials management CRUD page
  lib/
    node-definitions.ts - Node type definitions and configs

server/
  index.ts             - Express server entry
  routes.ts            - All API routes (workflows, runs, credentials, templates, webhooks)
  storage.ts           - JSON file storage layer (workflows, runs, credentials)
  execution.ts         - Workflow execution engine with expression resolution, credential support, Code node
  expressions.ts       - Expression engine ({{$json.field}}, {{$node["Name"].json.field}})
  templates.ts         - Template definitions
  seed.ts              - Initial data seeding

shared/
  schema.ts            - Shared TypeScript types, Zod schemas, credential type definitions

data/                  - JSON storage files (workflows.json, runs.json, credentials.json)
```

## Node Types
- **Triggers**: Manual Trigger, Webhook Trigger, Schedule Trigger
- **Core**: Set, IF (with branching), Code (sandboxed JS), Delay, JSON Transform
- **Developer**: HTTP Request (with credential-based auth)
- **Communication**: Send Email, WhatsApp Send
- **AI**: OpenAI Chat (with credential-based API key)
- **Finance**: AR Reminder

## Credential Types
- OpenAI API Key
- HTTP Bearer Token
- HTTP Basic Auth
- HTTP Header Auth

## API Endpoints
- `GET /api/dashboard` - Dashboard stats
- `GET/POST /api/workflows` - List/create workflows
- `GET/PATCH/DELETE /api/workflows/:id` - CRUD single workflow
- `POST /api/workflows/:id/duplicate` - Duplicate workflow
- `POST /api/workflows/:id/execute` - Execute full workflow
- `POST /api/workflows/:id/execute-node` - Execute single node (test)
- `GET /api/runs` - List all runs
- `GET /api/runs/:id` - Get single run
- `GET /api/templates` - List templates
- `POST /api/templates/:id/create` - Create workflow from template
- `GET/POST /api/credentials` - List/create credentials
- `GET/PATCH/DELETE /api/credentials/:id` - CRUD single credential
- `ALL /api/webhook/:path` - Webhook trigger endpoint

## Features
- Visual workflow builder with drag-and-drop canvas
- Node library with search and categories
- Tabbed node settings panel (Parameters, Credentials, Settings, I/O, Logs)
- Credentials management system (CRUD, masked values, per-node assignment)
- Expression engine: {{$json.field}}, {{$node["NodeName"].json.field}}
- Code node with sandboxed JavaScript execution (vm module)
- Single-node test execution
- Real execution engine with IF branching, delays, HTTP requests
- Credential resolution at execution time (HTTP auth, OpenAI API key)
- Webhook trigger support with optional secret header auth
- Execution logging with step-by-step input/output
- Node settings: disable, continue-on-fail, notes
- Dashboard with run stats
- Workflow CRUD (create, edit, duplicate, delete)
- Pre-built templates
- Dark theme
