---
name: mcp-n8n
description: 'Call tools from the N8n MCP server through code_execution callbacks. Available tools: mcpN8n_executeWorkflow, mcpN8n_getWorkflowDetails, mcpN8n_searchWorkflows. Reference skill for more information.'
---

# MCP Skill: N8n

Use this skill when you need data or actions from this MCP server.

## Available Functions

### mcpN8n_executeWorkflow(...)

Execute a workflow by ID. Before executing always ensure you know the input schema by first using the get_workflow_details tool and consulting workflow description

**Parameters:**

- `workflowId` (string, required): The ID of the workflow to execute
- `inputs` (any, optional): Inputs to provide to the workflow.

**Returns:** Object with `status`, `content`, and optional metadata.

**Example:**

```javascript
const result = await mcpN8n_executeWorkflow({ workflowId: "", inputs: "" });
console.log(result);
```

### mcpN8n_getWorkflowDetails(...)

Get detailed information about a specific workflow including trigger details

**Parameters:**

- `workflowId` (string, required): The ID of the workflow to retrieve

**Returns:** Object with `status`, `content`, and optional metadata.

**Example:**

```javascript
const result = await mcpN8n_getWorkflowDetails({ workflowId: "" });
console.log(result);
```

### mcpN8n_searchWorkflows(...)

Search for workflows with optional filters. Returns a preview of each workflow.

**Parameters:**

- `limit` (integer, optional): Limit the number of results (max 200)
- `query` (string, optional): Filter by name or description
- `projectId` (string, optional)

**Returns:** Object with `status`, `content`, and optional metadata.

**Example:**

```javascript
const result = await mcpN8n_searchWorkflows({ limit: 0, query: "", projectId: "" });
console.log(result);
```

## Blocked Tools

- None

## Notes

- Call these functions directly in `code_execution` JavaScript.
- These are pre-registered callbacks available in the sandbox; no imports needed.
