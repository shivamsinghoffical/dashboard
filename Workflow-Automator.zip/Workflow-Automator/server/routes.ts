import type { Express, Request, Response } from "express";
import express from "express";
import crypto from "crypto";
import {
  createWorkflowSchema,
  updateWorkflowSchema,
  createCredentialSchema,
  updateCredentialSchema,
} from "@shared/schema";
import { storage } from "./storage";
import { executeWorkflow, executeSingleNode } from "./execution";
import { workflowTemplates } from "./templates";

function getQuickBooksAuthorizeBase() {
  return "https://appcenter.intuit.com/connect/oauth2";
}

function getQuickBooksTokenUrl() {
  return "https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer";
}

function getGoogleAuthorizeBase() {
  return "https://accounts.google.com/o/oauth2/v2/auth";
}

function getGoogleTokenUrl() {
  return "https://oauth2.googleapis.com/token";
}

function getBaseUrl(req: Request) {
  const forwardedProto = req.headers["x-forwarded-proto"];
  const proto = Array.isArray(forwardedProto)
    ? forwardedProto[0]
    : forwardedProto?.split(",")[0] || req.protocol || "http";

  const forwardedHost = req.headers["x-forwarded-host"];
  const host = Array.isArray(forwardedHost)
    ? forwardedHost[0]
    : forwardedHost || req.get("host");

  return `${proto}://${host}`;
}

function getQuickBooksRedirectUrl(req: Request) {
  return `${getBaseUrl(req)}/rest/oauth2-credential/callback`;
}

function getGoogleRedirectUrl(req: Request) {
  return `${getBaseUrl(req)}/api/oauth/google/callback`;
}

const DEFAULT_GOOGLE_SCOPE = [
  "https://www.googleapis.com/auth/gmail.send",
  "https://www.googleapis.com/auth/gmail.readonly",
  "https://www.googleapis.com/auth/spreadsheets",
  "https://www.googleapis.com/auth/drive",
  "https://www.googleapis.com/auth/calendar",
  "https://www.googleapis.com/auth/documents",
].join(" ");

export async function registerRoutes(app: Express) {
  app.use(express.json());

  app.get("/api/dashboard", async (_req, res) => {
    try {
      const workflows = await storage.getWorkflows();
      const runs = await storage.getRuns();
      const stats = {
        totalWorkflows: workflows.length,
        totalRuns: runs.length,
        successfulRuns: runs.filter((r) => r.status === "success").length,
        failedRuns: runs.filter((r) => r.status === "error").length,
        recentWorkflows: workflows.slice(-5).reverse(),
        recentRuns: runs.slice(-10).reverse(),
      };
      res.json(stats);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/templates", async (_req, res) => {
    res.json(workflowTemplates);
  });

  app.post("/api/templates/:id/create", async (req, res) => {
    try {
      const template = workflowTemplates.find((t) => t.id === req.params.id);
      if (!template) return res.status(404).json({ message: "Template not found" });
      const workflow = await storage.createWorkflow({
        name: template.name,
        status: "draft",
        nodes: template.nodes,
        edges: template.edges,
      });
      res.status(201).json(workflow);
    } catch (err: any) {
      res.status(500).json({ message: err.message });
    }
  });

  app.get("/api/workflows", async (_req, res) => {
    const workflows = await storage.getWorkflows();
    res.json(workflows);
  });

  app.get("/api/workflows/:id", async (req, res) => {
    const workflow = await storage.getWorkflow(req.params.id);
    if (!workflow) {
      return res.status(404).json({ message: "Workflow not found" });
    }
    res.json(workflow);
  });

  app.post("/api/workflows", async (req, res) => {
    const parsed = createWorkflowSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ message: parsed.error.message });
    }

    const workflow = await storage.createWorkflow(parsed.data);
    res.status(201).json(workflow);
  });

  app.patch("/api/workflows/:id", async (req, res) => {
    const parsed = updateWorkflowSchema.safeParse(req.body);
    if (!parsed.success) {
      return res.status(400).json({ message: parsed.error.message });
    }

    const workflow = await storage.updateWorkflow(req.params.id, parsed.data);
    if (!workflow) {
      return res.status(404).json({ message: "Workflow not found" });
    }

    res.json(workflow);
  });

  app.delete("/api/workflows/:id", async (req, res) => {
    const ok = await storage.deleteWorkflow(req.params.id);
    if (!ok) {
      return res.status(404).json({ message: "Workflow not found" });
    }
    res.json({ success: true });
  });

  app.post("/api/workflows/:id/duplicate", async (req, res) => {
    const workflow = await storage.duplicateWorkflow(req.params.id);
    if (!workflow) {
      return res.status(404).json({ message: "Workflow not found" });
    }
    res.status(201).json(workflow);
  });

  app.post("/api/workflows/:id/execute", async (req, res) => {
    const workflow = await storage.getWorkflow(req.params.id);
    if (!workflow) {
      return res.status(404).json({ message: "Workflow not found" });
    }

    const triggerPayload = req.body?.triggerPayload ?? {};
    const run = await executeWorkflow(workflow, triggerPayload);
    return res.status(201).json(run);
  });

  const executeNodeHandler = async (req: Request, res: Response) => {
    const workflow = await storage.getWorkflow(req.params.id);
    if (!workflow) {
      return res.status(404).json({ message: "Workflow not found" });
    }

    const nodeId = String(req.body?.nodeId || "");
    if (!nodeId) {
      return res.status(400).json({ message: "nodeId is required" });
    }

    const node = workflow.nodes.find((candidate) => candidate.id === nodeId);
    if (!node) {
      return res.status(404).json({ message: "Node not found" });
    }

    const result = await executeSingleNode(node, req.body?.sampleInput ?? {});
    return res.json(result);
  };

  app.post("/api/workflows/:id/execute-node", executeNodeHandler);
  app.post("/api/workflows/:id/test-node", executeNodeHandler);
  app.post("/api/workflows/:id/executeNode", executeNodeHandler);

  app.get("/api/runs", async (_req, res) => {
    const runs = await storage.getRuns();
    res.json(runs);
  });

  app.get("/api/runs/:id", async (req, res) => {
    const run = await storage.getRun(req.params.id);
    if (!run) {
      return res.status(404).json({ message: "Run not found" });
    }
    res.json(run);
  });

  app.get("/api/workflows/:id/runs", async (req, res) => {
    const runs = await storage.getRunsByWorkflow(req.params.id);
    res.json(runs);
  });

  app.get("/api/credentials", async (_req, res) => {
    const credentials = await storage.getCredentials();
    res.json(credentials);
  });

  app.get("/api/credentials/:id", async (req, res) => {
    const credential = await storage.getCredentialMasked(req.params.id);
    if (!credential) {
      return res.status(404).json({ message: "Credential not found" });
    }
    res.json(credential);
  });

  app.post("/api/credentials", async (req, res) => {
    const parsed = createCredentialSchema.safeParse(req.body);

    if (!parsed.success) {
      return res.status(400).json({
        message: parsed.error.message,
        issues: parsed.error.flatten(),
      });
    }

    const credential = await storage.createCredential(parsed.data);
    res.status(201).json(credential);
  });

  app.patch("/api/credentials/:id", async (req, res) => {
    const parsed = updateCredentialSchema.safeParse(req.body);

    if (!parsed.success) {
      return res.status(400).json({
        message: parsed.error.message,
        issues: parsed.error.flatten(),
      });
    }

    const credential = await storage.updateCredential(req.params.id, parsed.data);
    if (!credential) {
      return res.status(404).json({ message: "Credential not found" });
    }

    res.json(credential);
  });

  app.delete("/api/credentials/:id", async (req, res) => {
    const ok = await storage.deleteCredential(req.params.id);
    if (!ok) {
      return res.status(404).json({ message: "Credential not found" });
    }
    res.json({ success: true });
  });

  app.get("/api/credentials/:id/google/connect", async (req, res) => {
    const credential = await storage.getCredential(req.params.id);

    if (!credential || credential.type !== "google_oauth2") {
      return res.status(404).json({ message: "Google credential not found" });
    }

    const clientId = credential.data.clientId;
    const redirectUrl = getGoogleRedirectUrl(req);
    const scope = credential.data.scope || DEFAULT_GOOGLE_SCOPE;

    if (!clientId || !redirectUrl) {
      return res.status(400).json({
        message: "Missing Google clientId or redirectUrl",
      });
    }

    const statePayload = {
      credentialId: credential.id,
      nonce: crypto.randomBytes(16).toString("hex"),
      createdAt: Date.now(),
    };

    const state = Buffer.from(JSON.stringify(statePayload)).toString("base64url");

    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUrl,
      response_type: "code",
      scope,
      access_type: "offline",
      prompt: "consent",
      include_granted_scopes: "true",
      state,
    });

    const url = `${getGoogleAuthorizeBase()}?${params.toString()}`;
    return res.json({ url, redirectUrl });
  });

  app.get("/api/credentials/:id/quickbooks/connect", async (req, res) => {
    const credential = await storage.getCredential(req.params.id);

    if (!credential || credential.type !== "quickbooks_oauth2") {
      return res.status(404).json({ message: "QuickBooks credential not found" });
    }

    const clientId = credential.data.clientId;
    const redirectUrl = getQuickBooksRedirectUrl(req);
    const scope = credential.data.scope || "com.intuit.quickbooks.accounting";

    if (!clientId || !redirectUrl) {
      return res.status(400).json({
        message: "Missing QuickBooks clientId or redirectUrl",
      });
    }

    const statePayload = {
      credentialId: credential.id,
      nonce: crypto.randomBytes(16).toString("hex"),
      createdAt: Date.now(),
    };

    const state = Buffer.from(JSON.stringify(statePayload)).toString("base64url");

    const params = new URLSearchParams({
      client_id: clientId,
      response_type: "code",
      scope,
      redirect_uri: redirectUrl,
      state,
    });

    const url = `${getQuickBooksAuthorizeBase()}?${params.toString()}`;
    return res.json({ url, redirectUrl });
  });

  const handleGoogleCallback = async (req: Request, res: Response) => {
    try {
      const code = String(req.query.code || "");
      const state = String(req.query.state || "");
      const oauthError = String(req.query.error || "");

      if (oauthError) {
        return res.status(400).send(`Google OAuth failed: ${oauthError}`);
      }

      if (!code || !state) {
        return res.status(400).send("Missing code or state");
      }

      const parsedState = JSON.parse(
        Buffer.from(state, "base64url").toString("utf8"),
      ) as {
        credentialId: string;
        nonce: string;
        createdAt: number;
      };

      const credential = await storage.getCredential(parsedState.credentialId);
      if (!credential || credential.type !== "google_oauth2") {
        return res.status(404).send("Credential not found");
      }

      const clientId = credential.data.clientId;
      const clientSecret = credential.data.clientSecret;
      const redirectUrl = getGoogleRedirectUrl(req);

      if (!clientId || !clientSecret || !redirectUrl) {
        return res.status(400).send("Missing OAuth configuration");
      }

      const tokenRes = await fetch(getGoogleTokenUrl(), {
        method: "POST",
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        },
        body: new URLSearchParams({
          code,
          client_id: clientId,
          client_secret: clientSecret,
          redirect_uri: redirectUrl,
          grant_type: "authorization_code",
        }),
      });

      const tokenJson = await tokenRes.json();

      if (!tokenRes.ok) {
        console.error("Google token exchange failed:", tokenJson);
        return res.status(400).send(
          `Google token exchange failed: ${JSON.stringify(tokenJson, null, 2)}`,
        );
      }

      const expiresIn = Number(tokenJson.expires_in || 0);
      const tokenExpiresAt = expiresIn
        ? new Date(Date.now() + expiresIn * 1000).toISOString()
        : "";

      await storage.updateCredential(credential.id, {
        data: {
          accessToken: tokenJson.access_token || "",
          refreshToken: tokenJson.refresh_token || credential.data.refreshToken || "",
          tokenExpiresAt,
          redirectUrl,
          scope: credential.data.scope || DEFAULT_GOOGLE_SCOPE,
        },
      });

      return res.send(`
        <html>
          <head>
            <title>Google Connected</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 40px; background: #f8fafc; }
              .card { max-width: 520px; margin: 40px auto; background: white; border-radius: 16px; padding: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
              h1 { margin: 0 0 12px; font-size: 22px; }
              p { color: #475569; line-height: 1.5; }
              .ok { color: #15803d; font-weight: 600; }
            </style>
          </head>
          <body>
            <div class="card">
              <h1>Google connected</h1>
              <p class="ok">Authorization completed successfully.</p>
              <p>You can now close this window and return to your app.</p>
              <script>
                if (window.opener) {
                  window.opener.postMessage({ type: "google_connected" }, "*");
                }
              </script>
            </div>
          </body>
        </html>
      `);
    } catch (error) {
      console.error(error);
      return res.status(500).send("Google OAuth callback failed");
    }
  };

  const handleQuickBooksCallback = async (req: Request, res: Response) => {
    try {
      const code = String(req.query.code || "");
      const state = String(req.query.state || "");
      const realmId = String(req.query.realmId || req.query.realmid || "");

      if (!code || !state) {
        return res.status(400).send("Missing code or state");
      }

      const parsedState = JSON.parse(
        Buffer.from(state, "base64url").toString("utf8"),
      ) as {
        credentialId: string;
        nonce: string;
        createdAt: number;
      };

      const credential = await storage.getCredential(parsedState.credentialId);
      if (!credential || credential.type !== "quickbooks_oauth2") {
        return res.status(404).send("Credential not found");
      }

      const clientId = credential.data.clientId;
      const clientSecret = credential.data.clientSecret;
      const redirectUrl = getQuickBooksRedirectUrl(req);

      if (!clientId || !clientSecret || !redirectUrl) {
        return res.status(400).send("Missing OAuth configuration");
      }

      const basicAuth = Buffer.from(`${clientId}:${clientSecret}`).toString("base64");

      const tokenRes = await fetch(getQuickBooksTokenUrl(), {
        method: "POST",
        headers: {
          Authorization: `Basic ${basicAuth}`,
          "Content-Type": "application/x-www-form-urlencoded",
          Accept: "application/json",
        },
        body: new URLSearchParams({
          grant_type: "authorization_code",
          code,
          redirect_uri: redirectUrl,
        }),
      });

      const tokenJson = await tokenRes.json();

      if (!tokenRes.ok) {
        console.error("QuickBooks token exchange failed:", tokenJson);
        return res.status(400).send(
          `QuickBooks token exchange failed: ${JSON.stringify(tokenJson, null, 2)}`,
        );
      }

      const expiresIn = Number(tokenJson.expires_in || 0);
      const tokenExpiresAt = expiresIn
        ? new Date(Date.now() + expiresIn * 1000).toISOString()
        : "";

      await storage.updateCredential(credential.id, {
        data: {
          accessToken: tokenJson.access_token || "",
          refreshToken: tokenJson.refresh_token || "",
          realmId: realmId || "",
          tokenExpiresAt,
          redirectUrl,
          scope: credential.data.scope || "com.intuit.quickbooks.accounting",
        },
      });

      return res.send(`
        <html>
          <head>
            <title>QuickBooks Connected</title>
            <style>
              body { font-family: Arial, sans-serif; padding: 40px; background: #f8fafc; }
              .card { max-width: 520px; margin: 40px auto; background: white; border-radius: 16px; padding: 24px; box-shadow: 0 10px 30px rgba(0,0,0,0.08); }
              h1 { margin: 0 0 12px; font-size: 22px; }
              p { color: #475569; line-height: 1.5; }
              .ok { color: #15803d; font-weight: 600; }
            </style>
          </head>
          <body>
            <div class="card">
              <h1>QuickBooks connected</h1>
              <p class="ok">Authorization completed successfully.</p>
              <p>You can now close this window and return to your app.</p>
              <script>
                if (window.opener) {
                  window.opener.postMessage({ type: "quickbooks_connected" }, "*");
                }
              </script>
            </div>
          </body>
        </html>
      `);
    } catch (error) {
      console.error(error);
      return res.status(500).send("QuickBooks OAuth callback failed");
    }
  };

  app.get("/api/oauth/google/callback", handleGoogleCallback);
  app.get("/rest/oauth2-credential/callback", handleQuickBooksCallback);
  app.get("/api/oauth/quickbooks/callback", handleQuickBooksCallback);

  app.use("/api/{*path}", (req, res) => {
    return res.status(404).json({ message: `API route not found: ${req.originalUrl}` });
  });

  return app;
}
