import express, { type Express } from "express";
import fs from "fs";
import path from "path";

export function serveStatic(app: Express) {
  const distPath = path.resolve(__dirname, "public");

  if (!fs.existsSync(distPath)) {
    throw new Error(
      `Could not find the build directory: ${distPath}, make sure to build the client first`,
    );
  }

  app.use(express.static(distPath));

  // Any unmatched API route must return JSON, never index.html
  app.all("/api/{*path}", (req, res) => {
    return res.status(404).json({
      message: `API route not found: ${req.originalUrl}`,
    });
  });

  // Only GET requests should fall back to index.html
  app.get("/{*path}", (_req, res) => {
    res.sendFile(path.resolve(distPath, "index.html"));
  });
}