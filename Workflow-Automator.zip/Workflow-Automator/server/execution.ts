import { randomUUID } from "crypto";
import type { Workflow, WorkflowRun, StepLog, WorkflowNode, WorkflowEdge, Credential } from "@shared/schema";
import { storage } from "./storage";
import { resolveExpressions } from "./expressions";
import vm from "vm";
import { customNodeExecutors, type NodeExecutionResult } from "./custom-node-executors";

async function resolveCredential(credentialId?: string): Promise<Credential | undefined> {
  if (!credentialId) return undefined;
  return storage.getCredential(credentialId);
}

function resolveNodeConfig(
  config: Record<string, any>,
  currentInput: any,
  nodeOutputs: Map<string, any>,
  nodeLabels: Map<string, string>
): Record<string, any> {
  return resolveExpressions(config, currentInput, nodeOutputs, nodeLabels);
}

function toRecord(value: any): Record<string, any> {
  if (!value) return {};
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value);
      if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) {
        return parsed;
      }
      return {};
    } catch {
      return {};
    }
  }

  if (typeof value === "object" && !Array.isArray(value)) {
    return value;
  }

  return {};
}

function toObjectOrEmpty(value: any): Record<string, any> {
  return value && typeof value === "object" && !Array.isArray(value) ? value : {};
}

async function executeNode(
  node: WorkflowNode,
  input: any,
  nodeOutputs: Map<string, any>,
  nodeLabels: Map<string, string>,
): Promise<NodeExecutionResult> {
  const rawConfig = node.data.config || {};
  const config = resolveNodeConfig(rawConfig, input, nodeOutputs, nodeLabels);
  const nodeType = node.data.nodeType;
  const customExecutor = customNodeExecutors[nodeType];

  if (customExecutor) {
    try {
      return await customExecutor({
        node,
        input,
        rawConfig,
        config,
        nodeOutputs,
        nodeLabels,
        resolveCredential,
      });
    } catch (err: any) {
      const message = err?.message || String(err);
      return {
        output: null,
        error: `Custom node "${nodeType}" failed: ${message}`,
      };
    }
  }

  switch (nodeType) {
    case "manualTrigger":
      return { output: config.samplePayload || input || {} };

    case "webhookTrigger":
      return { output: input || config.samplePayload || {} };

    case "scheduleTrigger":
      return { output: { triggeredAt: new Date().toISOString(), schedule: config.schedule || config.cron } };

    case "set": {
      const values = toRecord(config.values);
      if (config.keepOnlySet) {
        return { output: values };
      }

      return {
        output: {
          ...toObjectOrEmpty(input),
          ...values,
        },
      };
    }

    case "if": {
      const field = config.field || "";
      const operator = config.operator || "equals";
      const value = config.value;
      const fieldValue = input?.[field];
      let result = false;

      switch (operator) {
        case "equals": result = fieldValue == value; break;
        case "notEquals": result = fieldValue != value; break;
        case "greaterThan": result = Number(fieldValue) > Number(value); break;
        case "lessThan": result = Number(fieldValue) < Number(value); break;
        case "contains": result = String(fieldValue).includes(String(value)); break;
        case "startsWith": result = String(fieldValue ?? "").startsWith(String(value ?? "")); break;
        case "endsWith": result = String(fieldValue ?? "").endsWith(String(value ?? "")); break;
        case "exists": result = fieldValue !== undefined && fieldValue !== null; break;
        default: result = fieldValue == value;
      }

      return { output: { ...input, _condition: result, _branch: result ? "true" : "false" } };
    }

    case "code": {
      const code = rawConfig.code || "";
      if (!code.trim()) return { output: input, error: "No code provided" };

      try {
        const inputCopy = JSON.parse(JSON.stringify(input || {}));
        const logs: string[] = [];

        const sandbox = Object.create(null);
        sandbox.$input = inputCopy;
        sandbox.$json = inputCopy;
        sandbox.result = undefined;
        sandbox.console = {
          log: (...args: any[]) => { logs.push(args.map(String).join(" ")); },
          error: (...args: any[]) => { logs.push("[error] " + args.map(String).join(" ")); },
          warn: (...args: any[]) => { logs.push("[warn] " + args.map(String).join(" ")); },
        };
        sandbox.JSON = { parse: JSON.parse, stringify: JSON.stringify };
        sandbox.Math = Object.freeze({ ...Math });
        sandbox.parseInt = parseInt;
        sandbox.parseFloat = parseFloat;
        sandbox.isNaN = isNaN;
        sandbox.isFinite = isFinite;
        sandbox.undefined = undefined;
        sandbox.null = null;

        const wrappedCode = `
          "use strict";
          (function() {
            ${code}
          })();
        `;

        const context = vm.createContext(sandbox, {
          codeGeneration: { strings: false, wasm: false },
        });
        const script = new vm.Script(wrappedCode, { timeout: 5000, filename: "user-code.js" });
        const scriptResult = script.runInContext(context, { timeout: 5000 });

        const output = sandbox.result !== undefined ? sandbox.result : (scriptResult !== undefined ? scriptResult : input);
        return { output: typeof output === "object" ? JSON.parse(JSON.stringify(output)) : output };
      } catch (err: any) {
        return { output: null, error: `Code execution error: ${err.message}` };
      }
    }

    case "delay": {
      const ms = Number(config.ms) || 1000;
      const waitTime = Math.min(ms, 5000);
      await new Promise((resolve) => setTimeout(resolve, waitTime));
      return { output: { ...input, delayed: true, delayMs: waitTime } };
    }

    case "jsonTransform": {
      const mapping = config.mapping || {};
      const result: Record<string, any> = {};
      for (const [key, template] of Object.entries(mapping)) {
        if (typeof template === "string") {
          result[key] = template.replace(/\{\{(\w+)\}\}/g, (_, field) => {
            return input?.[field] !== undefined ? String(input[field]) : "";
          });
        } else {
          result[key] = template;
        }
      }
      return { output: result };
    }

    case "httpRequest": {
      const method = String(config.method || "GET").toUpperCase();
      const url = String(config.url || "");
      if (!url) return { output: null, error: "URL is required" };

      try {
        const requestUrl = new URL(url);

        if (config.sendQueryParams) {
          const queryParams = toRecord(config.queryParams);
          for (const [key, value] of Object.entries(queryParams)) {
            if (value === undefined || value === null || key === "") continue;
            requestUrl.searchParams.set(key, String(value));
          }
        }

        const headers: Record<string, string> = {};
        const authentication = String(
          config.authentication || (node.data.credentialId ? "credential" : "none"),
        );

        if (authentication === "credential") {
          const credential = await resolveCredential(node.data.credentialId);
          if (credential) {
            switch (credential.type) {
              case "http_bearer":
                headers["Authorization"] = `Bearer ${credential.data.token}`;
                break;

              case "quickbooks_oauth2":
              case "google_oauth2":
                if (credential.data.accessToken) {
                  headers["Authorization"] = `Bearer ${credential.data.accessToken}`;
                }
                break;

              case "http_basic": {
                const encoded = Buffer.from(
                  `${credential.data.username}:${credential.data.password}`,
                ).toString("base64");
                headers["Authorization"] = `Basic ${encoded}`;
                break;
              }

              case "http_header":
                if (credential.data.headerName) {
                  headers[credential.data.headerName] = credential.data.headerValue || "";
                }
                break;
            }
          }
        } else if (authentication === "bearer" && config.bearerToken) {
          headers["Authorization"] = `Bearer ${String(config.bearerToken)}`;
        } else if (authentication === "basic" && config.username) {
          const encoded = Buffer.from(
            `${String(config.username)}:${String(config.password || "")}`,
          ).toString("base64");
          headers["Authorization"] = `Basic ${encoded}`;
        } else if (authentication === "header" && config.headerName) {
          headers[String(config.headerName)] = String(config.headerValue || "");
        }

        if (config.sendHeaders) {
          const customHeaders = toRecord(config.headers);
          for (const [key, value] of Object.entries(customHeaders)) {
            if (!key) continue;
            headers[key] = value == null ? "" : String(value);
          }
        }

        const fetchOptions: RequestInit = {
          method,
          headers,
          redirect: config.followRedirects === false ? "manual" : "follow",
        };

        const canSendBody = !["GET", "HEAD"].includes(method) && !!config.sendBody;
        if (canSendBody) {
          const bodyType = String(config.bodyContentType || "json");
          if (bodyType === "raw") {
            headers["Content-Type"] = headers["Content-Type"] || "text/plain";
            fetchOptions.body = String(config.rawBody || "");
          } else if (bodyType === "form-urlencoded") {
            headers["Content-Type"] =
              headers["Content-Type"] || "application/x-www-form-urlencoded";
            const params = new URLSearchParams();
            const formBody = toRecord(config.formBody);
            for (const [key, value] of Object.entries(formBody)) {
              params.set(key, value == null ? "" : String(value));
            }
            fetchOptions.body = params.toString();
          } else if (bodyType === "form-data") {
            delete headers["Content-Type"];
            delete headers["content-type"];
            const formData = new FormData();
            const formBody = toRecord(config.formBody);
            for (const [key, value] of Object.entries(formBody)) {
              formData.append(key, value == null ? "" : String(value));
            }
            fetchOptions.body = formData;
          } else {
            headers["Content-Type"] = headers["Content-Type"] || "application/json";
            fetchOptions.body = JSON.stringify(config.jsonBody ?? input ?? {});
          }
        }

        const timeoutMs = Math.max(0, Number(config.timeout) || 30000);
        const maxRetries = config.retryOnFail
          ? Math.max(0, Number(config.maxRetries) || 0)
          : 0;

        let response: Response | null = null;
        let lastError: unknown;
        for (let attempt = 0; attempt <= maxRetries; attempt += 1) {
          const controller = new AbortController();
          const timeoutHandle = timeoutMs
            ? setTimeout(() => {
                controller.abort(`Request timed out after ${timeoutMs}ms`);
              }, timeoutMs)
            : null;

          try {
            response = await fetch(requestUrl.toString(), {
              ...fetchOptions,
              signal: controller.signal,
            });

            if (response.ok || attempt === maxRetries) {
              break;
            }
          } catch (err) {
            lastError = err;
            if (attempt === maxRetries) {
              break;
            }
          } finally {
            if (timeoutHandle) clearTimeout(timeoutHandle);
          }
        }

        if (!response) {
          if (lastError instanceof Error) {
            throw lastError;
          }
          throw new Error("HTTP request failed with an unknown error");
        }

        const responseFormat = String(config.responseFormat || "full");
        const contentType = response.headers.get("content-type") || "";
        let body: any;
        if (responseFormat === "text") {
          body = await response.text();
        } else if (responseFormat === "json") {
          if (contentType.includes("application/json")) {
            body = await response.json();
          } else {
            const textBody = await response.text();
            try {
              body = JSON.parse(textBody);
            } catch {
              body = textBody;
            }
          }
        } else if (contentType.includes("application/json")) {
          body = await response.json();
        } else {
          body = await response.text();
        }

        const fullResponse = {
          statusCode: response.status,
          statusText: response.statusText,
          headers: Object.fromEntries(response.headers.entries()),
          body,
          url: requestUrl.toString(),
        };

        if (!response.ok) {
          return {
            output: fullResponse,
            error: `HTTP request failed with status ${response.status}`,
          };
        }

        if (responseFormat === "full") {
          return { output: fullResponse };
        }
        return { output: body };
      } catch (err: any) {
        return { output: null, error: `HTTP Request failed: ${err.message}` };
      }
    }

    case "sendEmail":
      if (!config.to || !config.subject) {
        return {
          output: null,
          error: "Missing required email fields: to and subject",
        };
      }

      return {
        output: {
          sent: true,
          provider: config.provider || "smtp",
          to: config.to,
          subject: config.subject,
          body: config.body,
          timestamp: new Date().toISOString(),
          note: "Email prepared for sending. Connect a real email provider to send.",
        },
      };

    case "whatsappSend":
      if (!config.to) {
        return {
          output: null,
          error: "Missing required WhatsApp field: to",
        };
      }

      return {
        output: {
          sent: true,
          provider: config.provider || "twilio",
          to: config.to,
          message: config.message,
          timestamp: new Date().toISOString(),
          note: "WhatsApp message prepared. Connect a real provider (Twilio/Meta) to send.",
        },
      };

    case "openaiChat": {
      const credential = await resolveCredential(node.data.credentialId);
      const apiKey = credential?.data?.apiKey;
      const temperature = Number(config.temperature);
      const safeTemperature = Number.isFinite(temperature) ? temperature : 0.7;

      if (apiKey) {
        try {
          const model = config.model || "gpt-4o-mini";
          const messages: any[] = [];
          if (config.systemMessage) {
            messages.push({ role: "system", content: config.systemMessage });
          }
          messages.push({ role: "user", content: config.prompt || "" });

          const resp = await fetch("https://api.openai.com/v1/chat/completions", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
              "Authorization": `Bearer ${apiKey}`,
            },
            body: JSON.stringify({ model, messages, temperature: safeTemperature }),
          });

          const data = await resp.json();
          if (data.error) {
            return { output: { error: data.error }, error: data.error.message || "OpenAI API error" };
          }

          return {
            output: {
              model,
              prompt: config.prompt,
              response: data.choices?.[0]?.message?.content || "",
              usage: data.usage,
              raw: data,
              timestamp: new Date().toISOString(),
            },
          };
        } catch (err: any) {
          return { output: null, error: `OpenAI API error: ${err.message}` };
        }
      }

      return {
        output: {
          model: config.model || "gpt-4o-mini",
          prompt: config.prompt,
          temperature: safeTemperature,
          response: `AI response placeholder for prompt: "${config.prompt || ""}". Assign an OpenAI credential to get real responses.`,
          timestamp: new Date().toISOString(),
        },
      };
    }

    case "arReminder":
      return {
        output: {
          customer: config.customer,
          amount: config.amount,
          email: config.email,
          daysOverdue: config.daysOverdue,
          tone: config.tone || "professional",
          reminderSent: true,
          message: `Payment reminder sent to ${config.customer || "customer"} for $${config.amount || 0} (${config.daysOverdue || 0} days overdue)`,
          timestamp: new Date().toISOString(),
        },
      };

    default:
      return { output: input, error: `Unsupported node type: ${nodeType}` };
  }
}

function getIncomingEdges(nodeId: string, edges: WorkflowEdge[]) {
  return edges.filter((edge) => edge.target === nodeId);
}

function getOutgoingEdges(nodeId: string, edges: WorkflowEdge[]) {
  return edges.filter((edge) => edge.source === nodeId);
}

function isTriggerNodeType(nodeType: string) {
  return ["manualTrigger", "webhookTrigger", "scheduleTrigger"].includes(nodeType);
}

function topologicalOrder(nodes: WorkflowNode[], edges: WorkflowEdge[]): WorkflowNode[] {
  const inDegree = new Map<string, number>();
  const nodeMap = new Map(nodes.map((node) => [node.id, node]));

  for (const node of nodes) {
    inDegree.set(node.id, 0);
  }

  for (const edge of edges) {
    inDegree.set(edge.target, (inDegree.get(edge.target) || 0) + 1);
  }

  const queue: string[] = [];
  for (const [id, degree] of inDegree.entries()) {
    if (degree === 0) queue.push(id);
  }

  const ordered: WorkflowNode[] = [];
  while (queue.length) {
    const id = queue.shift()!;
    const node = nodeMap.get(id);
    if (node) ordered.push(node);

    for (const edge of getOutgoingEdges(id, edges)) {
      const nextDegree = (inDegree.get(edge.target) || 0) - 1;
      inDegree.set(edge.target, nextDegree);
      if (nextDegree === 0) queue.push(edge.target);
    }
  }

  if (ordered.length !== nodes.length) {
    return nodes;
  }

  return ordered;
}

function canUseEdgeOutput(edge: WorkflowEdge, sourceOutput: any): boolean {
  const sourceBranch =
    sourceOutput && typeof sourceOutput === "object"
      ? String(sourceOutput._branch || "")
      : "";

  if (!sourceBranch) {
    return true;
  }

  const handle = edge.sourceHandle ? String(edge.sourceHandle).toLowerCase() : "";
  if (!handle) {
    // Backward compatibility for flows created before explicit branch handles.
    return sourceBranch === "true";
  }

  return handle === sourceBranch;
}

type NodeInputSelection = {
  hasInput: boolean;
  input: any;
  branch?: string;
};

function selectInputForNode(
  node: WorkflowNode,
  edges: WorkflowEdge[],
  nodeOutputs: Map<string, any>,
  defaultInput: any,
): NodeInputSelection {
  const incoming = getIncomingEdges(node.id, edges);
  if (incoming.length === 0) {
    return { hasInput: true, input: defaultInput };
  }

  const eligibleEdges = incoming.filter((edge) => {
    if (!nodeOutputs.has(edge.source)) return false;
    return canUseEdgeOutput(edge, nodeOutputs.get(edge.source));
  });

  if (eligibleEdges.length === 0) {
    return { hasInput: false, input: defaultInput };
  }

  const upstreamOutputs = eligibleEdges.map((edge) => nodeOutputs.get(edge.source));
  if (upstreamOutputs.length === 1) {
    const branch =
      upstreamOutputs[0] && typeof upstreamOutputs[0] === "object"
        ? String(upstreamOutputs[0]._branch || "")
        : "";
    return {
      hasInput: true,
      input: upstreamOutputs[0],
      branch: branch || undefined,
    };
  }

  return { hasInput: true, input: upstreamOutputs };
}

export async function executeSingleNode(
  node: WorkflowNode,
  sampleInput: any = {},
): Promise<StepLog> {
  const startedAt = new Date().toISOString();
  const nodeOutputs = new Map<string, any>();
  const nodeLabels = new Map<string, string>([[node.id, node.data.label || node.id]]);
  const result = await executeNode(node, sampleInput, nodeOutputs, nodeLabels);

  return {
    nodeId: node.id,
    nodeLabel: node.data.label || node.id,
    nodeType: node.data.nodeType,
    status: result.error ? "error" : "success",
    startedAt,
    finishedAt: new Date().toISOString(),
    input: sampleInput,
    output: result.output,
    error: result.error,
  };
}

export async function executeWorkflow(
  workflow: Workflow,
  triggerPayload?: any,
): Promise<WorkflowRun> {
  const runId = randomUUID();
  const startedAt = new Date().toISOString();

  const run: WorkflowRun = {
    id: runId,
    workflowId: workflow.id,
    workflowName: workflow.name,
    triggerType: "manual",
    status: "running",
    startedAt,
    triggerPayload,
    steps: [],
  };

  await storage.createRun(run);

  const orderedNodes = topologicalOrder(workflow.nodes, workflow.edges);
  const nodeOutputs = new Map<string, any>();
  const nodeLabels = new Map<string, string>(
    workflow.nodes.map((node) => [node.id, node.data.label || node.id]),
  );

  let workflowError: string | undefined;

  for (const node of orderedNodes) {
    const stepStartedAt = new Date().toISOString();
    const selectedInput = selectInputForNode(
      node,
      workflow.edges,
      nodeOutputs,
      triggerPayload || {},
    );
    const input = selectedInput.input;

    const stepLog: StepLog = {
      nodeId: node.id,
      nodeLabel: node.data.label || node.id,
      nodeType: node.data.nodeType,
      status: "running",
      startedAt: stepStartedAt,
      input,
      output: null,
      branch: selectedInput.branch,
    };

    run.steps.push(stepLog);
    await storage.updateRun(run.id, { steps: run.steps });

    if (!selectedInput.hasInput && !isTriggerNodeType(node.data.nodeType)) {
      stepLog.status = "skipped";
      stepLog.finishedAt = new Date().toISOString();
      stepLog.output = null;
      await storage.updateRun(run.id, { steps: run.steps });
      continue;
    }

    if (node.data.disabled) {
      stepLog.status = "skipped";
      stepLog.finishedAt = new Date().toISOString();
      stepLog.output = input;
      nodeOutputs.set(node.id, input);
      await storage.updateRun(run.id, { steps: run.steps });
      continue;
    }

    const result = await executeNode(node, input, nodeOutputs, nodeLabels);

    stepLog.output = result.output;
    stepLog.error = result.error;
    stepLog.finishedAt = new Date().toISOString();

    if (result.error) {
      stepLog.status = "error";
      nodeOutputs.set(node.id, result.output);

      if (!node.data.continueOnFail) {
        workflowError = result.error;
        break;
      }
    } else {
      stepLog.status = "success";
      nodeOutputs.set(node.id, result.output);
    }

    await storage.updateRun(run.id, { steps: run.steps });
  }

  run.status = workflowError ? "error" : "success";
  run.error = workflowError;
  run.finishedAt = new Date().toISOString();

  await storage.updateRun(run.id, {
    status: run.status,
    error: run.error,
    finishedAt: run.finishedAt,
    steps: run.steps,
  });

  const finalRun = await storage.getRun(run.id);
  return finalRun || run;
}
