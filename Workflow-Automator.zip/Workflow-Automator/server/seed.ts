import { storage } from "./storage";
import { workflowTemplates } from "./templates";

export async function seedData() {
  const existing = await storage.getWorkflows();
  if (existing.length > 0) return;

  for (const template of workflowTemplates) {
    await storage.createWorkflow({
      name: template.name,
      status: template.id === "webhook-to-api" ? "active" : "draft",
      nodes: template.nodes,
      edges: template.edges,
    });
  }

  console.log("Seeded initial workflow data");
}
