import type { WorkflowTemplate } from "@shared/schema";

export const workflowTemplates: WorkflowTemplate[] = [
  {
    id: "high-value-lead-router",
    name: "High Value Lead Router",
    description: "Route leads based on value. Sends email for high-value leads and WhatsApp for others.",
    category: "Sales",
    nodes: [
      {
        id: "trigger-1",
        type: "customNode",
        position: { x: 100, y: 200 },
        data: {
          label: "Manual Trigger",
          nodeType: "manualTrigger",
          description: "Start manually",
          config: {
            samplePayload: { lead: "Acme Corp", amount: 15000, email: "sales@acme.com" },
          },
        },
      },
      {
        id: "set-1",
        type: "customNode",
        position: { x: 350, y: 200 },
        data: {
          label: "Enrich Lead",
          nodeType: "set",
          description: "Add lead score",
          config: { values: { scored: true, priority: "high" } },
        },
      },
      {
        id: "if-1",
        type: "customNode",
        position: { x: 600, y: 200 },
        data: {
          label: "Check Amount",
          nodeType: "if",
          description: "Route by value",
          config: { field: "amount", operator: "greaterThan", value: "10000" },
        },
      },
      {
        id: "email-1",
        type: "customNode",
        position: { x: 900, y: 100 },
        data: {
          label: "Send Email",
          nodeType: "sendEmail",
          description: "Email high-value lead",
          config: {
            provider: "smtp",
            to: "{{email}}",
            subject: "High Value Lead: {{lead}}",
            body: "New high-value lead from {{lead}} worth ${{amount}}",
          },
        },
      },
      {
        id: "whatsapp-1",
        type: "customNode",
        position: { x: 900, y: 320 },
        data: {
          label: "WhatsApp Alert",
          nodeType: "whatsappSend",
          description: "Alert via WhatsApp",
          config: {
            provider: "twilio",
            to: "+1234567890",
            message: "New lead: {{lead}} - ${{amount}}",
          },
        },
      },
    ],
    edges: [
      { id: "e1", source: "trigger-1", target: "set-1" },
      { id: "e2", source: "set-1", target: "if-1" },
      { id: "e3", source: "if-1", target: "email-1", sourceHandle: "true" },
      { id: "e4", source: "if-1", target: "whatsapp-1", sourceHandle: "false" },
    ],
  },
  {
    id: "webhook-to-api",
    name: "Webhook to API",
    description: "Receive webhook data, transform it, and forward to an external API.",
    category: "Integration",
    nodes: [
      {
        id: "webhook-1",
        type: "customNode",
        position: { x: 100, y: 200 },
        data: {
          label: "Webhook Trigger",
          nodeType: "webhookTrigger",
          description: "Receive webhook",
          config: {
            path: "lead-capture",
            method: "POST",
            authentication: "none",
            responseMode: "onReceived",
            samplePayload: { lead: "Acme", amount: 7500, email: "sales@example.com" },
          },
        },
      },
      {
        id: "transform-1",
        type: "customNode",
        position: { x: 400, y: 200 },
        data: {
          label: "Transform Data",
          nodeType: "jsonTransform",
          description: "Map fields",
          config: {
            mapping: {
              company_name: "{{lead}}",
              deal_value: "{{amount}}",
              contact_email: "{{email}}",
            },
          },
        },
      },
      {
        id: "http-1",
        type: "customNode",
        position: { x: 700, y: 200 },
        data: {
          label: "Send to CRM",
          nodeType: "httpRequest",
          description: "POST to CRM API",
          config: {
            method: "POST",
            url: "https://httpbin.org/post",
            headers: {},
          },
        },
      },
    ],
    edges: [
      { id: "e1", source: "webhook-1", target: "transform-1" },
      { id: "e2", source: "transform-1", target: "http-1" },
    ],
  },
  {
    id: "scheduled-ar-reminder",
    name: "Scheduled AR Reminder",
    description: "Send automated accounts receivable reminders on a schedule with AI-generated messages.",
    category: "Finance",
    nodes: [
      {
        id: "schedule-1",
        type: "customNode",
        position: { x: 100, y: 200 },
        data: {
          label: "Daily Schedule",
          nodeType: "scheduleTrigger",
          description: "Run daily at 9 AM",
          config: { schedule: "0 9 * * *" },
        },
      },
      {
        id: "ai-1",
        type: "customNode",
        position: { x: 400, y: 200 },
        data: {
          label: "Generate Message",
          nodeType: "openaiChat",
          description: "AI-generated reminder",
          config: {
            model: "gpt-3.5-turbo",
            prompt: "Write a professional payment reminder for an overdue invoice",
          },
        },
      },
      {
        id: "ar-1",
        type: "customNode",
        position: { x: 700, y: 200 },
        data: {
          label: "Send AR Reminder",
          nodeType: "arReminder",
          description: "Send payment reminder",
          config: {
            customer: "Acme Corp",
            amount: "5000",
            email: "billing@acme.com",
            daysOverdue: "30",
          },
        },
      },
    ],
    edges: [
      { id: "e1", source: "schedule-1", target: "ai-1" },
      { id: "e2", source: "ai-1", target: "ar-1" },
    ],
  },
];
