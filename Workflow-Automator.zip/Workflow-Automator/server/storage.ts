import { randomUUID } from "crypto";
import fs from "fs";
import path from "path";
import type {
  Workflow,
  WorkflowRun,
  Credential,
  CredentialMasked,
  CreateWorkflow,
  UpdateWorkflow,
  CreateCredential,
  UpdateCredential,
  WorkflowNode,
} from "@shared/schema";

const dataDir = path.join(process.cwd(), "data");
const workflowsFile = path.join(dataDir, "workflows.json");
const runsFile = path.join(dataDir, "runs.json");
const credentialsFile = path.join(dataDir, "credentials.json");

const SECRET_KEYS = new Set([
  "apiKey",
  "token",
  "password",
  "clientSecret",
  "headerValue",
  "accessToken",
  "refreshToken",
]);

function ensureDataDir() {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
}

function readJsonFile<T>(filePath: string, fallback: T): T {
  try {
    if (!fs.existsSync(filePath)) return fallback;
    const raw = fs.readFileSync(filePath, "utf-8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

function writeJsonFile<T>(filePath: string, value: T) {
  ensureDataDir();
  fs.writeFileSync(filePath, JSON.stringify(value, null, 2), "utf-8");
}

function maskSecrets(data: Record<string, string>): Record<string, string> {
  const masked: Record<string, string> = {};
  for (const [key, value] of Object.entries(data || {})) {
    masked[key] = SECRET_KEYS.has(key) && value ? "********" : value;
  }
  return masked;
}

function mergeCredentialData(
  existingData: Record<string, string>,
  nextData: Record<string, string>,
): Record<string, string> {
  const merged = { ...(existingData || {}) };

  for (const [key, value] of Object.entries(nextData || {})) {
    if (SECRET_KEYS.has(key) && value === "") {
      continue;
    }
    merged[key] = value;
  }

  return merged;
}

class FileStorage {
  constructor() {
    ensureDataDir();
  }

  async getWorkflows(): Promise<Workflow[]> {
    return readJsonFile<Workflow[]>(workflowsFile, []);
  }

  async getWorkflow(id: string): Promise<Workflow | undefined> {
    const workflows = await this.getWorkflows();
    return workflows.find((workflow) => workflow.id === id);
  }

  async createWorkflow(data: CreateWorkflow): Promise<Workflow> {
    const workflows = await this.getWorkflows();
    const now = new Date().toISOString();

    const workflow: Workflow = {
      id: randomUUID(),
      name: data.name,
      status: data.status || "draft",
      nodes: data.nodes || [],
      edges: data.edges || [],
      createdAt: now,
      updatedAt: now,
    };

    workflows.push(workflow);
    writeJsonFile(workflowsFile, workflows);
    return workflow;
  }

  async updateWorkflow(id: string, data: UpdateWorkflow): Promise<Workflow | undefined> {
    const workflows = await this.getWorkflows();
    const index = workflows.findIndex((workflow) => workflow.id === id);
    if (index === -1) return undefined;

    workflows[index] = {
      ...workflows[index],
      ...data,
      updatedAt: new Date().toISOString(),
    };

    writeJsonFile(workflowsFile, workflows);
    return workflows[index];
  }

  async deleteWorkflow(id: string): Promise<boolean> {
    const workflows = await this.getWorkflows();
    const filtered = workflows.filter((workflow) => workflow.id !== id);
    if (filtered.length === workflows.length) return false;
    writeJsonFile(workflowsFile, filtered);
    return true;
  }

  async duplicateWorkflow(id: string): Promise<Workflow | undefined> {
    const workflow = await this.getWorkflow(id);
    if (!workflow) return undefined;

    return this.createWorkflow({
      name: `${workflow.name} (Copy)`,
      status: "draft",
      nodes: workflow.nodes,
      edges: workflow.edges,
    });
  }

  async getRuns(): Promise<WorkflowRun[]> {
    return readJsonFile<WorkflowRun[]>(runsFile, []);
  }

  async getRun(id: string): Promise<WorkflowRun | undefined> {
    const runs = await this.getRuns();
    return runs.find((run) => run.id === id);
  }

  async getRunsByWorkflow(workflowId: string): Promise<WorkflowRun[]> {
    const runs = await this.getRuns();
    return runs.filter((run) => run.workflowId === workflowId);
  }

  async createRun(run: WorkflowRun): Promise<WorkflowRun> {
    const runs = await this.getRuns();
    runs.push(run);
    writeJsonFile(runsFile, runs);
    return run;
  }

  async updateRun(id: string, data: Partial<WorkflowRun>): Promise<WorkflowRun | undefined> {
    const runs = await this.getRuns();
    const index = runs.findIndex((run) => run.id === id);
    if (index === -1) return undefined;

    runs[index] = {
      ...runs[index],
      ...data,
    };

    writeJsonFile(runsFile, runs);
    return runs[index];
  }

  async getCredentials(): Promise<CredentialMasked[]> {
    const credentials = readJsonFile<Credential[]>(credentialsFile, []);
    return credentials.map((credential) => ({
      ...credential,
      data: maskSecrets(credential.data || {}),
    }));
  }

  async getCredential(id: string): Promise<Credential | undefined> {
    const credentials = readJsonFile<Credential[]>(credentialsFile, []);
    return credentials.find((credential) => credential.id === id);
  }

  async getCredentialMasked(id: string): Promise<CredentialMasked | undefined> {
    const credential = await this.getCredential(id);
    if (!credential) return undefined;

    return {
      ...credential,
      data: maskSecrets(credential.data || {}),
    };
  }

  async createCredential(data: CreateCredential): Promise<CredentialMasked> {
    const credentials = readJsonFile<Credential[]>(credentialsFile, []);
    const now = new Date().toISOString();

    const credential: Credential = {
      id: randomUUID(),
      name: data.name,
      type: data.type,
      data: data.data || {},
      createdAt: now,
      updatedAt: now,
    };

    credentials.push(credential);
    writeJsonFile(credentialsFile, credentials);

    return {
      ...credential,
      data: maskSecrets(credential.data || {}),
    };
  }

  async updateCredential(id: string, data: UpdateCredential): Promise<CredentialMasked | undefined> {
    const credentials = readJsonFile<Credential[]>(credentialsFile, []);
    const index = credentials.findIndex((credential) => credential.id === id);
    if (index === -1) return undefined;

    const current = credentials[index];
    const nextData = data.data
      ? mergeCredentialData(current.data || {}, data.data)
      : current.data;

    credentials[index] = {
      ...current,
      ...data,
      data: nextData,
      updatedAt: new Date().toISOString(),
    };

    writeJsonFile(credentialsFile, credentials);

    return {
      ...credentials[index],
      data: maskSecrets(credentials[index].data || {}),
    };
  }

  async deleteCredential(id: string): Promise<boolean> {
    const credentials = readJsonFile<Credential[]>(credentialsFile, []);
    const filteredCredentials = credentials.filter((credential) => credential.id !== id);
    if (filteredCredentials.length === credentials.length) return false;

    writeJsonFile(credentialsFile, filteredCredentials);

    const workflows = await this.getWorkflows();
    let changed = false;

    const updatedWorkflows = workflows.map((workflow) => {
      let workflowChanged = false;

      const updatedNodes: WorkflowNode[] = workflow.nodes.map((node) => {
        if (node.data?.credentialId !== id) return node;

        workflowChanged = true;
        changed = true;

        return {
          ...node,
          data: {
            ...node.data,
            credentialId: undefined,
          },
        };
      });

      if (!workflowChanged) return workflow;

      return {
        ...workflow,
        nodes: updatedNodes,
        updatedAt: new Date().toISOString(),
      };
    });

    if (changed) {
      writeJsonFile(workflowsFile, updatedWorkflows);
    }

    return true;
  }
}

export const storage = new FileStorage();