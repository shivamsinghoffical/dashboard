import type { StepLog } from "@shared/schema";

export function resolveExpressions(
  value: any,
  currentInput: any,
  nodeOutputs: Map<string, any>,
  nodeLabels: Map<string, string>
): any {
  if (typeof value === "string") {
    return resolveStringExpression(value, currentInput, nodeOutputs, nodeLabels);
  }
  if (Array.isArray(value)) {
    return value.map((v) => resolveExpressions(v, currentInput, nodeOutputs, nodeLabels));
  }
  if (value && typeof value === "object") {
    const result: Record<string, any> = {};
    for (const [k, v] of Object.entries(value)) {
      result[k] = resolveExpressions(v, currentInput, nodeOutputs, nodeLabels);
    }
    return result;
  }
  return value;
}

function resolveStringExpression(
  str: string,
  currentInput: any,
  nodeOutputs: Map<string, any>,
  nodeLabels: Map<string, string>
): string {
  return str.replace(/\{\{(.*?)\}\}/g, (match, expr) => {
    try {
      const trimmed = expr.trim();
      return evaluateExpression(trimmed, currentInput, nodeOutputs, nodeLabels);
    } catch {
      return match;
    }
  });
}

function evaluateExpression(
  expr: string,
  currentInput: any,
  nodeOutputs: Map<string, any>,
  nodeLabels: Map<string, string>
): string {
  if (expr === "$json") {
    return JSON.stringify(currentInput);
  }

  if (expr.startsWith("$json.")) {
    const path = expr.slice(6);
    const val = getNestedValue(currentInput, path);
    return val !== undefined ? String(val) : "";
  }

  if (expr.startsWith("$json[")) {
    const path = expr.slice(5);
    const val = resolvePathWithBrackets(currentInput, path);
    return val !== undefined ? String(val) : "";
  }

  const nodeRefMatch = expr.match(/^\$node\[["'](.+?)["']\]\.json(?:\.(.+))?$/);
  if (nodeRefMatch) {
    const nodeName = nodeRefMatch[1];
    const path = nodeRefMatch[2];

    let nodeOutput: any = null;
    for (const [nodeId, output] of nodeOutputs.entries()) {
      const label = nodeLabels.get(nodeId);
      if (label === nodeName) {
        nodeOutput = output;
        break;
      }
    }

    if (nodeOutput === null) return "";

    if (!path) return JSON.stringify(nodeOutput);
    const val = getNestedValue(nodeOutput, path);
    return val !== undefined ? String(val) : "";
  }

  const simpleFieldMatch = expr.match(/^(\w+)$/);
  if (simpleFieldMatch) {
    const val = currentInput?.[simpleFieldMatch[1]];
    return val !== undefined ? String(val) : "";
  }

  return "";
}

function getNestedValue(obj: any, path: string): any {
  const parts = path.split(".");
  let current = obj;
  for (const part of parts) {
    if (current === null || current === undefined) return undefined;
    const bracketMatch = part.match(/^(\w+)\[(\d+)\]$/);
    if (bracketMatch) {
      current = current[bracketMatch[1]];
      if (Array.isArray(current)) {
        current = current[parseInt(bracketMatch[2])];
      } else {
        return undefined;
      }
    } else {
      current = current[part];
    }
  }
  return current;
}

function resolvePathWithBrackets(obj: any, path: string): any {
  const parts: string[] = [];
  let remaining = path;
  while (remaining.length > 0) {
    const bracketMatch = remaining.match(/^\["(.+?)"\]\.?/);
    if (bracketMatch) {
      parts.push(bracketMatch[1]);
      remaining = remaining.slice(bracketMatch[0].length);
      continue;
    }
    const dotMatch = remaining.match(/^\.?(\w+)\.?/);
    if (dotMatch) {
      parts.push(dotMatch[1]);
      remaining = remaining.slice(dotMatch[0].length);
      continue;
    }
    break;
  }

  let current = obj;
  for (const part of parts) {
    if (current === null || current === undefined) return undefined;
    current = current[part];
  }
  return current;
}
