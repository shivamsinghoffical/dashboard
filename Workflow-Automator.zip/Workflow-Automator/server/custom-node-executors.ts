import type { Credential, WorkflowNode } from "@shared/schema";
import { storage } from "./storage";

export type NodeExecutionResult = { output: any; error?: string };

export interface CustomNodeExecutionContext {
  node: WorkflowNode;
  input: any;
  rawConfig: Record<string, any>;
  config: Record<string, any>;
  nodeOutputs: Map<string, any>;
  nodeLabels: Map<string, string>;
  resolveCredential: (credentialId?: string) => Promise<Credential | undefined>;
}

export type CustomNodeExecutor = (
  context: CustomNodeExecutionContext,
) => Promise<NodeExecutionResult> | NodeExecutionResult;

function isPlainObject(value: unknown): value is Record<string, unknown> {
  return !!value && typeof value === "object" && !Array.isArray(value);
}

function toRecord(value: unknown): Record<string, unknown> {
  if (!value) return {};
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value) as unknown;
      return isPlainObject(parsed) ? parsed : {};
    } catch {
      return {};
    }
  }
  return isPlainObject(value) ? value : {};
}

function toArray(value: unknown): unknown[] {
  if (Array.isArray(value)) return value;
  if (typeof value === "string") {
    try {
      const parsed = JSON.parse(value) as unknown;
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }
  return [];
}

function toStringValue(value: unknown, fallback = ""): string {
  if (value === undefined || value === null) return fallback;
  return String(value);
}

function toNumberValue(value: unknown, fallback: number): number {
  const n = Number(value);
  return Number.isFinite(n) ? n : fallback;
}

function requireString(value: unknown, fieldLabel: string): string {
  const str = toStringValue(value).trim();
  if (!str) {
    throw new Error(`${fieldLabel} is required`);
  }
  return str;
}

function toBase64Url(text: string): string {
  return Buffer.from(text, "utf8")
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/g, "");
}

function isGoogleTokenExpired(credential: Credential): boolean {
  const expiresAt = credential.data.tokenExpiresAt;
  if (!expiresAt) {
    return !credential.data.accessToken;
  }

  const expiresAtMs = Date.parse(expiresAt);
  if (!Number.isFinite(expiresAtMs)) {
    return !credential.data.accessToken;
  }

  return Date.now() >= expiresAtMs - 60_000;
}

async function refreshGoogleAccessTokenIfNeeded(
  credential: Credential,
): Promise<Credential> {
  if (credential.type !== "google_oauth2") {
    return credential;
  }

  if (!isGoogleTokenExpired(credential)) {
    return credential;
  }

  const refreshToken = credential.data.refreshToken;
  const clientId = credential.data.clientId;
  const clientSecret = credential.data.clientSecret;

  if (!refreshToken || !clientId || !clientSecret) {
    return credential;
  }

  const tokenRes = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
      Accept: "application/json",
    },
    body: new URLSearchParams({
      grant_type: "refresh_token",
      refresh_token: refreshToken,
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });

  const tokenJson = (await tokenRes.json()) as Record<string, unknown>;

  if (!tokenRes.ok || !tokenJson.access_token) {
    const details = JSON.stringify(tokenJson);
    throw new Error(`Google token refresh failed: ${details}`);
  }

  const expiresIn = toNumberValue(tokenJson.expires_in, 0);
  const tokenExpiresAt = expiresIn
    ? new Date(Date.now() + expiresIn * 1000).toISOString()
    : credential.data.tokenExpiresAt || "";

  const updateData: Record<string, string> = {
    accessToken: toStringValue(tokenJson.access_token),
    tokenExpiresAt,
  };

  if (tokenJson.refresh_token) {
    updateData.refreshToken = toStringValue(tokenJson.refresh_token);
  }

  await storage.updateCredential(credential.id, { data: updateData });

  return {
    ...credential,
    data: {
      ...credential.data,
      ...updateData,
    },
  };
}

async function getGoogleCredential(
  context: CustomNodeExecutionContext,
): Promise<Credential> {
  const credentialId = context.node.data.credentialId;
  const credential = await context.resolveCredential(credentialId);

  if (!credential) {
    throw new Error("Google OAuth2 credential is required for this node");
  }

  if (credential.type !== "google_oauth2") {
    throw new Error(`Expected google_oauth2 credential, got "${credential.type}"`);
  }

  const refreshed = await refreshGoogleAccessTokenIfNeeded(credential);
  if (!refreshed.data.accessToken) {
    throw new Error("Google access token missing. Connect your Google credential first");
  }

  return refreshed;
}

async function parseResponsePayload(response: Response): Promise<unknown> {
  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return response.json();
  }

  const text = await response.text();
  if (!text) return "";

  try {
    return JSON.parse(text) as unknown;
  } catch {
    return text;
  }
}

type GoogleResponseFormat = "json" | "text" | "full";

interface GoogleApiRequestOptions {
  method?: string;
  url: string;
  query?: Record<string, unknown>;
  headers?: Record<string, string>;
  body?: unknown;
  timeoutMs?: number;
  responseFormat?: GoogleResponseFormat;
}

async function googleApiRequest(
  context: CustomNodeExecutionContext,
  options: GoogleApiRequestOptions,
): Promise<unknown> {
  const credential = await getGoogleCredential(context);
  const method = toStringValue(options.method || "GET").toUpperCase();
  const timeoutMs = Math.max(0, toNumberValue(options.timeoutMs, 30000));
  const responseFormat: GoogleResponseFormat = options.responseFormat || "json";

  const url = new URL(options.url);
  for (const [key, value] of Object.entries(options.query || {})) {
    if (!key || value === undefined || value === null) continue;
    url.searchParams.set(key, String(value));
  }

  const headers: Record<string, string> = {
    Authorization: `Bearer ${credential.data.accessToken}`,
    Accept: "application/json",
    ...(options.headers || {}),
  };

  const fetchOptions: RequestInit = {
    method,
    headers,
  };

  if (!["GET", "HEAD"].includes(method) && options.body !== undefined) {
    if (!headers["Content-Type"] && !headers["content-type"]) {
      headers["Content-Type"] = "application/json";
    }
    fetchOptions.body =
      typeof options.body === "string" ? options.body : JSON.stringify(options.body);
  }

  const controller = new AbortController();
  const timeoutHandle = timeoutMs
    ? setTimeout(() => {
        controller.abort(`Google request timed out after ${timeoutMs}ms`);
      }, timeoutMs)
    : null;

  try {
    const response = await fetch(url.toString(), {
      ...fetchOptions,
      signal: controller.signal,
    });
    const payload = await parseResponsePayload(response);

    if (!response.ok) {
      const details =
        typeof payload === "string" ? payload : JSON.stringify(payload, null, 2);
      throw new Error(`Google API ${response.status} ${response.statusText}: ${details}`);
    }

    if (responseFormat === "full") {
      return {
        status: response.status,
        statusText: response.statusText,
        headers: Object.fromEntries(response.headers.entries()),
        body: payload,
      };
    }

    if (responseFormat === "text") {
      return typeof payload === "string" ? payload : JSON.stringify(payload);
    }

    return payload;
  } finally {
    if (timeoutHandle) clearTimeout(timeoutHandle);
  }
}

const myCompanyPing: CustomNodeExecutor = async ({ config, input }) => {
  const safeInput =
    input && typeof input === "object" && !Array.isArray(input) ? input : {};

  return {
    output: {
      ...safeInput,
      ok: true,
      message: String(config.message || "alive"),
      timestamp: new Date().toISOString(),
    },
  };
};

const gmail: CustomNodeExecutor = async (context) => {
  const operation = toStringValue(context.config.operation, "send");
  const userId = encodeURIComponent(toStringValue(context.config.userId, "me"));

  if (operation === "send") {
    const to = requireString(context.config.to, "To");
    const subject = requireString(context.config.subject, "Subject");
    const body = toStringValue(context.config.body, "");
    const threadId = toStringValue(context.config.threadId, "").trim();

    const emailRaw = [
      `To: ${to}`,
      "Content-Type: text/plain; charset=utf-8",
      "MIME-Version: 1.0",
      `Subject: ${subject}`,
      "",
      body,
    ].join("\r\n");

    const payload: Record<string, unknown> = {
      raw: toBase64Url(emailRaw),
    };
    if (threadId) {
      payload.threadId = threadId;
    }

    const result = await googleApiRequest(context, {
      method: "POST",
      url: `https://gmail.googleapis.com/gmail/v1/users/${userId}/messages/send`,
      body: payload,
    });

    return { output: result };
  }

  if (operation === "list") {
    const query: Record<string, unknown> = {
      maxResults: toNumberValue(context.config.maxResults, 10),
    };
    const q = toStringValue(context.config.query, "").trim();
    if (q) query.q = q;

    const result = await googleApiRequest(context, {
      method: "GET",
      url: `https://gmail.googleapis.com/gmail/v1/users/${userId}/messages`,
      query,
    });

    return { output: result };
  }

  if (operation === "get") {
    const messageId = requireString(context.config.messageId, "Message ID");
    const result = await googleApiRequest(context, {
      method: "GET",
      url: `https://gmail.googleapis.com/gmail/v1/users/${userId}/messages/${encodeURIComponent(messageId)}`,
      query: { format: "full" },
    });

    return { output: result };
  }

  throw new Error(`Unsupported Gmail operation "${operation}"`);
};

const googleSheets: CustomNodeExecutor = async (context) => {
  const operation = toStringValue(context.config.operation, "readRange");
  const spreadsheetId = requireString(context.config.spreadsheetId, "Spreadsheet ID");
  const range = requireString(context.config.range, "Range");
  const encodedRange = encodeURIComponent(range);

  if (operation === "readRange") {
    const result = await googleApiRequest(context, {
      method: "GET",
      url: `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values/${encodedRange}`,
      query: {
        majorDimension: toStringValue(context.config.majorDimension, "ROWS"),
      },
    });

    return { output: result };
  }

  if (operation === "appendValues" || operation === "updateValues") {
    const configuredValues = toArray(context.config.values);
    const fallbackValues = Array.isArray(context.input) ? context.input : [];
    const values = configuredValues.length > 0 ? configuredValues : fallbackValues;
    if (!Array.isArray(values) || values.length === 0) {
      throw new Error("Values must be a non-empty JSON array");
    }

    const valueInputOption = toStringValue(context.config.valueInputOption, "USER_ENTERED");
    const majorDimension = toStringValue(context.config.majorDimension, "ROWS");

    const result = await googleApiRequest(context, {
      method: operation === "appendValues" ? "POST" : "PUT",
      url:
        operation === "appendValues"
          ? `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values/${encodedRange}:append`
          : `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values/${encodedRange}`,
      query: { valueInputOption },
      body: {
        majorDimension,
        values,
      },
    });

    return { output: result };
  }

  if (operation === "clearRange") {
    const result = await googleApiRequest(context, {
      method: "POST",
      url: `https://sheets.googleapis.com/v4/spreadsheets/${encodeURIComponent(spreadsheetId)}/values/${encodedRange}:clear`,
      body: {},
    });

    return { output: result };
  }

  throw new Error(`Unsupported Google Sheets operation "${operation}"`);
};

const googleDrive: CustomNodeExecutor = async (context) => {
  const operation = toStringValue(context.config.operation, "listFiles");

  if (operation === "listFiles") {
    const query: Record<string, unknown> = {
      pageSize: toNumberValue(context.config.pageSize, 20),
      fields: "files(id,name,mimeType,modifiedTime,webViewLink),nextPageToken",
    };
    const q = toStringValue(context.config.query, "").trim();
    if (q) query.q = q;

    const result = await googleApiRequest(context, {
      method: "GET",
      url: "https://www.googleapis.com/drive/v3/files",
      query,
    });
    return { output: result };
  }

  if (operation === "createFolder") {
    const folderName = requireString(context.config.folderName, "Folder Name");
    const result = await googleApiRequest(context, {
      method: "POST",
      url: "https://www.googleapis.com/drive/v3/files",
      body: {
        name: folderName,
        mimeType: "application/vnd.google-apps.folder",
      },
    });
    return { output: result };
  }

  if (operation === "deleteFile") {
    const fileId = requireString(context.config.fileId, "File ID");
    await googleApiRequest(context, {
      method: "DELETE",
      url: `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}`,
      responseFormat: "full",
    });
    return { output: { deleted: true, fileId } };
  }

  if (operation === "getFile") {
    const fileId = requireString(context.config.fileId, "File ID");
    const result = await googleApiRequest(context, {
      method: "GET",
      url: `https://www.googleapis.com/drive/v3/files/${encodeURIComponent(fileId)}`,
      query: { fields: "*" },
    });
    return { output: result };
  }

  throw new Error(`Unsupported Google Drive operation "${operation}"`);
};

const googleCalendar: CustomNodeExecutor = async (context) => {
  const operation = toStringValue(context.config.operation, "listEvents");
  const calendarId = encodeURIComponent(toStringValue(context.config.calendarId, "primary"));

  if (operation === "listEvents") {
    const query: Record<string, unknown> = {
      singleEvents: "true",
      orderBy: "startTime",
      maxResults: toNumberValue(context.config.maxResults, 10),
    };

    const timeMin = toStringValue(context.config.timeMin, "").trim();
    const timeMax = toStringValue(context.config.timeMax, "").trim();
    if (timeMin) query.timeMin = timeMin;
    if (timeMax) query.timeMax = timeMax;

    const result = await googleApiRequest(context, {
      method: "GET",
      url: `https://www.googleapis.com/calendar/v3/calendars/${calendarId}/events`,
      query,
    });
    return { output: result };
  }

  if (operation === "createEvent") {
    const summary = requireString(context.config.summary, "Summary");
    const startDateTime = requireString(context.config.startDateTime, "Start (ISO)");
    const endDateTime = requireString(context.config.endDateTime, "End (ISO)");

    const result = await googleApiRequest(context, {
      method: "POST",
      url: `https://www.googleapis.com/calendar/v3/calendars/${calendarId}/events`,
      body: {
        summary,
        description: toStringValue(context.config.description, ""),
        location: toStringValue(context.config.location, ""),
        start: { dateTime: startDateTime },
        end: { dateTime: endDateTime },
      },
    });
    return { output: result };
  }

  if (operation === "deleteEvent") {
    const eventId = requireString(context.config.eventId, "Event ID");
    await googleApiRequest(context, {
      method: "DELETE",
      url: `https://www.googleapis.com/calendar/v3/calendars/${calendarId}/events/${encodeURIComponent(eventId)}`,
      responseFormat: "full",
    });
    return { output: { deleted: true, eventId } };
  }

  throw new Error(`Unsupported Google Calendar operation "${operation}"`);
};

const googleDocs: CustomNodeExecutor = async (context) => {
  const operation = toStringValue(context.config.operation, "createDocument");

  if (operation === "createDocument") {
    const title = toStringValue(context.config.title, "").trim() || "Untitled Document";
    const result = await googleApiRequest(context, {
      method: "POST",
      url: "https://docs.googleapis.com/v1/documents",
      body: { title },
    });
    return { output: result };
  }

  if (operation === "getDocument") {
    const documentId = requireString(context.config.documentId, "Document ID");
    const result = await googleApiRequest(context, {
      method: "GET",
      url: `https://docs.googleapis.com/v1/documents/${encodeURIComponent(documentId)}`,
    });
    return { output: result };
  }

  if (operation === "appendText") {
    const documentId = requireString(context.config.documentId, "Document ID");
    const text = requireString(context.config.text, "Text");
    const index = Math.max(1, toNumberValue(context.config.index, 1));

    const result = await googleApiRequest(context, {
      method: "POST",
      url: `https://docs.googleapis.com/v1/documents/${encodeURIComponent(documentId)}:batchUpdate`,
      body: {
        requests: [
          {
            insertText: {
              location: { index },
              text,
            },
          },
        ],
      },
    });
    return { output: result };
  }

  throw new Error(`Unsupported Google Docs operation "${operation}"`);
};

const googleApiRequestExecutor: CustomNodeExecutor = async (context) => {
  const method = toStringValue(context.config.method, "GET").toUpperCase();
  const url = requireString(context.config.url, "URL");
  const queryParams = toRecord(context.config.queryParams);
  const headersRecord = toRecord(context.config.headers);
  const bodyRecord = toRecord(context.config.body);
  const timeoutMs = Math.max(0, toNumberValue(context.config.timeout, 30000));
  const responseFormat = toStringValue(context.config.responseFormat, "json");

  const headers: Record<string, string> = {};
  for (const [key, value] of Object.entries(headersRecord)) {
    if (!key) continue;
    headers[key] = toStringValue(value);
  }

  const query: Record<string, unknown> = {};
  for (const [key, value] of Object.entries(queryParams)) {
    if (!key) continue;
    query[key] = value;
  }

  const hasBody = Object.keys(bodyRecord).length > 0;
  const result = await googleApiRequest(context, {
    method,
    url,
    query,
    headers,
    body: hasBody ? bodyRecord : undefined,
    timeoutMs,
    responseFormat:
      responseFormat === "text" || responseFormat === "full" ? responseFormat : "json",
  });

  return { output: result };
};

export const customNodeExecutors: Record<string, CustomNodeExecutor> = {
  myCompanyPing,
  gmail,
  googleSheets,
  googleDrive,
  googleCalendar,
  googleDocs,
  googleApiRequest: googleApiRequestExecutor,
};
